import math
import re
import itertools
from sympy import symbols, Eq, solve

from functions.common_funtions import get_element_count_dict, to_revert_subscript, convert_formula, convert_formula2


def lcm(a, b):
    return abs(a * b) // math.gcd(a, b)


def lcm_list(numbers):
    lcm_result = numbers[0]
    for num in numbers[1:]:
        lcm_result = lcm(lcm_result, num)
    return lcm_result


def get_element_set(chemical_formula):
    pattern = r'([A-Z][a-z]*)'
    element_set = set(re.findall(pattern, chemical_formula))
    return element_set


def get_formula_element_count_dict_dict(chemical_formula):
    return {chemical_formula: get_element_count_dict(chemical_formula)}


def get_reactant_chemical_formula_list(equation):
    left = equation.split("->")[0].split("+")
    return [reactant.strip() for reactant in left]


def get_product_chemical_formula_list(equation):
    right = equation.split("->")[1].split("+")
    return [product.strip() for product in right]


def get_comb_list(max_number, repeat=4):
    return list(itertools.product([i for i in range(1, max_number + 1)], repeat=repeat))


def get_element_total_count(element, reactant_formula_element_count_dict_dict):
    element_count = 0
    for reactant_chemical_formula, element_count_dict in reactant_formula_element_count_dict_dict.items():
        if element in get_element_set(reactant_chemical_formula):
            element_count += element_count_dict[element]
    return element_count


def balance_equation1(equation):
    all_element_set = get_element_set(equation)
    reactant_chemical_formula_list = get_reactant_chemical_formula_list(equation)
    product_chemical_formula_list = get_product_chemical_formula_list(equation)
    reactant_formula_element_count_dict_dict = {reactant_chemical_formula: get_element_count_dict(reactant_chemical_formula) for reactant_chemical_formula in reactant_chemical_formula_list}
    product_formula_element_count_dict_dict = {product_chemical_formula: get_element_count_dict(product_chemical_formula) for product_chemical_formula in product_chemical_formula_list}
    all_chemical_formula_list = reactant_chemical_formula_list + product_chemical_formula_list
    # 定义数字范围
    comb_list = get_comb_list(16, repeat=len(all_chemical_formula_list))
    ok_combo = None
    for combo in comb_list:
        true_count = 0
        new_reactant_formula_element_count_dict_dict = dict()
        new_product_formula_element_count_dict_dict = dict()
        for i in range(len(all_chemical_formula_list)):
            chemical_formula = all_chemical_formula_list[i]
            if chemical_formula in reactant_formula_element_count_dict_dict.keys():
                new_reactant_formula_element_count_dict_dict[chemical_formula] = {element: count * combo[i] for element, count in reactant_formula_element_count_dict_dict[chemical_formula].items()}
            else:
                new_product_formula_element_count_dict_dict[chemical_formula] = {element: count * combo[i] for element, count in product_formula_element_count_dict_dict[chemical_formula].items()}
        # 將反應物元素數量相加
        for element in all_element_set:
            left_element_count = get_element_total_count(element, new_reactant_formula_element_count_dict_dict)
            right_element_count = get_element_total_count(element, new_product_formula_element_count_dict_dict)
            if left_element_count != right_element_count:
                break
            else:
                true_count += 1
        # 如果左右元素數量一樣
        if true_count == len(list(all_element_set)):
            ok_combo = combo
            break
    result_dict = {all_chemical_formula_list[i]: ok_combo[i] for i in range(len(all_chemical_formula_list))}
    return result_dict


def get_symbol_solution_list_lcm(solution_list, symbol_list):
    adsf_list = list()
    for solution in solution_list:
        for i in range(1, 100):
            x = float(solution_list[solution].subs(symbol_list[-1], i))
            if x.is_integer():
                adsf_list.append(i)
                break
    last_value = lcm_list(list(set(adsf_list)))
    return last_value


def balance_equation(equation):
    equation = to_revert_subscript(equation)
    equation = equation.replace('→', '->')
    equation = convert_formula(equation)

    all_element_set = get_element_set(equation)
    all_element_list = list(all_element_set)
    reactant_chemical_formula_list = get_reactant_chemical_formula_list(equation)
    product_chemical_formula_list = get_product_chemical_formula_list(equation)
    all_chemical_formula_list = reactant_chemical_formula_list + product_chemical_formula_list
    reactant_formula_element_count_dict_dict = {reactant_chemical_formula: get_element_count_dict(reactant_chemical_formula) for reactant_chemical_formula in reactant_chemical_formula_list}
    product_formula_element_count_dict_dict = {product_chemical_formula: get_element_count_dict(product_chemical_formula) for product_chemical_formula in product_chemical_formula_list}

    # 代數法https://youtu.be/3AxdtjBzjeY?t=248
    alphabet_str = 'a b c d e f g h i j k l m n o p q r s t u v w x y z'
    symbol_list = symbols(alphabet_str[:len(all_chemical_formula_list) * 2])
    equation_list = list()
    for element in all_element_list:
        left_e = 0 * symbol_list[0]
        for formula, element_count_dict in reactant_formula_element_count_dict_dict.items():
            if element in element_count_dict:
                left_e += symbol_list[all_chemical_formula_list.index(formula)] * element_count_dict[element]

        right_e = 0 * symbol_list[0]
        for formula, element_count_dict in product_formula_element_count_dict_dict.items():
            if element in element_count_dict:
                right_e += symbol_list[all_chemical_formula_list.index(formula)] * element_count_dict[element]
        equation_list.append(Eq(left_e, right_e))  # 左邊=右邊

    solution_list = solve(equation_list, symbol_list)
    try:  # 如果條件不夠多會出錯
        last_value = get_symbol_solution_list_lcm(solution_list, symbol_list)
    except:
        return balance_equation1(equation)
    result_dict = dict()
    for i in range(len(all_chemical_formula_list) - 1):
        result_dict[all_chemical_formula_list[i]] = solution_list[symbol_list[i]].subs(symbol_list[-1], last_value)
    result_dict[all_chemical_formula_list[-1]] = last_value
    result_str = ''
    for i in range(len(reactant_chemical_formula_list)):
        formula = reactant_chemical_formula_list[i]
        if result_dict[formula] != 1:
            result_str += str(result_dict[formula])
        result_str += convert_formula2(formula)
        if i != len(reactant_chemical_formula_list) - 1:
            result_str += ' +'
        result_str += ' '
    result_str += '→ '
    for i in range(len(product_chemical_formula_list)):
        formula = product_chemical_formula_list[i]
        if result_dict[formula] != 1:
            result_str += str(result_dict[formula])
        result_str += convert_formula2(formula)
        if i != len(product_chemical_formula_list) - 1:
            result_str += ' +'
            result_str += ' '
    return result_str
