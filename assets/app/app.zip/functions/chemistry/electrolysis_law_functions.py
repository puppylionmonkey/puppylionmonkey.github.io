from functions.unit_functions import ureg

# Q/F = W/M*n
# Q : C
# W : g
# M : g/mole
# n : dimensionless
electrolysis_law_constant = 96500 * ureg.C / ureg.mole
F = electrolysis_law_constant


def calculate_electric_quantity(w_ureg, m_ureg, n: int):
    return w_ureg.to(ureg.g) / m_ureg * n * F


def calculate_mass(Q_ureg, m_ureg, n: int):
    return Q_ureg.to(ureg.C) / F / n * m_ureg


def calculate_molecular_weight(Q_ureg, w_ureg, n: int):
    return w_ureg.to(ureg.g) * n / Q_ureg.to(ureg.C) * F


def calculate_n_charge(Q_ureg, w_ureg, m_ureg):
    return (Q_ureg.to(ureg.C) / F) / (w_ureg.to(ureg.g) / m_ureg)
