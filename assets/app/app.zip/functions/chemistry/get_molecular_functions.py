from functions.common_funtions import get_element_count_dict
from functions.chemistry.periodic_table_element_functions import Element


def calculate_molecular_mass(molecular):
    element_count_dict = get_element_count_dict(molecular)
    molecular_weight = 0
    for element_str, count in element_count_dict.items():
        e = Element()
        ee = e.create_element(element_str)
        molecular_weight += count * round(ee.get_atomic_mass())
    return molecular_weight
