from functions.unit_functions import *
import math

# 创建一个单位管理器

# 瑞德柏常数
R_H = 1.097 * 10 ** 7 * ureg.m ** -1  # 单位是 1/m


# 计算波长
def calculate_wavelength(n1: int, n2: int):
    return 1 / (R_H * (1 / n1 ** 2 - 1 / n2 ** 2))


def calculate_n1_from_wavelength(wavelength_ureg, n2: int):
    value = (1 / wavelength_ureg) / R_H
    return round(math.sqrt(1 / (value + 1 / n2 ** 2)))


def calculate_n2_from_wavelength(wavelength_ureg, n1: int):
    value = (1 / wavelength_ureg) / R_H
    return round(math.sqrt(1 / (1 / n1 ** 2 - value)))
