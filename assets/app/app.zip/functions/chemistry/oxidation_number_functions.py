from functions.common_funtions import get_element_count_dict


def calculate_oxidation_number(formula, charge: int = 0):
    element_count_dict = get_element_count_dict(formula)
    element_oxidation_number_dict = dict()
    if len(element_count_dict) == 1:  # 單質元素狀態時，氧化數為零
        return {list(element_count_dict.keys())[0]: 0}
    for element, count in element_count_dict.items():
        if element in ['Li', 'Na', 'K', 'Rb', 'Cs', 'Fr']:  # 鹼金族於化合狀態，氧化數為＋1
            element_oxidation_number_dict[element] = 1
        if element in ['Be', 'Mg', 'Ca', 'Sr', 'Ba', 'Ra']:
            element_oxidation_number_dict[element] = 2
        if element in ['Al']:
            element_oxidation_number_dict[element] = 3
        if element in ['F']:
            if count == 2:
                element_oxidation_number_dict[element] = 0
            else:
                element_oxidation_number_dict[element] = -1
        if element in ['O']:
            if formula in ['H2O2', 'Na2O2', 'BaO2']:
                element_oxidation_number_dict[element] = -1
            # elif formula == 'BaO2':
            #     element_oxidation_number_dict[element] = -1 / 2
            else:
                element_oxidation_number_dict[element] = -2
        if element in ['H']:
            sub_list = list(element_count_dict.keys())
            metal_elements = [
                "Li", "Na", "K", "Rb", "Cs", "Fr", "Be", "Mg", "Ca", "Sr", "Ba", "Ra", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd",
                "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu",
                "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Al", "Ga", "In", "Sn", "Tl", "Pb", "Bi", "Po", "B", "Si", "Ge", "As", "Sb", "Te", "At"
            ]
            if any(elem in metal_elements for elem in sub_list):
                element_oxidation_number_dict[element] = -1
            else:
                element_oxidation_number_dict[element] = 1
        if element in ['Cl', 'Br', 'I']:
            element_oxidation_number_dict[element] = -1

    # 計算剩餘元素氧化素
    if len(element_count_dict) >= 2:
        # 計算現有電荷量
        un_balance_charge = 0
        for element, oxidation_number in element_oxidation_number_dict.items():
            un_balance_charge += oxidation_number * element_count_dict[element] - charge
        # 如果未平衡，剩下的元素平衡
        if un_balance_charge != charge:
            missing_element_list = list(set(element_count_dict.keys()) - set(element_oxidation_number_dict.keys()))
            missing_element = missing_element_list[0]
            element_oxidation_number_dict[missing_element] = -un_balance_charge // element_count_dict[missing_element]
    # 確認氧化數平衡
    total_oxidation_number = 0
    for element, count in element_count_dict.items():
        total_oxidation_number += count * element_oxidation_number_dict[element]
    if total_oxidation_number != charge:
        return '不平衡'
    return element_oxidation_number_dict
