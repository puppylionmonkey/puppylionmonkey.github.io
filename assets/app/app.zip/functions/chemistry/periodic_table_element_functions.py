from abc import ABC, abstractmethod


def simplify_electron_configuration(full_config: str) -> str:
    noble_gases = {
        '[He]': '1s²',
        '[Ne]': '1s² 2s² 2p⁶',
        '[Ar]': '1s² 2s² 2p⁶ 3s² 3p⁶',
        '[Kr]': '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶',
        '[Xe]': '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶',
        '[Rn]': '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶'
    }

    for symbol, config in sorted(noble_gases.items(), key=lambda x: -len(x[1])):
        if full_config.startswith(config):
            remaining = full_config[len(config):].strip()
            return f"{symbol} {remaining}" if remaining else symbol
    return full_config  # no simpli


class Element(ABC):
    def __init__(self):
        self.name = ''
        self.symbol = ''
        self.atomic_number = 0
        self.proton_number = self.atomic_number
        self.neutron_number = 0
        self.atomic_mass = 0.0
        self.electronegativity = None
        self.electron_configuration = ''
        self.element_symbols = [
            "H", "He",
            "Li", "Be", "B", "C", "N", "O", "F", "Ne",
            "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
            "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr",
            "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "I", "Te", "Xe",
            "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
            "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
            "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
            "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
            "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"
        ]

    def get_name(self):
        return self.name

    def get_symbol(self):
        return self.symbol

    def get_atomic_number(self):
        return self.atomic_number

    def get_proton_number(self):
        return self.proton_number

    def get_neutron_number(self):
        return self.neutron_number

    def get_atomic_mass(self):
        return self.atomic_mass



    @staticmethod
    def create_element(symbol: str):
        # 根据符号返回对应的元素实例
        elements = {
            'H': H(),
            'He': He(),
            'Li': Li(),
            'Be': Be(),
            'B': B(),
            'C': C(),
            'N': N(),
            'O': O(),
            'F': F(),
            'Ne': Ne(),
            'Na': Na(),
            'Mg': Mg(),
            'Al': Al(),
            'Si': Si(),
            'P': P(),
            'S': S(),
            'Cl': Cl(),
            'Ar': Ar(),
            'K': K(),
            'Ca': Ca(),
            'Sc': Sc(),
            'Ti': Ti(),
            'V': V(),
            'Cr': Cr(),
            'Mn': Mn(),
            'Fe': Fe(),
            'Co': Co(),
            'Ni': Ni(),
            'Cu': Cu(),
            'Zn': Zn(),
            'Ga': Ga(),
            'Ge': Ge(),
            'As': As(),
            'Se': Se(),
            'Br': Br(),
            'Kr': Kr(),
            'Rb': Rb(),
            'Sr': Sr(),
            'Y': Y(),
            'Zr': Zr(),
            'Nb': Nb(),
            'Mo': Mo(),
            'Tc': Tc(),
            'Ru': Ru(),
            'Rh': Rh(),
            'Pd': Pd(),
            'Ag': Ag(),
            'Cd': Cd(),
            'In': In(),
            'Sn': Sn(),
            'Sb': Sb(),
            'I': I(),
            'Xe': Xe(),
            'Cs': Cs(),
            'Ba': Ba(),
            'La': La(),
            'Ce': Ce(),
            'Pr': Pr(),
            'Nd': Nd(),
            'Pm': Pm(),
            'Sm': Sm(),
            'Eu': Eu(),
            'Gd': Gd(),
            'Tb': Tb(),
            'Dy': Dy(),
            'Ho': Ho(),
            'Er': Er(),
            'Tm': Tm(),
            'Yb': Yb(),
            'Lu': Lu(),
            'Hf': Hf(),
            'Ta': Ta(),
            'W': W(),
            'Re': Re(),
            'Os': Os(),
            'Ir': Ir(),
            'Pt': Pt(),
            'Au': Au(),
            'Hg': Hg(),
            'Tl': Tl(),
            'Pb': Pb(),
            'Bi': Bi(),
            'Po': Po(),
            'At': At(),
            'Rn': Rn(),
            'Fr': Fr(),
            'Ra': Ra(),
            'Ac': Ac(),
            'Th': Th(),
            'Pa': Pa(),
            'U': U(),
            'Np': Np(),
            'Pu': Pu(),
            'Am': Am(),
            'Cm': Cm(),
            'Bk': Bk(),
            'Cf': Cf(),
            'Es': Es(),
            'Fm': Fm(),
            'Md': Md(),
            'No': No(),
            'Lr': Lr(),
            'Rf': Rf(),
            'Db': Db(),
            'Sg': Sg(),
            'Bh': Bh(),
            'Hs': Hs(),
            'Mt': Mt(),
            'Ds': Ds(),
            'Rg': Rg(),
            'Cn': Cn(),
            'Nh': Nh(),
            'Fl': Fl(),
            'Mc': Mc(),
            'Lv': Lv(),
            'Ts': Ts(),
            'Og': Og()
        }
        return elements.get(symbol, None)


class H(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Hydrogen'
        self.symbol = 'H'
        self.atomic_number = 1
        self.proton_number = self.atomic_number
        self.neutron_number = 0
        self.atomic_mass = 1.008
        self.electronegativity = 2.2
        self.electron_configuration = '1s²'


class He(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Helium'
        self.symbol = 'He'
        self.atomic_number = 2
        self.proton_number = self.atomic_number
        self.neutron_number = 2
        self.atomic_mass = 4.0026
        self.electronegativity = None
        self.electron_configuration = '1s²'


class Li(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Lithium'
        self.symbol = 'Li'
        self.atomic_number = 3
        self.proton_number = self.atomic_number
        self.neutron_number = 4
        self.atomic_mass = 6.94
        self.electronegativity = 0.98
        self.electron_configuration = '1s² 2s¹'


class Be(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Beryllium'
        self.symbol = 'Be'
        self.atomic_number = 4
        self.proton_number = self.atomic_number
        self.neutron_number = 5
        self.atomic_mass = 9.0122
        self.electronegativity = 1.57
        self.electron_configuration = '1s² 2s²'


class B(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Boron'
        self.symbol = 'B'
        self.atomic_number = 5
        self.proton_number = self.atomic_number
        self.neutron_number = 6
        self.atomic_mass = 10.81
        self.electronegativity = 2.04
        self.electron_configuration = '1s² 2s² 2p¹'


class C(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Carbon'
        self.symbol = 'C'
        self.atomic_number = 6
        self.proton_number = self.atomic_number
        self.neutron_number = 6
        self.atomic_mass = 12.011
        self.electronegativity = 2.55
        self.electron_configuration = '1s² 2s² 2p²'


class N(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Nitrogen'
        self.symbol = 'N'
        self.atomic_number = 7
        self.proton_number = self.atomic_number
        self.neutron_number = 7
        self.atomic_mass = 14.007
        self.electronegativity = 3.04
        self.electron_configuration = '1s² 2s² 2p³'


class O(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Oxygen'
        self.symbol = 'O'
        self.atomic_number = 8
        self.proton_number = self.atomic_number
        self.neutron_number = 8
        self.atomic_mass = 15.999
        self.electronegativity = 3.44
        self.electron_configuration = '1s² 2s² 2p⁴'


class F(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Fluorine'
        self.symbol = 'F'
        self.atomic_number = 9
        self.proton_number = self.atomic_number
        self.neutron_number = 10
        self.atomic_mass = 18.998
        self.electronegativity = 3.98
        self.electron_configuration = '1s² 2s² 2p⁵'


class Ne(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Neon'
        self.symbol = 'Ne'
        self.atomic_number = 10
        self.proton_number = self.atomic_number
        self.neutron_number = 10
        self.atomic_mass = 20.180
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶'


class Na(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Sodium'
        self.symbol = 'Na'
        self.atomic_number = 11
        self.proton_number = self.atomic_number
        self.neutron_number = 12
        self.atomic_mass = 22.990
        self.electronegativity = 0.93
        self.electron_configuration = '1s² 2s² 2p⁶ 3s¹'


class Mg(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Magnesium'
        self.symbol = 'Mg'
        self.atomic_number = 12
        self.proton_number = self.atomic_number
        self.neutron_number = 12
        self.atomic_mass = 24.305
        self.electronegativity = 1.31
        self.electron_configuration = '1s² 2s² 2p⁶ 3s²'


class Al(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Aluminum'
        self.symbol = 'Al'
        self.atomic_number = 13
        self.proton_number = self.atomic_number
        self.neutron_number = 14
        self.atomic_mass = 26.982
        self.electronegativity = 1.61
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p¹'


class Si(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Silicon'
        self.symbol = 'Si'
        self.atomic_number = 14
        self.proton_number = self.atomic_number
        self.neutron_number = 14
        self.atomic_mass = 28.085
        self.electronegativity = 1.90
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p²'


class P(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Phosphorus'
        self.symbol = 'P'
        self.atomic_number = 15
        self.proton_number = self.atomic_number
        self.neutron_number = 16
        self.atomic_mass = 30.974
        self.electronegativity = 2.19
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p³'


class S(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Sulfur'
        self.symbol = 'S'
        self.atomic_number = 16
        self.proton_number = self.atomic_number
        self.neutron_number = 16
        self.atomic_mass = 32.06
        self.electronegativity = 2.58
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁴'


class Cl(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Chlorine'
        self.symbol = 'Cl'
        self.atomic_number = 17
        self.proton_number = self.atomic_number
        self.neutron_number = 18
        self.atomic_mass = 35.45
        self.electronegativity = 3.16
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁵'


class Ar(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Argon'
        self.symbol = 'Ar'
        self.atomic_number = 18
        self.proton_number = self.atomic_number
        self.neutron_number = 22
        self.atomic_mass = 39.948
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶'


class K(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Potassium'
        self.symbol = 'K'
        self.atomic_number = 19
        self.proton_number = self.atomic_number
        self.neutron_number = 20
        self.atomic_mass = 39.098
        self.electronegativity = 0.82
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s¹'


class Ca(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Calcium'
        self.symbol = 'Ca'
        self.atomic_number = 20
        self.proton_number = self.atomic_number
        self.neutron_number = 20
        self.atomic_mass = 40.078
        self.electronegativity = 1.00
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s²'


class Sc(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Scandium'
        self.symbol = 'Sc'
        self.atomic_number = 21
        self.proton_number = self.atomic_number
        self.neutron_number = 24
        self.atomic_mass = 44.956
        self.electronegativity = 1.36
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹ 4s²'


class Ti(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Titanium'
        self.symbol = 'Ti'
        self.atomic_number = 22
        self.proton_number = self.atomic_number
        self.neutron_number = 26
        self.atomic_mass = 47.867
        self.electronegativity = 1.54
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d² 4s²'


class V(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Vanadium'
        self.symbol = 'V'
        self.atomic_number = 23
        self.proton_number = self.atomic_number
        self.neutron_number = 28
        self.atomic_mass = 50.942
        self.electronegativity = 1.63
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d³ 4s²'


class Cr(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Chromium'
        self.symbol = 'Cr'
        self.atomic_number = 24
        self.proton_number = self.atomic_number
        self.neutron_number = 28
        self.atomic_mass = 52.0
        self.electronegativity = 1.66
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d⁵ 4s¹'


class Mn(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Manganese'
        self.symbol = 'Mn'
        self.atomic_number = 25
        self.proton_number = self.atomic_number
        self.neutron_number = 30
        self.atomic_mass = 54.938
        self.electronegativity = 1.55
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d⁵ 4s²'


class Fe(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Iron'
        self.symbol = 'Fe'
        self.atomic_number = 26
        self.proton_number = self.atomic_number
        self.neutron_number = 30
        self.atomic_mass = 55.845
        self.electronegativity = 1.83
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d⁶ 4s²'


class Co(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Cobalt'
        self.symbol = 'Co'
        self.atomic_number = 27
        self.proton_number = self.atomic_number
        self.neutron_number = 32
        self.atomic_mass = 58.933
        self.electronegativity = 1.88
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d⁷ 4s²'


class Ni(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Nickel'
        self.symbol = 'Ni'
        self.atomic_number = 28
        self.proton_number = self.atomic_number
        self.neutron_number = 31
        self.atomic_mass = 58.693
        self.electronegativity = 1.91
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d⁸ 4s²'


class Cu(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Copper'
        self.symbol = 'Cu'
        self.atomic_number = 29
        self.proton_number = self.atomic_number
        self.neutron_number = 35
        self.atomic_mass = 63.546
        self.electronegativity = 1.90
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s¹'


class Zn(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Zinc'
        self.symbol = 'Zn'
        self.atomic_number = 30
        self.proton_number = self.atomic_number
        self.neutron_number = 35
        self.atomic_mass = 65.38
        self.electronegativity = 1.65
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s²'


class Ga(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Gallium'
        self.symbol = 'Ga'
        self.atomic_number = 31
        self.proton_number = self.atomic_number
        self.neutron_number = 39
        self.atomic_mass = 69.723
        self.electronegativity = 1.81
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p¹'


class Ge(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Germanium'
        self.symbol = 'Ge'
        self.atomic_number = 32
        self.proton_number = self.atomic_number
        self.neutron_number = 41
        self.atomic_mass = 72.63
        self.electronegativity = 2.01
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p²'


class As(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Arsenic'
        self.symbol = 'As'
        self.atomic_number = 33
        self.proton_number = self.atomic_number
        self.neutron_number = 42
        self.atomic_mass = 74.922
        self.electronegativity = 2.18
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p³'


class Se(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Selenium'
        self.symbol = 'Se'
        self.atomic_number = 34
        self.proton_number = self.atomic_number
        self.neutron_number = 45
        self.atomic_mass = 78.971
        self.electronegativity = 2.55
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁴'


class Br(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Bromine'
        self.symbol = 'Br'
        self.atomic_number = 35
        self.proton_number = self.atomic_number
        self.neutron_number = 45
        self.atomic_mass = 79.904
        self.electronegativity = 2.96
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁵'


class Kr(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Krypton'
        self.symbol = 'Kr'
        self.atomic_number = 36
        self.proton_number = self.atomic_number
        self.neutron_number = 48
        self.atomic_mass = 83.798
        self.electronegativity = 3.00
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶'


class Rb(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Rubidium'
        self.symbol = 'Rb'
        self.atomic_number = 37
        self.proton_number = self.atomic_number
        self.neutron_number = 48
        self.atomic_mass = 85.468
        self.electronegativity = 0.82
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 5s¹'


class Sr(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Strontium'
        self.symbol = 'Sr'
        self.atomic_number = 38
        self.proton_number = self.atomic_number
        self.neutron_number = 50
        self.atomic_mass = 87.62
        self.electronegativity = 0.95
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 5s²'


class Y(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Yttrium'
        self.symbol = 'Y'
        self.atomic_number = 39
        self.proton_number = self.atomic_number
        self.neutron_number = 50
        self.atomic_mass = 88.906
        self.electronegativity = 1.22
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹ 5s²'


class Zr(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Zirconium'
        self.symbol = 'Zr'
        self.atomic_number = 40
        self.proton_number = self.atomic_number
        self.neutron_number = 51
        self.atomic_mass = 91.224
        self.electronegativity = 1.33
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d² 5s²'


class Nb(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Niobium'
        self.symbol = 'Nb'
        self.atomic_number = 41
        self.proton_number = self.atomic_number
        self.neutron_number = 52
        self.atomic_mass = 92.906
        self.electronegativity = 1.6
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d⁴ 5s¹'


class Mo(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Molybdenum'
        self.symbol = 'Mo'
        self.atomic_number = 42
        self.proton_number = self.atomic_number
        self.neutron_number = 54
        self.atomic_mass = 95.95
        self.electronegativity = 2.16
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d⁵ 5s¹'


class Tc(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Technetium'
        self.symbol = 'Tc'
        self.atomic_number = 43
        self.proton_number = self.atomic_number
        self.neutron_number = 56
        self.atomic_mass = 98
        self.electronegativity = 1.9
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d⁵ 5s²'


class Ru(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Ruthenium'
        self.symbol = 'Ru'
        self.atomic_number = 44
        self.proton_number = self.atomic_number
        self.neutron_number = 57
        self.atomic_mass = 101.07
        self.electronegativity = 2.2
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d⁷ 5s¹'


class Rh(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Rhodium'
        self.symbol = 'Rh'
        self.atomic_number = 45
        self.proton_number = self.atomic_number
        self.neutron_number = 58
        self.atomic_mass = 102.91
        self.electronegativity = 2.28
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d⁸ 5s¹'


class Pd(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Palladium'
        self.symbol = 'Pd'
        self.atomic_number = 46
        self.proton_number = self.atomic_number
        self.neutron_number = 60
        self.atomic_mass = 106.42
        self.electronegativity = 2.20
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰'


class Ag(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Silver'
        self.symbol = 'Ag'
        self.atomic_number = 47
        self.proton_number = self.atomic_number
        self.neutron_number = 61
        self.atomic_mass = 107.87
        self.electronegativity = 1.93
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s¹'


class Cd(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Cadmium'
        self.symbol = 'Cd'
        self.atomic_number = 48
        self.proton_number = self.atomic_number
        self.neutron_number = 64
        self.atomic_mass = 112.41
        self.electronegativity = 1.69
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s²'


class In(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Indium'
        self.symbol = 'In'
        self.atomic_number = 49
        self.proton_number = self.atomic_number
        self.neutron_number = 66
        self.atomic_mass = 114.82
        self.electronegativity = 1.78
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p¹'


class Sn(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Tin'
        self.symbol = 'Sn'
        self.atomic_number = 50
        self.proton_number = self.atomic_number
        self.neutron_number = 69
        self.atomic_mass = 118.71
        self.electronegativity = 1.96
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p²'


class Sb(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Antimony'
        self.symbol = 'Sb'
        self.atomic_number = 51
        self.proton_number = self.atomic_number
        self.neutron_number = 71
        self.atomic_mass = 121.76
        self.electronegativity = 2.05
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p³'


class I(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Iodine'
        self.symbol = 'I'
        self.atomic_number = 53
        self.proton_number = self.atomic_number
        self.neutron_number = 74
        self.atomic_mass = 126.90
        self.electronegativity = 2.66
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁵'


class Xe(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Xenon'
        self.symbol = 'Xe'
        self.atomic_number = 54
        self.proton_number = self.atomic_number
        self.neutron_number = 77
        self.atomic_mass = 131.29
        self.electronegativity = 2.60
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶'


class Cs(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Cesium'
        self.symbol = 'Cs'
        self.atomic_number = 55
        self.proton_number = self.atomic_number
        self.neutron_number = 78
        self.atomic_mass = 132.91
        self.electronegativity = 0.79
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 6s¹'


class Ba(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Barium'
        self.symbol = 'Ba'
        self.atomic_number = 56
        self.proton_number = self.atomic_number
        self.neutron_number = 81
        self.atomic_mass = 137.33
        self.electronegativity = 0.89
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 6s²'


class La(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Lanthanum'
        self.symbol = 'La'
        self.atomic_number = 57
        self.proton_number = self.atomic_number
        self.neutron_number = 82
        self.atomic_mass = 138.91
        self.electronegativity = 1.10
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 5d¹ 6s²'


class Ce(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Cerium'
        self.symbol = 'Ce'
        self.atomic_number = 58
        self.proton_number = self.atomic_number
        self.neutron_number = 82
        self.atomic_mass = 140.12
        self.electronegativity = 1.12
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f¹ 5d¹ 6s²'


class Pr(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Praseodymium'
        self.symbol = 'Pr'
        self.atomic_number = 59
        self.proton_number = self.atomic_number
        self.neutron_number = 82
        self.atomic_mass = 140.91
        self.electronegativity = 1.13
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f³ 6s²'


class Nd(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Neodymium'
        self.symbol = 'Nd'
        self.atomic_number = 60
        self.proton_number = self.atomic_number
        self.neutron_number = 84
        self.atomic_mass = 144.24
        self.electronegativity = 1.14
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f⁴ 6s²'


class Pm(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Promethium'
        self.symbol = 'Pm'
        self.atomic_number = 61
        self.proton_number = self.atomic_number
        self.neutron_number = 85
        self.atomic_mass = 145
        self.electronegativity = 1.13
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f⁵ 6s²'


class Sm(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Samarium'
        self.symbol = 'Sm'
        self.atomic_number = 62
        self.proton_number = self.atomic_number
        self.neutron_number = 88
        self.atomic_mass = 150.36
        self.electronegativity = 1.17
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f⁶ 6s²'


class Eu(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Europium'
        self.symbol = 'Eu'
        self.atomic_number = 63
        self.proton_number = self.atomic_number
        self.neutron_number = 89
        self.atomic_mass = 151.98
        self.electronegativity = 1.20
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f⁷ 6s²'


class Gd(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Gadolinium'
        self.symbol = 'Gd'
        self.atomic_number = 64
        self.proton_number = self.atomic_number
        self.neutron_number = 93
        self.atomic_mass = 157.25
        self.electronegativity = 1.20
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f⁷ 5d¹ 6s²'


class Tb(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Terbium'
        self.symbol = 'Tb'
        self.atomic_number = 65
        self.proton_number = self.atomic_number
        self.neutron_number = 94
        self.atomic_mass = 158.93
        self.electronegativity = 1.10
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f⁹ 6s²'


class Dy(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Dysprosium'
        self.symbol = 'Dy'
        self.atomic_number = 66
        self.proton_number = self.atomic_number
        self.neutron_number = 96
        self.atomic_mass = 162.50
        self.electronegativity = 1.22
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f¹⁰ 6s²'


class Ho(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Holmium'
        self.symbol = 'Ho'
        self.atomic_number = 67
        self.proton_number = self.atomic_number
        self.neutron_number = 98
        self.atomic_mass = 164.93
        self.electronegativity = 1.23
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f¹¹ 6s²'


class Er(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Erbium'
        self.symbol = 'Er'
        self.atomic_number = 68
        self.proton_number = self.atomic_number
        self.neutron_number = 99
        self.atomic_mass = 167.26
        self.electronegativity = 1.24
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f¹² 6s²'


class Tm(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Thulium'
        self.symbol = 'Tm'
        self.atomic_number = 69
        self.proton_number = self.atomic_number
        self.neutron_number = 102
        self.atomic_mass = 168.93
        self.electronegativity = 1.25
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 3d¹⁰ 4s² 4p⁶ 4d¹⁰ 5s² 5p⁶ 4f¹³ 6s²'


class Yb(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Ytterbium'
        self.symbol = 'Yb'
        self.atomic_number = 70
        self.proton_number = self.atomic_number
        self.neutron_number = 103
        self.atomic_mass = 173.04
        self.electronegativity = 1.10
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴'


class Lu(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Lutetium'
        self.symbol = 'Lu'
        self.atomic_number = 71
        self.proton_number = self.atomic_number
        self.neutron_number = 104
        self.atomic_mass = 175.00
        self.electronegativity = 1.27
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹'


class Hf(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Hafnium'
        self.symbol = 'Hf'
        self.atomic_number = 72
        self.proton_number = self.atomic_number
        self.neutron_number = 106
        self.atomic_mass = 178.49
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d²'


class Ta(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Tantalum'
        self.symbol = 'Ta'
        self.atomic_number = 73
        self.proton_number = self.atomic_number
        self.neutron_number = 108
        self.atomic_mass = 180.95
        self.electronegativity = 1.5
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d³'


class W(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Tungsten'
        self.symbol = 'W'
        self.atomic_number = 74
        self.proton_number = self.atomic_number
        self.neutron_number = 110
        self.atomic_mass = 183.84
        self.electronegativity = 2.36
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁴'


class Re(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Rhenium'
        self.symbol = 'Re'
        self.atomic_number = 75
        self.proton_number = self.atomic_number
        self.neutron_number = 111
        self.atomic_mass = 186.21
        self.electronegativity = 1.9
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁵'


class Os(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Osmium'
        self.symbol = 'Os'
        self.atomic_number = 76
        self.proton_number = self.atomic_number
        self.neutron_number = 114
        self.atomic_mass = 190.23
        self.electronegativity = 2.2
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁶'


class Ir(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Iridium'
        self.symbol = 'Ir'
        self.atomic_number = 77
        self.proton_number = self.atomic_number
        self.neutron_number = 115
        self.atomic_mass = 192.22
        self.electronegativity = 2.2
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d⁷'


class Pt(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Platinum'
        self.symbol = 'Pt'
        self.atomic_number = 78
        self.proton_number = self.atomic_number
        self.neutron_number = 117
        self.atomic_mass = 195.08
        self.electronegativity = 2.28
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s¹ 4f¹⁴ 5d⁹'


class Au(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Gold'
        self.symbol = 'Au'
        self.atomic_number = 79
        self.proton_number = self.atomic_number
        self.neutron_number = 118
        self.atomic_mass = 196.97
        self.electronegativity = 2.54
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s¹ 4f¹⁴ 5d¹⁰'


class Hg(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Mercury'
        self.symbol = 'Hg'
        self.atomic_number = 80
        self.proton_number = self.atomic_number
        self.neutron_number = 121
        self.atomic_mass = 200.59
        self.electronegativity = 2.00
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰'


class Tl(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Thallium'
        self.symbol = 'Tl'
        self.atomic_number = 81
        self.proton_number = self.atomic_number
        self.neutron_number = 123
        self.atomic_mass = 204.38
        self.electronegativity = 1.62
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p¹'


class Pb(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Lead'
        self.symbol = 'Pb'
        self.atomic_number = 82
        self.proton_number = self.atomic_number
        self.neutron_number = 125
        self.atomic_mass = 207.2
        self.electronegativity = 2.33
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p²'


class Bi(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Bismuth'
        self.symbol = 'Bi'
        self.atomic_number = 83
        self.proton_number = self.atomic_number
        self.neutron_number = 126
        self.atomic_mass = 208.98
        self.electronegativity = 2.02
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p³'


class Po(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Polonium'
        self.symbol = 'Po'
        self.atomic_number = 84
        self.proton_number = self.atomic_number
        self.neutron_number = 130
        self.atomic_mass = 209
        self.electronegativity = 2.0
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁴'


class At(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Astatine'
        self.symbol = 'At'
        self.atomic_number = 85
        self.proton_number = self.atomic_number
        self.neutron_number = 138
        self.atomic_mass = 210
        self.electronegativity = 2.2
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁵'


class Rn(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Radon'
        self.symbol = 'Rn'
        self.atomic_number = 86
        self.proton_number = self.atomic_number
        self.neutron_number = 139
        self.atomic_mass = 222
        self.electronegativity = 2.2
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶'


class Fr(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Francium'
        self.symbol = 'Fr'
        self.atomic_number = 87
        self.proton_number = self.atomic_number
        self.neutron_number = 136
        self.atomic_mass = 223
        self.electronegativity = 0.7
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s¹'


class Ra(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Radium'
        self.symbol = 'Ra'
        self.atomic_number = 88
        self.proton_number = self.atomic_number
        self.neutron_number = 138
        self.atomic_mass = 226.03
        self.electronegativity = 0.9
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s²'


class Ac(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Actinium'
        self.symbol = 'Ac'
        self.atomic_number = 89
        self.proton_number = self.atomic_number
        self.neutron_number = 138
        self.atomic_mass = 227
        self.electronegativity = 1.1
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 6d¹'


class Th(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Thorium'
        self.symbol = 'Th'
        self.atomic_number = 90
        self.proton_number = self.atomic_number
        self.neutron_number = 140
        self.atomic_mass = 232.04
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 6d²'


class Pa(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Protactinium'
        self.symbol = 'Pa'
        self.atomic_number = 91
        self.proton_number = self.atomic_number
        self.neutron_number = 140
        self.atomic_mass = 231.04
        self.electronegativity = 1.5
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f² 6d¹'


class U(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Uranium'
        self.symbol = 'U'
        self.atomic_number = 92
        self.proton_number = self.atomic_number
        self.neutron_number = 146
        self.atomic_mass = 238.03
        self.electronegativity = 1.38
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f³ 6d¹'


class Np(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Neptunium'
        self.symbol = 'Np'
        self.atomic_number = 93
        self.proton_number = self.atomic_number
        self.neutron_number = 145
        self.atomic_mass = 237
        self.electronegativity = 1.36
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁴ 6d¹'


class Pu(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Plutonium'
        self.symbol = 'Pu'
        self.atomic_number = 94
        self.proton_number = self.atomic_number
        self.neutron_number = 150
        self.atomic_mass = 244
        self.electronegativity = 1.28
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁶'


class Am(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Americium'
        self.symbol = 'Am'
        self.atomic_number = 95
        self.proton_number = self.atomic_number
        self.neutron_number = 151
        self.atomic_mass = 243
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁷'


class Cm(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Curium'
        self.symbol = 'Cm'
        self.atomic_number = 96
        self.proton_number = self.atomic_number
        self.neutron_number = 152
        self.atomic_mass = 247
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁷ 6d¹'


class Bk(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Berkelium'
        self.symbol = 'Bk'
        self.atomic_number = 97
        self.proton_number = self.atomic_number
        self.neutron_number = 153
        self.atomic_mass = 247
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f⁹'


class Cf(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Californium'
        self.symbol = 'Cf'
        self.atomic_number = 98
        self.proton_number = self.atomic_number
        self.neutron_number = 157
        self.atomic_mass = 251
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁰'


class Es(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Einsteinium'
        self.symbol = 'Es'
        self.atomic_number = 99
        self.proton_number = self.atomic_number
        self.neutron_number = 157
        self.atomic_mass = 252
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹¹'


class Fm(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Fermium'
        self.symbol = 'Fm'
        self.atomic_number = 100
        self.proton_number = self.atomic_number
        self.neutron_number = 157
        self.atomic_mass = 257
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹²'


class Md(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Mendelevium'
        self.symbol = 'Md'
        self.atomic_number = 101
        self.proton_number = self.atomic_number
        self.neutron_number = 159
        self.atomic_mass = 258
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹³'


class No(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Nobelium'
        self.symbol = 'No'
        self.atomic_number = 102
        self.proton_number = self.atomic_number
        self.neutron_number = 160
        self.atomic_mass = 259
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴'


class Lr(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Lawrencium'
        self.symbol = 'Lr'
        self.atomic_number = 103
        self.proton_number = self.atomic_number
        self.neutron_number = 161
        self.atomic_mass = 262
        self.electronegativity = 1.3
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹'


class Rf(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Rutherfordium'
        self.symbol = 'Rf'
        self.atomic_number = 104
        self.proton_number = self.atomic_number
        self.neutron_number = 162
        self.atomic_mass = 267
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d²'


class Db(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Dubnium'
        self.symbol = 'Db'
        self.atomic_number = 105
        self.proton_number = self.atomic_number
        self.neutron_number = 163
        self.atomic_mass = 270
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d³'


class Sg(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Seaborgium'
        self.symbol = 'Sg'
        self.atomic_number = 106
        self.proton_number = self.atomic_number
        self.neutron_number = 163
        self.atomic_mass = 271
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁴'


class Bh(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Bohrium'
        self.symbol = 'Bh'
        self.atomic_number = 107
        self.proton_number = self.atomic_number
        self.neutron_number = 164
        self.atomic_mass = 270
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁵'


class Hs(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Hassium'
        self.symbol = 'Hs'
        self.atomic_number = 108
        self.proton_number = self.atomic_number
        self.neutron_number = 167
        self.atomic_mass = 277
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁶'


class Mt(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Meitnerium'
        self.symbol = 'Mt'
        self.atomic_number = 109
        self.proton_number = self.atomic_number
        self.neutron_number = 168
        self.atomic_mass = 276
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁷'


class Ds(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Darmstadtium'
        self.symbol = 'Ds'
        self.atomic_number = 110
        self.proton_number = self.atomic_number
        self.neutron_number = 169
        self.atomic_mass = 281
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁸'


class Rg(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Roentgenium'
        self.symbol = 'Rg'
        self.atomic_number = 111
        self.proton_number = self.atomic_number
        self.neutron_number = 170
        self.atomic_mass = 280
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d⁹'


class Cn(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Copernicium'
        self.symbol = 'Cn'
        self.atomic_number = 112
        self.proton_number = self.atomic_number
        self.neutron_number = 173
        self.atomic_mass = 285
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰'


class Nh(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Nihonium'
        self.symbol = 'Nh'
        self.atomic_number = 113
        self.proton_number = self.atomic_number
        self.neutron_number = 173
        self.atomic_mass = 284
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p¹'


class Fl(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Flerovium'
        self.symbol = 'Fl'
        self.atomic_number = 114
        self.proton_number = self.atomic_number
        self.neutron_number = 175
        self.atomic_mass = 289
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p²'


class Mc(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Moscovium'
        self.symbol = 'Mc'
        self.atomic_number = 115
        self.proton_number = self.atomic_number
        self.neutron_number = 176
        self.atomic_mass = 288
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p³'


class Lv(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Livermorium'
        self.symbol = 'Lv'
        self.atomic_number = 116
        self.proton_number = self.atomic_number
        self.neutron_number = 177
        self.atomic_mass = 293
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p⁴'


class Ts(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Tennessine'
        self.symbol = 'Ts'
        self.atomic_number = 117
        self.proton_number = self.atomic_number
        self.neutron_number = 177
        self.atomic_mass = 294
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p⁵'


class Og(Element):
    def __init__(self):
        super().__init__()
        self.name = 'Oganesson'
        self.symbol = 'Og'
        self.atomic_number = 118
        self.proton_number = self.atomic_number
        self.neutron_number = 177
        self.atomic_mass = 294
        self.electronegativity = None
        self.electron_configuration = '1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶ 6s² 4f¹⁴ 5d¹⁰ 6p⁶ 7s² 5f¹⁴ 6d¹⁰ 7p⁶'
