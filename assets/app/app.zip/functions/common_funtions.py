import re


def get_element_count_dict(formula):
    element_count_dict = {}  # 使用普通字典
    stack = [element_count_dict]  # 用来记录括号中的元素
    i = 0
    while i < len(formula):
        if formula[i] == '(':
            stack.append({})  # 新建字典用于括号内的元素
            i += 1
        elif formula[i] == ')':
            i += 1
            m = re.match(r'\d+', formula[i:])
            multiplier = int(m.group()) if m else 1  # 获取括号后的倍数
            if m:
                i += len(m.group())
            popped = stack.pop()  # 弹出当前括号中的元素
            for elem, count in popped.items():
                if elem in stack[-1]:
                    stack[-1][elem] += count * multiplier  # 更新外层字典
                else:
                    stack[-1][elem] = count * multiplier
        else:
            m = re.match(r'([A-Z][a-z]*)(-?\d*)', formula[i:])  # 支持负数的元素数量
            if not m:
                raise ValueError(f"Invalid formula at: {formula[i:]}")
            elem = m.group(1)
            count = int(m.group(2)) if m.group(2) else 1  # 处理元素及其数量，默认为 1
            if elem in stack[-1]:
                stack[-1][elem] += count
            else:
                stack[-1][elem] = count
            i += len(m.group(0))  # 移动指针
    return stack[0]  # 返回最外层字典


def to_camel_case(snake_str: str) -> str:
    parts = snake_str.split('_')
    return ''.join(word.capitalize() for word in parts)


def test_get_element_count_dict():
    assert get_element_count_dict("NaHCO3") == {'Na': 1, 'H': 1, 'C': 1, 'O': 3}
    assert get_element_count_dict("C6H12O6") == {'C': 6, 'H': 12, 'O': 6}
    assert get_element_count_dict("Na2CO3") == {'Na': 2, 'C': 1, 'O': 3}
    assert get_element_count_dict("Na2CO3H2O") == {'Na': 2, 'C': 1, 'O': 4, 'H': 2}
    assert get_element_count_dict("MnOE-1") == {'E': -1, 'Mn': 1, 'O': 1}
    assert get_element_count_dict("Ca(OH)2") == {'Ca': 1, 'O': 2, 'H': 2}


def format_number(num) -> str:
    if num >= 10 ** 9 or 0 < num < 10 ** -6:
        base, exp = f"{num:.6e}".split("e")  # 拆分基数和指数
        exp_sup = exp.lstrip("+")
        return f"{base:.3}×10{to_superscript(int(exp_sup))}"  # 格式化为 *10^ 形式
    else:
        return f"{num:.6f}".rstrip("0").rstrip(".")


def to_subscript(text: str) -> str:
    subscript_map = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")
    return str(text).translate(subscript_map)


def to_superscript(text) -> str:
    text = str(text)
    sup_map = str.maketrans("-+0123456789", "⁻⁺⁰¹²³⁴⁵⁶⁷⁸⁹")  # 创建上标映射，加入 + 映射
    return str(text).translate(sup_map)


def to_charge_superscript(text) -> str:
    text_int = int(text)
    if text_int == 0:
        return ""
    if text_int == 1:
        return '⁺'
    elif text_int > 1:
        return '⁺' + to_superscript(text)
    else:
        return to_superscript(text)


def search_str_in_dict(text: str, original_dict: dict) -> dict:
    return {key: value for key, value in original_dict.items() if text.lower().strip() in str(key).lower() or text.lower().strip() in str(value).lower()}


def to_superscript2(text: str) -> str:
    text_int = int(text)
    if text_int == 1:
        return '⁺'
    elif text_int > 1:
        return '⁺' + to_superscript(text)
    else:
        return to_superscript(text)


def test_to_subscript():
    assert to_subscript("H2O") == "H₂O"
    assert to_subscript("CO2") == "CO₂"
    assert to_subscript("SO42") == "SO₄₂"
    assert to_subscript("Na") == "Na"
    assert to_subscript("C6H12O6") == "C₆H₁₂O₆"


def test_to_superscript():
    assert to_superscript("3+") == "³⁺"
    assert to_superscript("2-") == "²⁻"
    assert to_superscript("+") == "⁺"
    assert to_superscript("4-") == "⁴⁻"
    assert to_superscript("") == ""


def test_format_number():
    assert format_number(0.00069444444444444) == '0.000694'
    assert format_number(759.9998917256114) == '759.999892'
    assert format_number(1000000000) == '1.0×10⁹'
    assert format_number(2e-7) == '2.0×10⁻⁷'
    assert format_number(2e-5) == '0.00002'


def to_revert_subscript(text: str) -> str:
    subscript_map = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")
    return str(text).translate(subscript_map)


def convert_formula(formula):
    # 替換 Unicode 上標為普通數字和符號
    def replacer(match):
        charge = match.group(0)
        charge = charge.replace('⁻', '-').replace('⁺', '+')
        sup_to_num = str.maketrans('⁰¹²³⁴⁵⁶⁷⁸⁹', '0123456789')
        charge = charge.translate(sup_to_num)
        if charge == '+':
            charge = '1'
        elif charge == '-':
            charge = '-1'
        return f'E{charge}'

    # 處理 Unicode 上標
    formula = re.sub(r'[⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+', replacer, formula)
    # 把 E+3 變成 E3
    formula = re.sub(r'E\+(\d+)', r'E\1', formula)
    return formula


def convert_formula2(formula):
    formula_split_e = formula.split('E')
    new_formula = to_subscript(formula_split_e[0])
    if 'E' in formula:
        new_formula += to_superscript2(formula_split_e[1])
    return new_formula


def test_convert_formula2():
    assert convert_formula2('Cr2O7E-2') == 'Cr₂O₇⁻²'
    assert convert_formula2('SO3E-2') == 'SO₃⁻²'
    assert convert_formula2('HE1') == 'H⁺'


# x**5轉換成x⁵
def convert_power_to_superscript(expr: str) -> str:
    superscript_dict = {
        "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
        "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹",
        "+": "⁺", "-": "⁻", "=": "⁼", "(": "⁽", ")": "⁾",
        "n": "ⁿ", "i": "ⁱ", "x": "ˣ", "y": "ʸ", "z": "ᶻ",
        "a": "ᵃ", "b": "ᵇ", "c": "ᶜ", "d": "ᵈ", "e": "ᵉ",
        "f": "ᶠ", "g": "ᵍ", "h": "ʰ", "j": "ʲ", "k": "ᵏ",
        "l": "ˡ", "m": "ᵐ", "o": "ᵒ", "p": "ᵖ", "r": "ʳ",
        "s": "ˢ", "t": "ᵗ", "u": "ᵘ", "v": "ᵛ", "w": "ʷ",
        "q": "ᑫ"  # 稀有字元，視系統字型支援程度
    }

    def replacer(match):
        base = match.group(1)
        exponent = match.group(2)
        if exponent == "1":
            return base
        translated = ''.join(superscript_dict.get(c, c) for c in exponent)
        return f"{base}{translated}"

    # 支援變數、常數、函數與括號為底，指數為字母或數字組合
    return re.sub(r"([a-zA-Z∂0-9_().]+)\*\*([a-zA-Z0-9()+\-=/]*)", replacer, expr)


def test_convert_power_to_superscript():
    assert convert_power_to_superscript("x**2 + 3**k + tan(x)**2") == "x² + 3ᵏ + tan(x)²"


def remove_redundant_multiplication_sign(expr: str) -> str:
    # 僅在數字、變數、上標之間移除乘號（避免刪掉 3*(x+1) 這種）
    return re.sub(r"(?<=[0-9a-zA-Z⁰¹²³⁴⁵⁶⁷⁸⁹⁻])\*(?=[a-zA-Z∂])", "", expr)


def convert_expression_to_pretty(expr: str) -> str:
    expr = convert_power_to_superscript(expr)
    expr = remove_redundant_multiplication_sign(expr)
    return expr


def test_convert_expression_to_pretty():
    expr = "2x**5 + 5**5 + xy = 5"
    assert convert_expression_to_pretty(expr) == "2x⁵ + 5⁵ + xy = 5"
    expr = "∂**5"
    assert convert_expression_to_pretty(expr) == '∂⁵'
    assert convert_expression_to_pretty('∂**1') == '∂'
    assert convert_expression_to_pretty('x**2*y**2') == 'x²y²'
    assert convert_expression_to_pretty('3*x²') == '3x²'
    assert convert_expression_to_pretty('tan(x)**2') == 'tan(x)²'
    assert convert_expression_to_pretty('3**k') == '3ᵏ'
