import os

from path_config import project_path

language_dict = {
    '科學': 'Science',
    '加速': 'Acceleration',
    '物質': 'Substance',
    '溫度': 'Temperature',
    '飽和壓力': 'Saturation Pressure',
    '飽和液態': 'Saturated Liquid',
    '飽和氣態': 'Saturated Vapor',
    '比容': 'Specific Volume',
    '比焓': 'Specific Enthalpy',
    '比熵': 'Specific Entropy',
    '比內能': 'Specific Internal Energy',
    '請輸入正確的數值': 'Please enter valid values',
    '輸入': 'Input',
    '錯誤': 'Error',
    '計算': 'Calculate',
    #####
    '反應物數量': 'Reactant Count',
    '產物數量': 'Product Count',
    '確認': 'Confirm',
    '輸入化學式': 'Enter Chemical Formula',
    '電荷：': 'Charge:',
    '上一步': 'Undo',
    '重設': 'Reset',
    '化學式：': 'Chemical Formula:',
    '平衡後化學式：': 'Balanced Chemical Formula:',
    '請輸入反應物與產物的數量': 'Enter reactants and products count',
    '請輸入正整數（不含 0、負數、小數點）': 'Please enter a positive integer (no 0, negative, or decimal)',
    '輸入錯誤': 'Input error',
    '名稱': 'Name',
    '元素符號': 'Symbol',
    '原子序': 'Atomic Number',
    '質子數': 'Proton Number',
    '中子數': 'Neutron Number',
    '原子質量': 'Atomic Mass',
    '電負度': 'Electronegativity',
    '電子組態': 'Electron Configuration',
    "輸入莫爾數 (mole)": "Enter Moles",
    "分子量": "Molar Mass",
    "質量": "Mass",
    "電荷": "Charge:",
    "氧化數": "Oxidation Numbers",
    "輸入一個方程式（如 x**2 + sin(x)）": "Enter an expression (e.g., x**2 + sin(x))",
    "微分": "Differentiate",
    "積分": "Integrate",
    "錯誤：找不到變數": "Error: No variable found",
    "結果": "Result",
    "範例": "Example",
    '請輸入一個方程式（如 2x + y = 3）': 'Please enter an equation (e.g., 2x + y = 3)',
    '方程式': 'Equation',
    '刪除': 'Delete',
    '時間戳': 'Timestamp',
    '時間': 'Time',
    '轉換模式': 'Mode',
    '年': 'Year',
    '月': 'Month',
    '日': 'Day',
    '時': 'Hour',
    '分': 'Min',
    '秒': 'Second',
    "密度：": "Density",
    '選擇氣體': 'Select gas',
    '發送郵件': 'Send email',
    '隱私政策': 'Privacy Policy',
    '搜尋': 'Search',
    '設定': 'Settings',
    '聯絡我們': 'Contact Us',
    '回到主頁': 'Home',
    '搜尋名稱或公式...': 'Search by name or formula...',
    '單位': 'unit',
    '語言': 'Language',
    "選擇計算濃度": "Select Concentration Type",
    "莫耳濃度": "Molarity",
    "重量百分濃度": "Weight Percent",
    "體積百分濃度": "Volume Percent",
    "溶質": "Solute",
    "溶液": "Solution",
    "濃度": "Concentration",
    "請輸入正確的數值！": "Please enter valid values!",
    "關閉": "Close",
}


def set_text_by_language(text, language):
    return text if language == 'zh' else language_dict.get(text, text)


def get_language():
    path = project_path + 'assets/language_file.txt'
    if not os.path.exists(path):
        return 'zh'
    with open(path, 'r') as f:
        language = f.readlines()
    return language[0].strip() if language else 'zh'


def set_language(language_text: str):
    try:
        with open(project_path + 'assets/language_file.txt', 'w') as f:
            f.write(language_text)
    except:
        pass
