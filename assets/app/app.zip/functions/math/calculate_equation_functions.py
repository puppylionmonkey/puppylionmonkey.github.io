import re
import sympy as sp
from sympy import parse_expr
from sympy.parsing.sympy_parser import standard_transformations, implicit_multiplication_application, convert_xor

transformations = standard_transformations + (implicit_multiplication_application, convert_xor)


def convert_superscript_to_power(expr: str) -> str:
    superscript_map = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")
    pattern = re.compile(r"([a-zA-Z])([⁰¹²³⁴⁵⁶⁷⁸⁹]+)")
    return pattern.sub(lambda m: f"{m.group(1)}**{m.group(2).translate(superscript_map)}", expr)


def evaluate_expression_multi(expr_str: str, values: dict):
    expr_str = convert_superscript_to_power(expr_str)
    expr = parse_expr(expr_str, transformations=transformations)
    subs = {sp.Symbol(k): v for k, v in values.items()}
    return expr.subs(subs).evalf()


def test_evaluate_expression_multi():
    assert float(evaluate_expression_multi("2*x + 3", {"x": 1})) == 5
    assert float(evaluate_expression_multi("x*y + y**2", {"x": 2, "y": 3})) == 15
    assert float(evaluate_expression_multi("x - y", {"x": -2, "y": 3})) == -5
    assert float(evaluate_expression_multi("x / y", {"x": 1.5, "y": 0.5})) == 3
    assert abs(evaluate_expression_multi("x * pi", {"x": 2}) - 2 * sp.pi.evalf()) < 1e-10
    assert float(evaluate_expression_multi("5 + 2", {})) == 7
    assert float(evaluate_expression_multi("5 + 2", {})) == 7
    assert float(evaluate_expression_multi("36*x²*y", {'x': 5.0, 'y': 1.0})) == 900
    assert float(evaluate_expression_multi("4x³ + 18x²y² + 6", {'x': 5.0, 'y': 1.0})) == 956
