import sympy as sp
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application, convert_xor

transformations = standard_transformations + (implicit_multiplication_application, convert_xor)


def calculate_sigma(expr_str: str, start: int, end: int):
    expr = parse_expr(expr_str, transformations=transformations)
    free_symbols = list(expr.free_symbols)

    if not free_symbols:
        # 無變數，表示為常數總和
        return expr * (end - start + 1)

    var = free_symbols[0]
    return sp.summation(expr, (var, start, end))
