import math


# A = π r²
def calculate_area(r):
    return math.pi * r ** 2


# r = sqrt(A / π)
def calculate_radius(A):
    return (A / math.pi) ** 0.5
