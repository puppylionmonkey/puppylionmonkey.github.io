import math


# C = 2πr
def calculate_circumference(r):
    return 2 * math.pi * r


# r = C / (2π)
def calculate_radius(C):
    return C / (2 * math.pi)
