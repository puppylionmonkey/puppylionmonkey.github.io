import re

import numpy as np
import sympy
from sympy.parsing.sympy_parser import convert_xor
from sympy import simplify, oo, limit, preorder_traversal, Symbol, Eq, Rational, Pow, Abs, ConditionSet, FiniteSet, Union, Integral, expand, ln, sec, tan, log, Matrix, solve, summation
from sympy import integrate
from sympy import symbols, diff, solveset, Interval, sympify, lambdify
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application
from sympy import symbols, sympify, diff, limit, sqrt, S

transformations = standard_transformations + (implicit_multiplication_application, convert_xor)


def diff_expression(expr_str):
    expr = parse_expr(expr_str, transformations=transformations)
    free_symbols = list(expr.free_symbols)

    if not free_symbols:
        # 沒有變數，就代表是常數，微分為 0
        return 0

    var = free_symbols[0]
    return diff(expr, var)


def test_diff_expression():
    x = Symbol('x')
    expr_str = '(3x**5 + 4x - 7)**10'
    expected = diff((3 * x ** 5 + 4 * x - 7) ** 10, x)
    result = diff_expression(expr_str)
    assert result == expected, f"Expected: {expected}, but got: {result}"
    expr_str = '(3x**2 + 4x-5)**10'
    print(diff_expression(expr_str))
    print(diff_expression('cos((3x+4)/(2x-1))'))
    print(diff_expression('asin(3x**2-1)'))


def integrate_expression(expr_str):
    expr = parse_expr(expr_str, transformations=transformations)
    free_symbols = list(expr.free_symbols)
    var = free_symbols[0]
    return integrate(expr, var)


def get_variables(expr_str):
    return sorted(set(re.findall(r'[a-zA-Z]', expr_str)))


def implicit_partial_derivative(equation_str, numerator_var: str = 'y', denominator_var: str = 'x'):
    if '=' not in equation_str:
        raise ValueError("請輸入一個等式，例如 '6x - 3y + 15 = 0'")

    left_str, right_str = equation_str.split('=')

    vars_in_eq = get_variables(equation_str)
    if numerator_var not in vars_in_eq or denominator_var not in vars_in_eq:
        raise ValueError(f"等式中必須包含 {numerator_var} 和 {denominator_var} 這兩個變數")

    symbols_dict = {var: symbols(var) for var in vars_in_eq}
    num = symbols_dict[numerator_var]
    denom = symbols_dict[denominator_var]

    left_expr = parse_expr(left_str, local_dict=symbols_dict, transformations=transformations)
    right_expr = parse_expr(right_str, local_dict=symbols_dict, transformations=transformations)
    equation = Eq(left_expr, right_expr)

    F = equation.lhs - equation.rhs
    d_denom = diff(F, denom)
    d_num = diff(F, num)

    result = -d_denom / d_num
    return simplify(result)


def test_implicit_partial_derivative():
    assert implicit_partial_derivative("6x - 3y + 15 = 0", "y", "x") == 2
    assert implicit_partial_derivative("6x - 3y + 15 = 0", "x", "y") == Rational(1, 2)


def implicit_derivative(equation_str: str, var: str = "y", wrt: str = "x", order: int = 1):
    if '=' not in equation_str:
        raise ValueError("請輸入等式，如 4x**2 + 9y**2 = 36")

    left_str, right_str = equation_str.split('=')
    vars_in_eq = get_variables(equation_str)
    if var not in vars_in_eq or wrt not in vars_in_eq:
        raise ValueError(f"公式中需有 {var} 和 {wrt}")

    sym_dict = {v: symbols(v) for v in vars_in_eq}
    x, y = sym_dict[wrt], sym_dict[var]

    left = parse_expr(left_str, local_dict=sym_dict, transformations=transformations)
    right = parse_expr(right_str, local_dict=sym_dict, transformations=transformations)
    F = left - right

    dy_dx = simplify(-diff(F, x) / diff(F, y))

    if order == 1:
        return dy_dx

    elif order == 2:
        dFx = diff(F, x)
        dFy = diff(F, y)
        d2Fx = diff(dFx, x) + diff(dFx, y) * dy_dx
        d2Fy = diff(dFy, x) + diff(dFy, y) * dy_dx
        return simplify((-d2Fx + d2Fy * dy_dx) / dFy)

    else:
        raise NotImplementedError("目前只支援一階和二階微分")


def derivative_of_definite_integral(expr_str: str, lower_limit_str: str, upper_limit_str: str, diff_var_str: str = "x"):
    t = symbols("t")
    x = symbols(diff_var_str)

    f_t = sympify(expr_str)
    lower = sympify(lower_limit_str)
    upper = sympify(upper_limit_str)

    integral_expr = integrate(f_t, (t, lower, upper))
    derivative_result = diff(integral_expr, x)

    return derivative_result


def limit_expression(expr_str: str, approach_to="oo"):
    expr = parse_expr(expr_str, transformations=transformations)
    free_symbols = sorted(expr.free_symbols, key=lambda s: s.name)

    if not free_symbols:
        raise ValueError("無法從表達式中辨識變數")

    var = free_symbols[0]

    # 判斷方向
    dir = "+"
    if approach_to.endswith("+") or approach_to.endswith("-"):
        dir = approach_to[-1]
        approach_val = approach_to[:-1]
    else:
        approach_val = approach_to

    # 解析趨近目標
    if approach_val == "oo":
        point = oo
    elif approach_val == "-oo":
        point = -oo
    else:
        try:
            point = float(approach_val)
        except:
            raise ValueError("無效的趨近值")

    return limit(expr, var, point, dir=dir)


def test_limit_expression():
    print(limit_expression('sin(2x)/3x', approach_to="0"))


def check_continuity_piecewise(pieces, x_val):
    x = symbols('x')
    x_val_str = str(int(x_val)) if x_val == int(x_val) else str(x_val)

    left_expr = right_expr = value_expr = None
    matched_expr = None

    for expr_str, cond_str in pieces:
        expr = parse_expr(expr_str, transformations=transformations)
        cond = cond_str.replace(" ", "")

        # ✅ 處理條件：x!=3 保留，x=3 換成 x==3
        if "!=" in cond:
            cond_eval = cond
        else:
            cond_eval = re.sub(r"(?<=[^<>=!])=(?=[^=])", "==", cond)

        try:
            if eval(cond_eval.replace("x", str(x_val))):
                matched_expr = expr
        except Exception as e:
            print(f"條件解析錯誤：{cond} -> {cond_eval}，錯誤：{e}")
            return False

        # 支援 x!=val 為左右極限來源
        if cond in (f"x<{x_val_str}", f"x<={x_val_str}", f"x!={x_val_str}"):
            if left_expr is None:
                left_expr = expr
        if cond in (f"x>{x_val_str}", f"x>={x_val_str}", f"x!={x_val_str}"):
            if right_expr is None:
                right_expr = expr
        if cond == f"x={x_val_str}":
            value_expr = expr

    # ✅ 若是一般點（非邊界）：有一段定義就算連續
    if value_expr is None and left_expr is None and right_expr is None:
        return matched_expr is not None

    # ❌ 無法判斷極限或函數值 → 不連續
    if left_expr is None or right_expr is None or value_expr is None:
        return False

    # ✅ 計算左右極限與函數值
    x = symbols('x')  # 再次聲明確保作用域一致
    left_limit = limit(left_expr, x, x_val, dir='-')
    right_limit = limit(right_expr, x, x_val, dir='+')
    func_value = value_expr.subs(x, x_val)

    # ✅ 比對是否連續
    return simplify(left_limit - right_limit) == 0 and simplify(left_limit - func_value) == 0


def definite_integral(expr_str: str, lower, upper):
    expr = parse_expr(expr_str, transformations=transformations)
    symbols_set = {s for s in preorder_traversal(expr) if isinstance(s, Symbol)}
    if not symbols_set:
        raise ValueError("無法偵測到變數")
    var = symbols_set.pop()

    result = integrate(expr, (var, lower, upper))
    return result


def calculate_integral_diff(f_str, lower_limit_str, upper_limit_str):
    # 建立符號
    t = sympy.Symbol('t')
    # 轉成 SymPy 表達式
    f_expr = sympy.sympify(f_str)
    a = sympy.sympify(lower_limit_str)
    b = sympy.sympify(upper_limit_str)

    # 偵測變數（除了 t 的其他）
    free_symbols = (f_expr.free_symbols | a.free_symbols | b.free_symbols) - {t}

    if len(free_symbols) != 1:
        raise ValueError("無法自動判斷變數，請確認只有一個變數")

    x = free_symbols.pop()

    # 萊布尼茲法則
    f_b = f_expr.subs(t, b)
    f_a = f_expr.subs(t, a)
    db = sympy.diff(b, x)
    da = sympy.diff(a, x)
    return (f_b * db - f_a * da).simplify()


def test_arctan():
    result = calculate_integral_diff("1 / (1 + t**2)", "1", "x")
    x = sympy.Symbol("x")
    expected = 1 / (1 + x ** 2)
    assert sympy.simplify(result - expected) == 0


def test_poly():
    result = calculate_integral_diff("t**2", "0", "x")
    x = sympy.Symbol("x")
    assert sympy.simplify(result - x ** 2) == 0


def test_variable_limits():
    result = calculate_integral_diff("sin(t)", "x**2", "x**3")
    x = sympy.Symbol("x")
    expected = sympy.sin(x ** 3) * sympy.diff(x ** 3, x) - sympy.sin(x ** 2) * sympy.diff(x ** 2, x)
    assert sympy.simplify(result - expected) == 0


def get_relative_maximum(expr_str: str, a: float, b: float):
    expr = parse_expr(expr_str, transformations=transformations)
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)
    if not free_vars:
        raise ValueError("找不到變數")
    var = free_vars[0]

    # 求導
    derivative = diff(expr, var)

    # 在區間內求臨界點（導數為 0）
    critical_points = solveset(derivative, var, domain=Interval(a, b))

    # 加入端點
    candidates = list(critical_points) + [a, b]

    # 評估 f(x)
    f = lambdify(var, expr, "numpy")
    max_x = None
    max_y = float("-inf")

    for x_val in candidates:
        try:
            y_val = f(x_val)
            if y_val > max_y:
                max_y = y_val
                max_x = x_val
        except:
            continue  # 忽略無法計算的點

    return (max_x, max_y)


def test_get_relative_maximum():
    print(get_relative_maximum("x**3 - 3*x", -2, 2))  # ➜ ( -1.0, 2.0 )
    print(get_relative_maximum("x**2", 0, 5))  # ➜ ( 5.0, 25.0 )
    print(get_relative_maximum("3x+5", 1, 4))  # ➜ ( 4.0, 17.0 )


def get_relative_minimum(expr_str: str, a: float, b: float):
    expr = parse_expr(expr_str, transformations=transformations)
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)
    if not free_vars:
        raise ValueError("找不到變數")
    var = free_vars[0]

    # 一階導數
    derivative = diff(expr, var)

    # 找出區間內導數為 0 的臨界點
    critical_points = solveset(derivative, var, domain=Interval(a, b))

    # 加入端點
    candidates = list(critical_points) + [a, b]

    # 建立函數以計算 f(x)
    f = lambdify(var, expr, modules=["numpy"])
    min_x = None
    min_y = float("inf")

    for x_val in candidates:
        try:
            y_val = f(x_val)
            if y_val < min_y:
                min_y = y_val
                min_x = x_val
        except:
            continue

    return (min_x, min_y)


def test_get_relative_minimum():
    print(get_relative_minimum("x**3 - 3*x", -2, 2))  # ➜ (1.0, -2.0)
    print(get_relative_minimum("x**2", 0, 5))  # ➜ (0.0, 0.0)
    print(get_relative_minimum("3x+5", 1, 4))


def rewrite_fractional_powers(expr):
    """把 x**(a/b) 轉成 Abs(x)**(a/b)，避免負數次方報錯。"""
    if isinstance(expr, Pow):
        base, exp = expr.args
        if exp.is_Rational and exp.q != 1 and base.is_Symbol:
            return Pow(Abs(base), exp)
    if expr.args:
        return expr.func(*[rewrite_fractional_powers(arg) for arg in expr.args])
    return expr


def get_extrema(expr_str: str, a: float, b: float):
    # 解析並重寫分數次方
    expr = parse_expr(expr_str, transformations=transformations)
    expr = rewrite_fractional_powers(expr)

    # 取第一個變數
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)
    if not free_vars:
        raise ValueError("找不到變數")
    var = free_vars[0]

    # 求導並解 f'(x)=0
    derivative = diff(expr, var)
    roots = solveset(derivative, var, domain=Interval(a, b))

    # === 建立候選點 ===
    candidates = [a, b]  # 先放兩端點
    if isinstance(roots, FiniteSet):  # 直接是有限集合
        candidates += list(roots)
    elif isinstance(roots, Union):  # 可能是 Union(FiniteSet, ConditionSet)
        for subset in roots.args:
            if isinstance(subset, FiniteSet):
                candidates += list(subset)
            # ConditionSet 直接忽略
    # 其他回傳型別 (ConditionSet / EmptySet) 也一律忽略

    # === 計算 f(x) 並找極值 ===
    f = lambdify(var, expr, modules=["numpy"])
    max_x = max_y = None
    min_x = min_y = None
    max_y, min_y = float("-inf"), float("inf")

    for x_val in candidates:
        try:
            y_val = f(x_val)
            if y_val > max_y:
                max_x, max_y = x_val, y_val
            if y_val < min_y:
                min_x, min_y = x_val, y_val
        except Exception:
            # 可能因評估失敗 (如 0**(-1/3))，直接略過
            continue

    return {
        "max": (float(max_x), float(max_y)),
        "min": (float(min_x), float(min_y))
    }


def test_get_extrema():
    # 測試 1：x**2 在 [0, 5]
    result = get_extrema("x**2", 0, 5)
    assert result["min"] == (0.0, 0.0)
    assert result["max"] == (5.0, 25.0)

    # 測試 2：-x**2 + 4x - 3 在 [0, 5]
    result = get_extrema("-x**2 + 4*x - 3", 0, 5)
    assert result["min"] == (5.0, -8.0)
    assert result["max"][0] == 2.0 and abs(result["max"][1] - 1.0) < 1e-5

    # 測試 3：x**(2/3) + 1 在 [-2, 1]
    result = get_extrema("x**(2/3) + 1", -2, 1)
    assert result["min"][0] == 0.0 and abs(result["min"][1] - 1.0) < 1e-5
    assert result["max"][0] == -2.0 or result["max"][0] == 1.0  # 端點皆可為最大值候選

    # 測試 4：線性函數 3x + 5 在 [1, 4]
    result = get_extrema("3*x + 5", 1, 4)
    assert result["min"] == (1.0, 8.0)
    assert result["max"] == (4.0, 17.0)

    print("✅ 所有極值測試通過")


def multivariable_limit(expr_str: str, var_limits: dict):
    """
    計算多變數極限。

    Parameters:
        expr_str (str): 表達式字串，例如 "x**2 + y**2"
        var_limits (dict): 要帶入極限的變數與目標值，格式為 {"x": 0, "y": 0}

    Returns:
        sympy 限值結果
    """
    expr = parse_expr(expr_str, transformations=transformations)
    # 多重 limit 嵌套處理：內層變數先處理
    for var, val in reversed(var_limits.items()):
        sym_var = symbols(var)
        expr = limit(expr, sym_var, val)
    return expr


def test_multivariable_limit():
    # 測試極限 lim_{x->0, y->0} (x**2 + y**2)
    result = multivariable_limit("x**2 + y**2", {"x": 0, "y": 0})
    assert result == 0

    # 測試極限 lim_{x->0, y->0} (x*y / (x**2 + y**2))，不同路徑可能不同，應該是不存在
    result = multivariable_limit("x*y / (x**2 + y**2)", {"x": 0, "y": 0})
    print("可能不存在的路徑極限結果（單一路徑）:", result)


def partial_derivative(expr_str: str, diff_vars: str):
    """
    計算偏微分，支援多階與多變數，例如：
    partial_derivative("x**4 + 6*x**3*y**2 + 6*x - 3*y + 5", "x") → fx
    partial_derivative("x**4 + 6*x**3*y**2 + 6*x - 3*y + 5", "xx") → fxx
    partial_derivative("x**4 + 6*x**3*y**2 + 6*x - 3*y + 5", "xy") → fxy
    partial_derivative("x**4 + 6*x**3*y**2 + 6*x - 3*y + 5", "xxy") → ∂³f/∂x²∂y
    """
    expr = parse_expr(expr_str.replace("^", "**"), transformations=transformations)
    free_vars = expr.free_symbols
    var_symbols = {str(v): v for v in free_vars}

    for v in diff_vars:
        if v not in var_symbols:
            raise ValueError(f"找不到變數 {v} 在輸入表達式中")
        expr = diff(expr, var_symbols[v])

    return expr


def test_partial_derivative():
    x, y, z = symbols("x y z")

    assert partial_derivative("x^2 + xy - 3y + 4", "x") == 2 * x + y
    assert partial_derivative("x^2 + xy - 3y + 4", "y") == x - 3
    assert partial_derivative("3xz + 2z^2", "z") == 3 * x + 4 * z
    expr = "x**4 + 6*x**3*y**2 + 6*x - 3*y + 5"
    assert partial_derivative(expr, "xx") == 12 * x ** 2 + 36 * x * y ** 2
    assert partial_derivative(expr, "yy") == 12 * x ** 3
    assert partial_derivative(expr, "xy") == 36 * x ** 2 * y
    assert partial_derivative(expr, "yx") == 36 * x ** 2 * y
    assert partial_derivative('x*ln(y)+z*tan(x)+ye**z', "x") == z * (tan(x) ** 2 + 1) + log(y)


def is_differentiable(expr_str: str, x0: float, y0: float) -> bool:
    x, y, h, k = symbols("x y h k")
    try:
        f = parse_expr(expr_str, transformations=transformations)

        # 偏導數
        fx = diff(f, x)
        fy = diff(f, y)

        # 計算主函數與線性近似的差
        fx0 = fx.subs({x: x0, y: y0})
        fy0 = fy.subs({x: x0, y: y0})

        R = f.subs({x: x0 + h, y: y0 + k}) - f.subs({x: x0, y: y0}) - fx0 * h - fy0 * k
        E = R / sqrt(h ** 2 + k ** 2)

        # 檢查誤差是否趨近於 0
        return limit(limit(E, h, 0), k, 0) == 0
    except:
        return False


def test_is_differentiable():
    assert is_differentiable("x**2 + y**2", 0, 0) == True
    assert is_differentiable("Abs(x*y)", 0, 0) == False  # 非光滑點
    assert is_differentiable("x**4y**5", 1, 2) == True  # 非光滑點


def directional_derivative(f_expr: str, point: tuple, direction: tuple) -> float:
    """
    計算多變數函數在某點沿特定方向的方向導數。

    :param f_expr: 函數字串，例如 "xy + 4x"（支援隱式乘法）
    :param point: 對應變數的點 (如 (1, 3))
    :param direction: 對應方向向量 (如 (3, 4))，會自動轉單位向量
    :return: float，方向導數值
    """
    # 支援隱式乘法（xy → x*y）
    expr = parse_expr(f_expr, transformations=transformations)

    # 自動抓取所有變數，並排序（依字母順序）
    vars_sorted = sorted(expr.free_symbols, key=lambda s: str(s))

    if len(point) != len(vars_sorted) or len(direction) != len(vars_sorted):
        raise ValueError("點與方向向量的維度必須與變數數量一致")

    # 建立梯度向量
    grad = [diff(expr, var) for var in vars_sorted]

    # 單位化方向向量
    mag = sum(d ** 2 for d in direction) ** 0.5
    unit_vec = [d / mag for d in direction]

    # 將變數與點打包為 dict 代入
    subs_dict = {var: val for var, val in zip(vars_sorted, point)}
    grad_at_point = [g.subs(subs_dict) for g in grad]

    # 計算方向導數 = dot(grad, unit_vec)
    directional_value = sum(g * u for g, u in zip(grad_at_point, unit_vec))

    return float(directional_value)


def test_directional_derivative():
    assert directional_derivative("xy + 4x", (1, 3), (3, 4)) == 5.0  # 使用隱式乘法格式
    assert directional_derivative("x*y + z", (1, 2, 3), (0, 0, 1)) == 1.0  # 三變數，z方向導數


def gradient_at_point(expr_str: str, point: dict):
    expr = parse_expr(expr_str, transformations=transformations)

    # 自動偵測所有自由變數，並排序（照名稱順序）
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)

    grad = Matrix([expr.diff(var) for var in free_vars])
    subs_grad = grad.subs(point)
    return subs_grad


def test_gradient_at_point():
    # 測試
    expr_str = "3x + 4x^2y + 6y^2"
    point = {symbols('x'): 1, symbols('y'): 1}
    result = gradient_at_point(expr_str, point)
    assert result == Matrix([[11], [16]])

    expr = "z**2 - 2*x**2 - 2*y**2 - 21"
    point = {symbols('x'): 1, symbols('y'): -1, symbols('z'): 5}
    result = gradient_at_point(expr, point)
    assert result == Matrix([[-4], [4], [10]])


def compute_gradient(expr_str: str):
    """
    計算函數的梯度向量（不代入值），自動偵測所有變數
    """
    expr = parse_expr(expr_str, transformations=transformations)
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)  # 照名稱排序
    grad = Matrix([expr.diff(var) for var in free_vars])
    return grad


def test_compute_gradient():
    expr = "x*y + z**2"
    grad = compute_gradient(expr)
    print(grad)  # Matrix([[y], [x], [2*z]])


def analyze_critical_points(expr_str: str):
    expr = parse_expr(expr_str, transformations=transformations)
    vars = sorted(expr.free_symbols, key=lambda s: s.name)

    if len(vars) == 0:
        raise ValueError("找不到任何變數")

    # 梯度向量
    grad = [diff(expr, v) for v in vars]

    # 臨界點：∇f = 0
    crit_points = solve([Eq(g, 0) for g in grad], vars, dict=True)

    # Hessian 矩陣（符號形式）
    hessian_expr = Matrix([[diff(diff(expr, vi), vj) for vj in vars] for vi in vars])

    results = []

    for pt in crit_points:
        H = hessian_expr.subs(pt)
        det = simplify(H.det())
        trace = simplify(H.trace())

        if det.is_number:
            if det > 0:
                if trace > 0:
                    type_ = "極小值"
                elif trace < 0:
                    type_ = "極大值"
                else:
                    type_ = "無法判斷"
            elif det < 0:
                type_ = "鞍點"
            else:
                type_ = "無法判斷"
        else:
            type_ = "無法判斷"

        results.append({
            "point": pt,
            "hessian": H,
            "det": det,
            "trace": trace,
            "type": type_,
        })

    return results


def test_analyze_critical_points():
    results = analyze_critical_points("3*x*y**2 - 2*x**2*y + 36*x*y")
    print(results)
    for r in results:
        print(f"\n臨界點: {r['point']}")
        print(f"類型: {r['type']}")
        print(f"Hessian:\n{r['hessian']}")
        print(f"行列式: {r['det']}, 跡: {r['trace']}")


def evaluate_absolute_extrema(expr_str: str, points: list[dict]):
    expr = parse_expr(expr_str, transformations=transformations)

    # 自動偵測變數
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)

    # 計算每個點的函數值
    evaluated = []
    for pt in points:
        # 將所有變數都補齊（即使沒給值）
        subs_dict = {var: pt.get(var, 0) for var in free_vars}
        val = expr.subs(subs_dict).evalf()
        evaluated.append((subs_dict, val))

    # 求最大最小值
    max_pt = max(evaluated, key=lambda t: t[1])
    min_pt = min(evaluated, key=lambda t: t[1])

    return {
        "all": evaluated,  # 每個點及其值
        "max": max_pt,  # 最大值點與值
        "min": min_pt,  # 最小值點與值
    }


def test_evaluate_absolute_extrema():
    x, y = symbols("x y")

    points = [
        {x: 0, y: 0},
        {x: 4, y: 0},
        {x: 0, y: 5},
    ]

    result = evaluate_absolute_extrema("3*x*y - 6*x - 3*y + 5", points)

    for pt, val in result["all"]:
        print(f"點 {pt} → f = {val}")

    print(f"✅ 最大值: {result['max']}")
    print(f"✅ 最小值: {result['min']}")


def optimize_with_constraints(objective_str: str, equality_constraints: list[str], inequality_constraints: list[str]):
    # 解析目標函數與所有條件
    expr = parse_expr(objective_str, transformations=transformations)
    all_constraint_exprs = [
        parse_expr(c.split("=")[0], transformations=transformations) - parse_expr(c.split("=")[1], transformations=transformations)
        for c in equality_constraints
    ]
    all_ineqs = [parse_expr(c, transformations=transformations) for c in inequality_constraints]

    # 找出所有變數
    all_vars = sorted(expr.free_symbols.union(*[e.free_symbols for e in all_constraint_exprs + all_ineqs]), key=lambda s: s.name)

    # 若只有一個等式約束，嘗試代入簡化
    subs_expr = expr
    subs_vars = all_vars

    if len(equality_constraints) == 1:
        eq = all_constraint_exprs[0]
        main_var = list(eq.free_symbols)[0]  # 拿一個變數來解
        try:
            solved = solveset(Eq(eq, 0), main_var)
            if solved.is_FiniteSet:
                solved_val = list(solved)[0]
                subs_expr = expr.subs(main_var, solved_val)
                subs_vars = [v for v in all_vars if v != main_var]
                all_ineqs = [i.subs(main_var, solved_val) for i in all_ineqs]
            else:
                raise ValueError("無法從等式中解出變數")
        except:
            raise ValueError("無法處理等式條件")

    # 確保是單變數情況
    if len(subs_vars) != 1:
        raise NotImplementedError("目前僅支援單變數條件分析")

    var = subs_vars[0]

    # 從不等式中找出變數區間
    domain = Interval(-1000, 1000)  # 預設極大區間
    for ineq in all_ineqs:
        if ineq.has(var):
            if ineq.rel_op == '>=':
                domain = domain.intersect(Interval(ineq.rhs, float('inf')))
            elif ineq.rel_op == '<=':
                domain = domain.intersect(Interval(float('-inf'), ineq.rhs))

    # 用 numpy 搜尋極值（近似法）
    f_lambdified = lambdify(var, subs_expr, modules=["numpy"])
    x_vals = np.linspace(float(domain.start), float(domain.end), 1000)
    y_vals = f_lambdified(x_vals)

    max_idx = np.argmax(y_vals)
    min_idx = np.argmin(y_vals)

    return {
        "max": (round(x_vals[max_idx], 5), round(y_vals[max_idx], 5)),
        "min": (round(x_vals[min_idx], 5), round(y_vals[min_idx], 5)),
    }


def test_constrained_optimal_value():
    x, y = symbols("x y")
    f = parse_expr("1 - 2*x**2 - y**2")

    result = optimize_with_constraints(
        "1 - 2*x**2 - y**2",
        ["x + y = 1"],
        ["x >= 0", "y >= 0"]
    )

    max_pt = result["max"][0]
    min_pt = result["min"][0]

    f_max = f.subs({x: max_pt, y: 1 - max_pt}).evalf()
    f_min = f.subs({x: min_pt, y: 1 - min_pt}).evalf()

    assert abs(f_max - 1 / 3) < 1e-3
    assert abs(f_min - -1.0) < 1e-3


def multiple_integral(expr_str: str, limits: list[tuple[str, str, str]]):
    expr = parse_expr(expr_str, transformations=transformations)
    limits_sympy = [
        (symbols(var), parse_expr(lower, transformations=transformations), parse_expr(upper, transformations=transformations))
        for var, lower, upper in limits
    ]
    return integrate(expr, *limits_sympy).doit()


def test_multiple_integral():
    # 支援省略乘號的輸入
    result1 = multiple_integral("2y + 4x", [("y", "x**2", "2x"), ("x", "0", "1")])
    assert result1 == Rational(14, 5)

    result2 = multiple_integral("xy*z", [
        ("z", "0", "x+y"),
        ("y", "0", "1"),
        ("x", "0", "1")
    ])
    assert result2 == Rational(17, 72)
    result = multiple_integral("exp(y**2)", [("y", "2*x", "4"), ("x", "0", "2")])
    print(result)  # 預期: (1/4)*(e**16 - 1)


def infinite_series_sum(expr_str: str, start: int = 1):
    expr = parse_expr(expr_str, transformations=transformations)

    free_vars = list(expr.free_symbols)
    if len(free_vars) != 1:
        raise ValueError(f"需要唯一變數，但發現：{[str(v) for v in free_vars]}")

    var = free_vars[0]
    result = summation(expr, (var, start, oo))
    is_convergent = not (result.has(oo) or result.has('nan'))

    return result, is_convergent


def test_infinite_series_sum():
    r1, c1 = infinite_series_sum("(3**k + 2**k)/(4**k)")
    assert c1 and abs(float(r1) - 4) < 1e-10

    r2, c2 = infinite_series_sum("3k/2**k")
    assert c2 and abs(float(r2) - 6) < 1e-10

    r3, c3 = infinite_series_sum("k")
    assert not c3  # ∑ k 發散

    print("所有測試通過 ✅")
    print("結果範例：")
    print("→ 收斂：", r1)
    print("→ 發散：", r3)



