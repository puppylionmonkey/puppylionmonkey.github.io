from sympy import Eq, solve
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application, convert_xor

from functions.language_dict_functions import get_language


def solve_equation_list(equations: list[str]) -> str:
    transformations = standard_transformations + (implicit_multiplication_application, convert_xor)
    lang = get_language()
    value_error_text = "每行必須包含 '=' 符號" if lang == 'zh' else "Each line must contain an '=' sign"
    answer_text = '解' if lang == 'zh' else 'Answer'
    no_answer_text = '找不到解。' if lang == 'zh' else 'No answer'
    error_text = '錯誤' if lang == 'zh' else 'Error'
    try:
        all_vars = set()
        equation_list = list()

        for line in equations:
            if '=' in line:
                left, right = line.split('=')
                left_expr = parse_expr(left.strip(), transformations=transformations)
                right_expr = parse_expr(right.strip(), transformations=transformations)
                equation_list.append(Eq(left_expr, right_expr))
                all_vars.update(left_expr.free_symbols)
                all_vars.update(right_expr.free_symbols)
            else:
                raise ValueError(value_error_text)

        vars = list(all_vars)
        solution = solve(equation_list, vars, dict=True)
        result_str = f"{answer_text}：\n"
        for sol_dict in solution:
            result_str += "".join([
                f"{symbol} = {value.evalf()}\n" if 'Integer' not in str(type(value)) else f"{symbol} = {value}\n"
                for symbol, value in sol_dict.items()
            ])
            result_str += '\n\n'
        return result_str if solution else no_answer_text
    except Exception as ex:
        return f"{error_text}：{str(ex)}"
