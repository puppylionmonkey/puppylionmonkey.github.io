from functions.unit_functions import ureg
import math


# V = (4/3)πr³
def calculate_volume(r):
    return (4 / 3) * math.pi * r ** 3


# r = (3V / 4π)^(1/3)
def calculate_radius(V):
    return ((3 * V) / (4 * math.pi)) ** (1 / 3)
