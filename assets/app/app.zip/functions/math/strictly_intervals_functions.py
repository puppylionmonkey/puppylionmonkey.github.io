from sympy import symbols, diff
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application
from sympy import Union, Interval
from sympy.sets.sets import EmptySet
from sympy.solvers.inequalities import solve_univariate_inequality

# 支援像 "3x + 5" 的隱式乘法
transformations = standard_transformations + (implicit_multiplication_application,)


def get_strictly_increasing_intervals(expr_str):
    expr = parse_expr(expr_str, transformations=transformations)
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)
    if not free_vars:
        return EmptySet()
    var = free_vars[0]

    derivative = diff(expr, var)

    # 解導數 > 0 的區域（區間格式）
    interval_set = solve_univariate_inequality(derivative > 0, var, relational=False)
    return interval_set


def get_strictly_decreasing_intervals(expr_str):
    expr = parse_expr(expr_str, transformations=transformations)
    free_vars = sorted(expr.free_symbols, key=lambda s: s.name)

    if not free_vars:
        # 常數函數：沒有遞減區間
        return EmptySet()

    var = free_vars[0]
    derivative = diff(expr, var)

    # 解導數 < 0（嚴格遞減區間）
    return solve_univariate_inequality(derivative < 0, var, relational=False)


def test_get_strictly_increasing_intervals():
    assert get_strictly_increasing_intervals("3x + 5") == Interval.open(-float('inf'), float('inf'))
    assert get_strictly_increasing_intervals("x**3 - 3*x") == Union(Interval.open(-float('inf'), -1), Interval.open(1, float('inf')))
    assert get_strictly_increasing_intervals("x**2 - 4x + 3") == Interval.open(2, float('inf'))
    assert get_strictly_increasing_intervals("5") == EmptySet()
    print("✅ 所有測試通過")


def test_get_strictly_decreasing_intervals():
    assert get_strictly_decreasing_intervals("3x + 5") == EmptySet()
    assert get_strictly_decreasing_intervals("x**3 - 3*x") == Interval.open(-1, 1)
    assert get_strictly_decreasing_intervals("x**2 - 4x + 3") == Interval.open(-float('inf'), 2)
    assert get_strictly_decreasing_intervals("5") == EmptySet()
    print("✅ 嚴格遞減測試通過")
