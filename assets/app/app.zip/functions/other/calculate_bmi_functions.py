from functions.unit_functions import *


def calculate_bmi(weight_ureg, height_ureg):
    weight_kg = weight_ureg.to(ureg.kg)
    height_m = height_ureg.to(ureg.m)
    bmi = weight_kg / (height_m ** 2)
    return bmi.magnitude  # 無單位


def calculate_weight(bmi, height_ureg):
    height_m = height_ureg.to(ureg.m)
    weight = bmi * (height_m ** 2)
    return weight.magnitude * ureg.kg


def calculate_height(bmi, weight_ureg):
    weight_kg = weight_ureg.to(ureg.kg)
    height = (weight_kg / bmi) ** 0.5
    return height.magnitude * ureg.m


# BMI 分類
def classify_bmi(bmi):
    bmi_value = bmi.magnitude  # 去除單位，方便分類
    if bmi_value < 18.5:
        return "過輕"
    elif bmi_value < 24:
        return "正常"
    elif bmi_value < 27:
        return "過重"
    elif bmi_value < 30:
        return "輕度肥胖"
    elif bmi_value < 35:
        return "中度肥胖"
    else:
        return "重度肥胖"
