import datetime


def timestamp_to_datetime(ts):
    return datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')


def calculate_timestamp(year: int, month: int, day: int, hour: int, minute: int, second: int) -> int:
    dt = datetime.datetime(year, month, day, hour, minute, second)
    return int(dt.timestamp())
