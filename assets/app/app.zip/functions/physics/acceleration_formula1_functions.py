from functions.unit_functions import *


# 經典運動方程式：v = v_0 + a·t
def calculate_velocity(v_0, a, t):
    return v_0 + a * t


def calculate_initial_velocity(v, a, t):
    return v - a * t


def calculate_acceleration(v, v_0, t):
    return (v - v_0) / t


def calculate_time(v, v_0, a):
    return (v - v_0) / a
