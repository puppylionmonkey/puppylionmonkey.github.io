from sympy import symbols, solve

from functions.unit_functions import *


# 經典運動方程式：x = V₀t + 1/2·a·t²
def calculate_displacement(v_0, t, a):
    return v_0 * t + 0.5 * a * t ** 2


def calculate_initial_velocity(x, t, a):
    return ((x - 0.5 * a * t ** 2) / t).to('m/s^2')


def calculate_acceleration(x, v_0, t):
    return 2 * (x - v_0 * t) / t ** 2


def calculate_time(x, v_0, a):
    t_symbol = symbols('t', real=True, positive=True)
    x = x.to('m')
    v_0 = v_0.to('m/s')
    a = a.to('m/s^2')
    eq = v_0.magnitude * t_symbol + 0.5 * a.magnitude * t_symbol ** 2 - x.magnitude
    solutions = solve(eq, t_symbol)
    # 取正數解
    for sol in solutions:
        if sol.is_real and sol > 0:
            return float(sol) * ureg.s
    raise ValueError("No valid positive real solution for time.")
