from functions.unit_functions import *


# 經典運動方程式：V² = V₀² + 2·a·x
def calculate_final_velocity(V_0, a, x):
    return (V_0 ** 2 + 2 * a * x) ** 0.5


def calculate_initial_velocity(V, a, x):
    return (V ** 2 - 2 * a * x) ** 0.5


def calculate_acceleration(V, V_0, x):
    return (V ** 2 - V_0 ** 2) / (2 * x)


def calculate_displacement(V, V_0, a):
    return (V ** 2 - V_0 ** 2) / (2 * a)
