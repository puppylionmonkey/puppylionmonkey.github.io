from functions.unit_functions import *


# ω = θ/t

def calculate_angular_velocity(theta_ureg, time_ureg):
    return (theta_ureg / time_ureg).to(ureg.radian / ureg.second)


def calculate_angular_displacement(omega_ureg, time_ureg):
    return (omega_ureg * time_ureg).to(ureg.radian)


def calculate_time(omega_ureg, theta_ureg):
    return (theta_ureg / omega_ureg).to(ureg.second)
