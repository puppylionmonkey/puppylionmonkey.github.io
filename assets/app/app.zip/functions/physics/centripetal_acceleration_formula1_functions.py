from functions.unit_functions import *


# 向心加速度公式：a_c = v² / r
def calculate_centripetal_acceleration(v, r):
    return v ** 2 / r


def calculate_velocity(a_c, r):
    return (a_c * r) ** 0.5


def calculate_radius(a_c, v):
    return v ** 2 / a_c
