from functions.unit_functions import *


# 向心加速度公式：a = r · ω²
def calculate_centripetal_acceleration(r, omega):
    return r * omega ** 2


def calculate_radius(a, omega):
    return a / (omega ** 2)


def calculate_angular_velocity(a, r):
    return (a / r) ** 0.5
