from functions.unit_functions import *

# F = kq1q2/(r**2)

coulomb_law_constant = 8.9875 * 10 ** 9 * ureg.newton * ureg.meter ** 2 / ureg.coulomb ** 2
k = coulomb_law_constant


def calculate_force(q1_ureg, q2_ureg, length_ureg):
    return k * q1_ureg.to(ureg.C) * q2_ureg.to(ureg.C) / (length_ureg.to(ureg.m) ** 2)


def calculate_q1(force_ureg, q2_ureg, length_ureg):
    return force_ureg * (length_ureg.to(ureg.m) ** 2) / (q2_ureg.to(ureg.C) * k)


def calculate_q2(force_ureg, q1_ureg, length_ureg):
    return force_ureg * (length_ureg.to(ureg.m) ** 2) / (q1_ureg.to(ureg.C) * k)


def calculate_r(force_ureg, q1_ureg, q2_ureg):
    return pow(k * q1_ureg.to(ureg.C) * q2_ureg.to(ureg.C) / force_ureg, 1 / 2)
