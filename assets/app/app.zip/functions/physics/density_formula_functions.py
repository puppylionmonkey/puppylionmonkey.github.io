from functions.unit_functions import ureg


# 密度公式：ρ = m / V
def calculate_density(mass, volume):
    return mass / volume


# 質量公式：m = ρ × V
def calculate_mass(density, volume):
    return density * volume


# 體積公式：V = m / ρ
def calculate_volume(density, mass):
    return mass / density
