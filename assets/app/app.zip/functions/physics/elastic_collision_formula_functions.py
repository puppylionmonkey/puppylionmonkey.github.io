from functions.unit_functions import *


# m1·v1 + m2·v2 = m1·v1' + m2·v2'
def calculate_v1_after(m1, m2, v1, v2, v2_after):
    return ((m1 * v1 + m2 * v2) - m2 * v2_after) / m1


# solve for v2'
def calculate_v2_after(m1, m2, v1, v2, v1_after):
    return ((m1 * v1 + m2 * v2) - m1 * v1_after) / m2


def calculate_v1_before(m1, m2, v2, v1_after, v2_after):
    return ((m1 * v1_after + m2 * v2_after) - m2 * v2) / m1


def calculate_v2_before(m1, m2, v1, v2_after, v1_after):
    return ((m1 * v1_after + m2 * v2_after) - m1 * v1) / m2


def calculate_m1(m2, v1, v2, v1_after, v2_after):
    numerator = m2 * (v2 - v2_after)
    denominator = v1_after - v1
    return numerator / denominator


def calculate_m2(m1, v1, v2, v1_after, v2_after):
    numerator = m1 * (v1_after - v1)
    denominator = v2 - v2_after
    return numerator / denominator
