# F = q(E + v×B)
def calculate_force(q_ureg, E_ureg, v_ureg, B_ureg):
    return q_ureg * (E_ureg.to_base_units() + v_ureg.to_base_units() * B_ureg.to_base_units())


def calculate_electric_quantity(f_ureg, E_ureg, v_ureg, B_ureg):
    return f_ureg.to_base_units() / (E_ureg.to_base_units() + v_ureg.to_base_units() * B_ureg.to_base_units())


def calculate_electric_field_strength(f_ureg, q_ureg, v_ureg, B_ureg):
    return f_ureg.to_base_units() / q_ureg.to_base_units() - v_ureg.to_base_units() * B_ureg.to_base_units()


def calculate_velocity(f_ureg, q_ureg, E_ureg, B_ureg):
    return (f_ureg.to_base_units() / q_ureg.to_base_units() - E_ureg.to_base_units()) / B_ureg.to_base_units()


def calculate_magnetic_field(f_ureg, q_ureg, E_ureg, v_ureg):
    return (f_ureg.to_base_units() / q_ureg.to_base_units() - E_ureg.to_base_units()) / v_ureg.to_base_units()
