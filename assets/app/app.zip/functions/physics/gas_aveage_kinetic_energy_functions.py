from functions.unit_functions import ureg

k_B = 1.380649 * 10 ** -23 * ureg.joule / ureg.kelvin  # 玻爾茲曼常數
k_B.to_base_units()


# 單一分子平均動能：E = (3/2) * k * T
def calculate_average_energy(T):
    return (3 / 2) * k_B * T.to('K')


def calculate_temperature(E):
    return E / ((3 / 2) * k_B)
