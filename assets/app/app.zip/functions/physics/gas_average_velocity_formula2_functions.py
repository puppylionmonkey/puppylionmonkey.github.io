from functions.unit_functions import ureg

R = 8.314462618 * ureg.joule / (ureg.mole * ureg.kelvin)  # 氣體常數


# (1/2) M v² = (3/2) R T → v = sqrt(3RT / M)
def calculate_velocity(M, T):
    return ((3 * R * T.to('K')) / M) ** 0.5


def calculate_temperature(v, M):
    return (M * v ** 2) / (3 * R)


def calculate_molar_mass(v, T):
    return (3 * R * T.to('K')) / v ** 2
