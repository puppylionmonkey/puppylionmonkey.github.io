from functions.unit_functions import ureg

k_B = 1.380649 * 10 ** -23 * ureg.joule / ureg.kelvin  # 玻爾茲曼常數
k_B.to_base_units()


# (1/2)mv² = (3/2)kT → v = sqrt(3kT / m)
def calculate_velocity(m, T):
    return ((3 * k_B * T.to('K')) / m) ** 0.5


def calculate_temperature(v, m):
    return (m * v ** 2) / (3 * k_B)


def calculate_mass(v, T):
    return (3 * k_B * T.to('K')) / v ** 2
