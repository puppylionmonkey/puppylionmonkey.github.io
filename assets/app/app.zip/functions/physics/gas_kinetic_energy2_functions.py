from functions.unit_functions import ureg

R = 8.314462618 * ureg.joule / (ureg.mole * ureg.kelvin)  # 氣體常數


# E = (3/2) * n * R * T
def calculate_internal_energy(n, T):
    return (3 / 2) * n * R * T.to('K')


def calculate_temperature(E, n):
    return E / ((3 / 2) * n * R)


def calculate_mole(E, T):
    return E / ((3 / 2) * R * T.to('K'))
