from functions.unit_functions import ureg

k_B = 1.380649 * 10 ** -23 * ureg.joule / ureg.kelvin  # 玻爾茲曼常數
k_B.to_base_units()


# E = (3/2) * N * k * T
def calculate_internal_energy(N, T):
    return (3 / 2) * N * k_B * T.to('K')


def calculate_temperature(E, N):
    return E / ((3 / 2) * N * k_B)


def calculate_molecule_count(E, T):
    return E / ((3 / 2) * k_B * T.to('K'))
