from functions.unit_functions import *


# F ≈ N·m·V² / L
def calculate_force(N, m, V, L):
    return N * m * V ** 2 / L


def calculate_average_velocity(F, N, m, L):
    return ((F * L) / (N * m)) ** 0.5


def calculate_mass(F, N, V, L):
    return F * L / (N * V ** 2)


def calculate_length(F, N, m, V):
    return N * m * V ** 2 / F


def calculate_molecule_count(F, m, V, L):
    return F * L / (m * V ** 2)
