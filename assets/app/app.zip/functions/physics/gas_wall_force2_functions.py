from functions.unit_functions import *


# F = N·m·V² / 3L
def calculate_force(N, m, V, L):
    return N * m * V ** 2 / (3 * L)


def calculate_velocity(F, N, m, L):
    return ((3 * F * L) / (N * m)) ** 0.5


def calculate_mass(F, N, V, L):
    return 3 * F * L / (N * V ** 2)


def calculate_length(F, N, m, V):
    return N * m * V ** 2 / (3 * F)


def calculate_molecule_count(F, m, V, L):
    return 3 * F * L / (m * V ** 2)
