from functions.unit_functions import *


# 三維平均速度下的壓力公式
# P = (1/3) * N·m·V² / V
def calculate_pressure(N, m, V, volume):
    return N * m * V ** 2 / (3 * volume)


def calculate_velocity(P, N, m, volume):
    return ((3 * P * volume) / (N * m)) ** 0.5


def calculate_mass(P, N, V, volume):
    return 3 * P * volume / (N * V ** 2)


def calculate_volume(P, N, m, V):
    return N * m * V ** 2 / (3 * P)


def calculate_molecule_count(P, m, V, volume):
    return 3 * P * volume / (m * V ** 2)
