# 充量公式：J = F · t
def calculate_impulse(F, t):
    return F * t


def calculate_force(J, t):
    return J / t


def calculate_time(J, F):
    return J / F
