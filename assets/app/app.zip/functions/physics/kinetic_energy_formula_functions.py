# E = 1/2*m*v**2
def calculate_energy(mass_ureg, v_ureg):
    return 1 / 2 * mass_ureg * v_ureg ** 2


def calculate_mass(energy_ureg, v_ureg):
    return energy_ureg * 2 / v_ureg ** 2


def calculate_velocity(energy_ureg, mass_ureg):
    return abs(pow(energy_ureg * 2 / mass_ureg, 1 / 2))
