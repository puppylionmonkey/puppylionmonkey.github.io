from functions.unit_functions import *  # Assuming you have 'unit_functions' to handle units

c = light_speed


# E = mc^2
def calculate_energy(mass_ureg):
    return (mass_ureg.to(ureg.kg) * c ** 2).to(ureg.J)


def calculate_mass(energy_ureg):
    return energy_ureg / (c ** 2)
