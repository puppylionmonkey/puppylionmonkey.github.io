# 動量公式：p = m · v
def calculate_momentum(m, v):
    return m * v


def calculate_mass(p, v):
    return p / v


def calculate_velocity(p, m):
    return p / m
