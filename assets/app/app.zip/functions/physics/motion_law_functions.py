from functions.unit_functions import *


def calculate_force(mass_ureg, acceleration_ureg):
    return (mass_ureg.to(ureg.kg) * acceleration_ureg).to(ureg.N)


def calculate_mass(force_ureg, acceleration_ureg):
    return force_ureg / acceleration_ureg


def calculate_acceleration(force_ureg, mass_ureg):
    return force_ureg / mass_ureg.to(ureg.kg)
