# V = I * R
def calculate_voltage(I, R):
    return I * R


# I = V / R
def calculate_current(V, R):
    return V / R


# R = V / I
def calculate_resistance(V, I):
    return V / I
