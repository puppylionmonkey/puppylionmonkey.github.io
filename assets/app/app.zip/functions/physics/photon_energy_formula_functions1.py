from functions.unit_functions import *

h = 6.626 * 10 ** -34 * ureg.J * ureg.s


def calculate_energy(f_ureg):
    return f_ureg * h


def calculate_frequency(e_ureg):
    return e_ureg / h
