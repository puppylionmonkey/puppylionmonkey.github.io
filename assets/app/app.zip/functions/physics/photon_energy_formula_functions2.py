from functions.unit_functions import *

h = 6.626 * 10 ** -34 * ureg.J * ureg.s
c = 3 * 10 ** 8 * ureg.m / ureg.s


# E = hc/λ

def calculate_energy(w_ureg):
    return h * c / w_ureg


def calculate_wavelength(e_ureg):
    return h * c / e_ureg
