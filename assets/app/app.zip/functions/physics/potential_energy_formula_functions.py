# U = m * g * h
from functions.unit_functions import *

g = gravitational_acceleration


def calculate_energy(mass_ureg, h_ureg):
    return mass_ureg * g * h_ureg


def calculate_mass(U_ureg, h_ureg):
    return U_ureg / (g * h_ureg)


def calculate_height(U_ureg, mass_ureg):
    return U_ureg / (mass_ureg * g)
