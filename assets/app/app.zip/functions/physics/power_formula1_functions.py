from functions.unit_functions import *


def calculate_power(work_ureg, time_ureg):
    return (work_ureg / time_ureg).to(ureg.watt)


def calculate_work(power_ureg, time_ureg):
    return (power_ureg * time_ureg).to(ureg.joule)


def calculate_time(power_ureg, work_ureg):
    return (work_ureg / power_ureg).to(ureg.s)
