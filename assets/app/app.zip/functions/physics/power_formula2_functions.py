from functions.unit_functions import *


def calculate_power(force_ureg, velocity_ureg):
    return (force_ureg * velocity_ureg).to(ureg.watt)


def calculate_force(power_ureg, velocity_ureg):
    return (power_ureg / velocity_ureg).to(ureg.newton)


def calculate_velocity(power_ureg, force_ureg):
    return (power_ureg / force_ureg).to(ureg.meter / ureg.second)
