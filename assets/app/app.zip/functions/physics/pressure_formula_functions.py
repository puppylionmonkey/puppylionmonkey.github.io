def calculate_pressure(F, A):
    return F / A


def calculate_force(P, A):
    return P * A


def calculate_area(P, F):
    return F / P
