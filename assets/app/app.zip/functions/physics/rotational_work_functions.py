from functions.unit_functions import ureg


# W = T × θ
def calculate_rotational_work(torque, angle):
    return torque * angle


# T = W / θ
def calculate_torque(work, angle):
    return work / angle


# θ = W / T
def calculate_angle(work, torque):
    return work / torque
