from functions.unit_functions import *


# v = 331 + 0.6 * T（T 是攝氏溫度）
def calculate_sound_speed_simple(T_celsius):
    return 331 + 0.6 * T_celsius


# T = (v - 331) / 0.6
def calculate_temperature_from_speed_simple(v):
    return (v - 331) / 0.6
