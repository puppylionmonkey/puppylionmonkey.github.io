from functions.unit_functions import *


def calculate_linear_speed(radius_ureg, omega_ureg):
    return (radius_ureg * omega_ureg).to(ureg.meter / ureg.second)


def calculate_radius(v_ureg, omega_ureg):
    return (v_ureg / omega_ureg).to(ureg.meter)


def calculate_angular_velocity_from_linear_speed(v_ureg, radius_ureg):
    return (v_ureg / radius_ureg).to(ureg.radian / ureg.second)
