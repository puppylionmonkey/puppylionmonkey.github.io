from functions.unit_functions import *
import math


# v = 2πr / T
def calculate_velocity(radius_ureg, period_ureg):
    return (2 * math.pi * radius_ureg / period_ureg).to(ureg.meter / ureg.second)


def calculate_period(v_ureg, radius_ureg):
    return (2 * math.pi * radius_ureg / v_ureg).to(ureg.second)


def calculate_radius(v_ureg, period_ureg):
    return (v_ureg * period_ureg / (2 * math.pi)).to(ureg.meter)
