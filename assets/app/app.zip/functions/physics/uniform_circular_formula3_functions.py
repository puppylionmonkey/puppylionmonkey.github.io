from functions.unit_functions import *
import math


# v = 2πrf
def calculate_velocity(radius_ureg, frequency_ureg):
    return (2 * math.pi * radius_ureg * frequency_ureg).to(ureg.meter / ureg.second)


# f = v / (2πr)
def calculate_frequency(v_ureg, radius_ureg):
    return (v_ureg / (2 * math.pi * radius_ureg)).to(ureg.hertz)


# r = v / (2πf)
def calculate_radius(v_ureg, frequency_ureg):
    return (v_ureg / (2 * math.pi * frequency_ureg)).to(ureg.meter)
