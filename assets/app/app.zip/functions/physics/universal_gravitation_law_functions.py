from functions.unit_functions import *
from functions.unit_functions import ureg

# F = Gm1m2/(r**2)

universal_gravitation_law_constant = 6.6 * 10 ** -11 * ureg.m ** 3 * ureg.kg ** -1 * ureg.s ** -2
G = universal_gravitation_law_constant


def calculate_force(m1_ureg, m2_ureg, length_ureg):
    return G * m1_ureg * m2_ureg / (length_ureg ** 2)


def calculate_mass1(force_ureg, m2_ureg, length_ureg):
    return force_ureg * (length_ureg ** 2) / (m2_ureg * G)


def calculate_mass2(force_ureg, m1_ureg, length_ureg):
    return force_ureg * (length_ureg ** 2) / (m1_ureg * G)


def calculate_r(force_ureg, m1_ureg, m2_ureg):
    return pow(G * m1_ureg * m2_ureg / force_ureg, 1 / 2)
