from functions.unit_functions import *


# v = f * λ

def calculate_speed(f_ureg, length_ureg):
    return f_ureg.to_base_units() * length_ureg.to_base_units()


def calculate_frequency(v_ureg, length_ureg):
    return v_ureg.to_base_units() / length_ureg.to_base_units()


def calculate_wavelength(v_ureg, f_ureg):
    return v_ureg.to_base_units() / f_ureg.to_base_units()
