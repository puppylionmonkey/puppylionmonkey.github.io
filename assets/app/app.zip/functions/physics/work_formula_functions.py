import math
from functions.unit_functions import ureg


# W = F * d * cos(theta)
def calculate_work(force_ureg, displacement_ureg, theta_deg=0):
    theta_rad = math.radians(theta_deg)
    return (force_ureg * displacement_ureg * math.cos(theta_rad)).to('J')


def calculate_force(work_ureg, displacement_ureg, theta_deg=0):
    theta_rad = math.radians(theta_deg)
    return (work_ureg / (displacement_ureg * math.cos(theta_rad))).to('N')


def calculate_displacement(work_ureg, force_ureg, theta_deg=0):
    theta_rad = math.radians(theta_deg)
    return (work_ureg / (force_ureg * math.cos(theta_rad))).to('m')


def calculate_theta(work_ureg, force_ureg, displacement_ureg):
    cos_theta = work_ureg / (force_ureg * displacement_ureg)
    cos_theta = max(-1, min(1, cos_theta))
    theta_rad = math.acos(cos_theta)
    return math.degrees(theta_rad)
