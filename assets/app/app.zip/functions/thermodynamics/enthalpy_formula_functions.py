from functions.unit_functions import *


def calculate_enthalpy(U, P, V):
    return (U.to(ureg.joule) + (P.to(ureg.pascal) * V.to(ureg.meter ** 3))).to(ureg.joule)


def calculate_internal_energy(H, P, V):
    return (H.to(ureg.joule) - (P.to(ureg.pascal) * V.to(ureg.meter ** 3))).to(ureg.joule)


def calculate_pressure(H, U, V):
    return ((H.to(ureg.joule) - U.to(ureg.joule)) / V.to(ureg.meter ** 3)).to(ureg.pascal)


def calculate_volume(H, U, P):
    return ((H.to(ureg.joule) - U.to(ureg.joule)) / P.to(ureg.pascal)).to(ureg.meter ** 3)
