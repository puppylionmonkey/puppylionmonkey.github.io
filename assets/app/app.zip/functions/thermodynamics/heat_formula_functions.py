# Q = mcdT
from functions.unit_functions import ureg


def calculate_heat(m, delta_T, c):
    return m * c * delta_T.to('K')


def calculate_mass(Q, delta_T, c):
    return Q / (c * delta_T.to('K'))


def calculate_temperature_change(Q, m, c):
    return Q / (m * c)

