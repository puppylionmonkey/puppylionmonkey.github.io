from functions.unit_functions import ureg

# PV=nRT
gas_constant = 8.314462618 * ureg.J / (ureg.mole * ureg.K)
gas_constant2 = gas_constant.to(ureg.L * ureg.atm / (ureg.mole * ureg.K))
R = gas_constant


def calculate_pressure(volume_ureg, number_ureg, temperature_ureg):
    return number_ureg * temperature_ureg.to(ureg.K) * R / volume_ureg.to(ureg.L)


def calculate_volume(pressure_ureg, number_ureg, temperature_ureg):
    return number_ureg * temperature_ureg.to(ureg.K) * R / pressure_ureg.to(ureg.atm)


def calculate_number(pressure_ureg, volume_ureg, temperature_ureg):
    return pressure_ureg.to(ureg.atm) * volume_ureg.to(ureg.L) / (R * temperature_ureg.to(ureg.K))


def calculate_temperature(pressure_ureg, volume_ureg, number_ureg):
    return pressure_ureg.to(ureg.atm) * volume_ureg.to(ureg.L) / (R * number_ureg)

