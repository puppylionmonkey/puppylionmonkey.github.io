from sympy import symbols, solve

from functions.unit_functions import ureg

# (P+an²/V²)(V-nb) = nRT
gas_constant = 8.314462618 * ureg.J / (ureg.mole * ureg.K)
gas_constant2 = gas_constant.to(ureg.L * ureg.atm / (ureg.mole * ureg.K))
R = gas_constant2


def calculate_a(Tc, Pc):
    return (27 * R ** 2 * Tc ** 2) / (64 * Pc)


def calculate_b(Tc, Pc):
    return (R * Tc) / (8 * Pc)


def calculate_pressure(V, n, T, a=1, b=1):
    return n * R * T.to('K') / (V - n * b) - a * n ** 2 / V ** 2


def calculate_volume(P, n, T, a, b):
    V = symbols('V', real=True, positive=True)
    # 先把所有有單位的東西轉成純 float
    P_val = P.to('atm').magnitude
    T_val = T.to('K').magnitude
    n_val = n.to('mole').magnitude
    a_val = a.to('liter**2 * atm / mole**2').magnitude
    b_val = b.to('liter / mole').magnitude
    R_val = R.to('liter * atm / (mole * kelvin)').magnitude

    expr = (P_val + a_val * n_val ** 2 / V ** 2) * (V - n_val * b_val) - n_val * R_val * T_val
    solutions = solve(expr, V)
    real_solutions = [sol.evalf() for sol in solutions if sol.is_real and sol > 0]
    return float(real_solutions[0]) * ureg.liter if real_solutions else None


def calculate_number(P, V, T, a, b):
    n = symbols('n', real=True, positive=True)
    P_val = P.to('atm').magnitude
    V_val = V.to('liter').magnitude
    T_val = T.to('kelvin').magnitude
    a_val = a.to('liter**2 * atm / mole**2').magnitude
    b_val = b.to('liter / mole').magnitude
    R_val = R.to('liter * atm / (mole * kelvin)').magnitude

    expr = (P_val + a_val * n ** 2 / V_val ** 2) * (V_val - n * b_val) - n * R_val * T_val
    solutions = solve(expr, n)
    real_solutions = [sol.evalf() for sol in solutions if sol.is_real and sol > 0]
    return float(real_solutions[0]) * ureg.mole if real_solutions else None


def calculate_temperature(P, V, n, a, b):
    return ((P + a * n ** 2 / V ** 2) * (V - n * b)) / (n * R)


