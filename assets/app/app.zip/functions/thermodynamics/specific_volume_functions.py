from functions.unit_functions import ureg


# v = V / m
def calculate_specific_volume(volume, mass):
    return volume / mass


# V = v * m
def calculate_volume(specific_volume, mass):
    return specific_volume * mass


# m = V / v
def calculate_mass(specific_volume, volume):
    return volume / specific_volume


