# 設定單位
substance_list = ['ig.Al', 'ig.Al+', 'ig.Al-', 'ig.Al2', 'ig.Al2Br6', 'ig.Al2Cl6', 'ig.Al2F6', 'ig.Al2I6', 'ig.Al2O', 'ig.Al2O+', 'ig.Al2O2', 'ig.Al2O2+', 'ig.AlBO2', 'ig.AlBr', 'ig.AlBr3', 'ig.AlCl', 'ig.AlCl+', 'ig.AlCl2', 'ig.AlCl2+', 'ig.AlCl2-', 'ig.AlCl2F', 'ig.AlCl3', 'ig.AlClF', 'ig.AlClF+', 'ig.AlClF2', 'ig.AlClO', 'ig.AlF', 'ig.AlF+', 'ig.AlF2', 'ig.AlF2+', 'ig.AlF2-', 'ig.AlF2O', 'ig.AlF2O-', 'ig.AlF3', 'ig.AlF4-', 'ig.AlF4Li', 'ig.AlF4Na', 'ig.AlFO', 'ig.AlH', 'ig.AlHO', 'ig.AlHO2', 'ig.AlHO_1', 'ig.AlI', 'ig.AlI3', 'ig.AlN', 'ig.AlO', 'ig.AlO+', 'ig.AlO-', 'ig.AlO2', 'ig.AlO2-', 'ig.AlS', 'ig.Ar', 'ig.Ar+', 'ig.B', 'ig.B+', 'ig.B-', 'ig.B10H14', 'ig.B2', 'ig.B2BeO4', 'ig.B2Cl4', 'ig.B2F4', 'ig.B2F4O', 'ig.B2H4O4', 'ig.B2O', 'ig.B2O2', 'ig.B2O3', 'ig.B3Cl3O3', 'ig.B3F2HO3', 'ig.B3F3O3', 'ig.B3FH2O3', 'ig.B3H3O3', 'ig.B3H3O6', 'ig.B5H9', 'ig.BBeO2', 'ig.BBr', 'ig.BBr2', 'ig.BBr2Cl', 'ig.BBr2F', 'ig.BBr2H', 'ig.BBr3', 'ig.BBrCl', 'ig.BBrCl2', 'ig.BBrF', 'ig.BBrF2', 'ig.BBrO',
                  'ig.BCl', 'ig.BCl+', 'ig.BCl2', 'ig.BCl2+', 'ig.BCl2-', 'ig.BCl2F', 'ig.BCl2H', 'ig.BCl3', 'ig.BClF', 'ig.BClF2', 'ig.BClO', 'ig.BF', 'ig.BF2', 'ig.BF2+', 'ig.BF2-', 'ig.BF2H', 'ig.BF2HO', 'ig.BF2O', 'ig.BF3', 'ig.BF4K', 'ig.BFO', 'ig.BH', 'ig.BH2', 'ig.BH2O2', 'ig.BH3', 'ig.BH3O3', 'ig.BHO', 'ig.BHO2', 'ig.BHS', 'ig.BI', 'ig.BI2', 'ig.BI3', 'ig.BKO2', 'ig.BLiO2', 'ig.BN', 'ig.BNaO2', 'ig.BO', 'ig.BO2', 'ig.BO2-', 'ig.BS', 'ig.Ba', 'ig.BaBr', 'ig.BaBr2', 'ig.BaCl', 'ig.BaCl2', 'ig.BaF', 'ig.BaF+', 'ig.BaF2', 'ig.BaH2O2', 'ig.BaHO', 'ig.BaI', 'ig.BaI2', 'ig.BaS', 'ig.Be', 'ig.Be+', 'ig.Be2', 'ig.Be2Cl4', 'ig.Be2F2O', 'ig.Be2O', 'ig.Be2O2', 'ig.Be3O3', 'ig.Be4O4', 'ig.BeBr', 'ig.BeBr2', 'ig.BeCl', 'ig.BeCl+', 'ig.BeCl2', 'ig.BeClF', 'ig.BeF', 'ig.BeF2', 'ig.BeF3Li', 'ig.BeH', 'ig.BeH2O2', 'ig.BeHO', 'ig.BeI', 'ig.BeI2', 'ig.BeN', 'ig.BeO', 'ig.BeS', 'ig.Br', 'ig.Br2', 'ig.Br2Ca', 'ig.Br2Fe', 'ig.Br2H2Si', 'ig.Br2Hg', 'ig.Br2K2', 'ig.Br2Li2', 'ig.Br2Mg', 'ig.Br2Mo',
                  'ig.Br2Na2', 'ig.Br2Pb', 'ig.Br2Si', 'ig.Br2Sr', 'ig.Br2Ti', 'ig.Br2Zr', 'ig.Br3HSi', 'ig.Br3Mo', 'ig.Br3OP', 'ig.Br3P', 'ig.Br3PS', 'ig.Br3Si', 'ig.Br3Ti', 'ig.Br3Zr', 'ig.Br4Fe2', 'ig.Br4Mg2', 'ig.Br4Mo', 'ig.Br4Pb', 'ig.Br4Si', 'ig.Br4Ti', 'ig.Br4Zr', 'ig.Br5Nb', 'ig.Br5W', 'ig.Br6W', 'ig.BrCa', 'ig.BrCl', 'ig.BrF', 'ig.BrF3', 'ig.BrF5', 'ig.BrF5S', 'ig.BrH', 'ig.BrH3Si', 'ig.BrHg', 'ig.BrI', 'ig.BrK', 'ig.BrLi', 'ig.BrMg', 'ig.BrMo', 'ig.BrN', 'ig.BrNO', 'ig.BrNa', 'ig.BrP', 'ig.BrPb', 'ig.BrSi', 'ig.BrSr', 'ig.BrTi', 'ig.BrW', 'ig.BrZr', 'ig.C', 'ig.C+', 'ig.C-', 'ig.C10H21', 'ig.C10H8', 'ig.C12D10', 'ig.C12D9', 'ig.C12H10', 'ig.C12H23', 'ig.C12H9', 'ig.C2', 'ig.C2+', 'ig.C2-', 'ig.C2Be', 'ig.C2Cl2', 'ig.C2Cl4', 'ig.C2Cl6', 'ig.C2F2', 'ig.C2F3N', 'ig.C2F4', 'ig.C2F6', 'ig.C2H', 'ig.C2H2', 'ig.C2H2O', 'ig.C2H3', 'ig.C2H3N', 'ig.C2H3O', 'ig.C2H4', 'ig.C2H4O', 'ig.C2H4O2', 'ig.C2H4O4', 'ig.C2H5', 'ig.C2H6', 'ig.C2H6N2', 'ig.C2H6O', 'ig.C2HCl', 'ig.C2HF', 'ig.C2HN',
                  'ig.C2HO', 'ig.C2K2N2', 'ig.C2N', 'ig.C2N2', 'ig.C2N2Na2', 'ig.C2O', 'ig.C2Si', 'ig.C3', 'ig.C3H3', 'ig.C3H4', 'ig.C3H5', 'ig.C3H6', 'ig.C3H6O', 'ig.C3H7', 'ig.C3H8', 'ig.C3H8O', 'ig.C3O2', 'ig.C4', 'ig.C4H10', 'ig.C4H12Si', 'ig.C4H2', 'ig.C4H4', 'ig.C4H6', 'ig.C4H8', 'ig.C4H8O4', 'ig.C4H9', 'ig.C4N2', 'ig.C4NiO4', 'ig.C5', 'ig.C5FeO5', 'ig.C5H10', 'ig.C5H11', 'ig.C5H12', 'ig.C5H6', 'ig.C5H8', 'ig.C6D5', 'ig.C6D6', 'ig.C6H10', 'ig.C6H12', 'ig.C6H13', 'ig.C6H2', 'ig.C6H5', 'ig.C6H5O', 'ig.C6H6', 'ig.C6H6O', 'ig.C7H14', 'ig.C7H15', 'ig.C7H16', 'ig.C7H7', 'ig.C7H8', 'ig.C7H8O', 'ig.C8H10', 'ig.C8H16', 'ig.C8H17', 'ig.C8H18', 'ig.C8H8', 'ig.C9H19', 'ig.CAl', 'ig.CB', 'ig.CBr', 'ig.CBr4', 'ig.CBrF3', 'ig.CBrN', 'ig.CCl', 'ig.CCl2', 'ig.CCl2F2', 'ig.CCl2O', 'ig.CCl3', 'ig.CCl3F', 'ig.CCl4', 'ig.CClF3', 'ig.CClFO', 'ig.CClN', 'ig.CClO', 'ig.CF', 'ig.CF+', 'ig.CF2', 'ig.CF2+', 'ig.CF2O', 'ig.CF3', 'ig.CF3+', 'ig.CF3I', 'ig.CF4', 'ig.CF4O', 'ig.CF8S', 'ig.CFN', 'ig.CFO',
                  'ig.CH', 'ig.CH+', 'ig.CH2', 'ig.CH2Cl2', 'ig.CH2ClF', 'ig.CH2F2', 'ig.CH2O', 'ig.CH2O2', 'ig.CH3', 'ig.CH3Cl', 'ig.CH3Cl3Si', 'ig.CH3F', 'ig.CH3F3Si', 'ig.CH3O', 'ig.CH4', 'ig.CH4O', 'ig.CHCl', 'ig.CHCl2F', 'ig.CHCl3', 'ig.CHClF2', 'ig.CHF', 'ig.CHF3', 'ig.CHFO', 'ig.CHN', 'ig.CHNO', 'ig.CHO', 'ig.CHO+', 'ig.CHO2', 'ig.CHP', 'ig.CIN', 'ig.CKN', 'ig.CN', 'ig.CN+', 'ig.CN-', 'ig.CN2', 'ig.CN2_1', 'ig.CNNa', 'ig.CNO', 'ig.CO', 'ig.CO+', 'ig.CO2', 'ig.CO2+', 'ig.COS', 'ig.CP', 'ig.CS', 'ig.CS2', 'ig.CSi', 'ig.CSi2', 'ig.Ca', 'ig.Ca+', 'ig.Ca2', 'ig.CaCl', 'ig.CaCl2', 'ig.CaF', 'ig.CaF2', 'ig.CaH2O2', 'ig.CaHO', 'ig.CaI', 'ig.CaI2', 'ig.CaO', 'ig.CaS', 'ig.Cl', 'ig.Cl+', 'ig.Cl-', 'ig.Cl10W2', 'ig.Cl2', 'ig.Cl2Co', 'ig.Cl2Cs2', 'ig.Cl2FOP', 'ig.Cl2Fe', 'ig.Cl2H2Si', 'ig.Cl2Hg', 'ig.Cl2K2', 'ig.Cl2Li2', 'ig.Cl2Mg', 'ig.Cl2MoO2', 'ig.Cl2Na2', 'ig.Cl2Ni', 'ig.Cl2O', 'ig.Cl2O2S', 'ig.Cl2O2W', 'ig.Cl2OTi', 'ig.Cl2Pb', 'ig.Cl2Pb+', 'ig.Cl2S', 'ig.Cl2S+', 'ig.Cl2S2', 'ig.Cl2Si',
                  'ig.Cl2Sr', 'ig.Cl2Ti', 'ig.Cl2W', 'ig.Cl2Zr', 'ig.Cl3Co', 'ig.Cl3Cu3', 'ig.Cl3FSi', 'ig.Cl3Fe', 'ig.Cl3HSi', 'ig.Cl3Li3', 'ig.Cl3OP', 'ig.Cl3P', 'ig.Cl3PS', 'ig.Cl3Si', 'ig.Cl3Ti', 'ig.Cl3Zr', 'ig.Cl4Co2', 'ig.Cl4Fe2', 'ig.Cl4Mg2', 'ig.Cl4Mo', 'ig.Cl4OW', 'ig.Cl4Pb', 'ig.Cl4Si', 'ig.Cl4Ti', 'ig.Cl4V', 'ig.Cl4W', 'ig.Cl4Zr', 'ig.Cl5Mo', 'ig.Cl5Nb', 'ig.Cl5P', 'ig.Cl5Ta', 'ig.Cl5W', 'ig.Cl6Fe2', 'ig.Cl6Mo', 'ig.Cl6W', 'ig.ClCo', 'ig.ClCs', 'ig.ClCu', 'ig.ClD', 'ig.ClDO', 'ig.ClF', 'ig.ClF2OP', 'ig.ClF3', 'ig.ClF3Si', 'ig.ClF5', 'ig.ClF5S', 'ig.ClFLi2', 'ig.ClFMg', 'ig.ClFO2S', 'ig.ClFO3', 'ig.ClFe', 'ig.ClH', 'ig.ClH3Si', 'ig.ClHO', 'ig.ClHg', 'ig.ClI', 'ig.ClK', 'ig.ClLi', 'ig.ClLiO', 'ig.ClMg', 'ig.ClMg+', 'ig.ClNO', 'ig.ClNO2', 'ig.ClNa', 'ig.ClNi', 'ig.ClO', 'ig.ClO2', 'ig.ClOTi', 'ig.ClP', 'ig.ClPb', 'ig.ClPb+', 'ig.ClS', 'ig.ClS2', 'ig.ClSi', 'ig.ClSr', 'ig.ClTi', 'ig.ClW', 'ig.ClZr', 'ig.Co', 'ig.CoF2', 'ig.Cr', 'ig.CrN', 'ig.CrO', 'ig.CrO2', 'ig.CrO3', 'ig.Cs',
                  'ig.Cs+', 'ig.Cs2', 'ig.Cs2F2', 'ig.Cs2H2O2', 'ig.Cs2O', 'ig.Cs2O4S', 'ig.CsF', 'ig.CsHO', 'ig.CsO', 'ig.Cu', 'ig.Cu+', 'ig.Cu2', 'ig.CuF', 'ig.CuF2', 'ig.CuO', 'ig.D', 'ig.D+', 'ig.D-', 'ig.D2', 'ig.D2+', 'ig.D2-', 'ig.D2N', 'ig.D2N2', 'ig.D2O', 'ig.D2S', 'ig.D3N', 'ig.DF', 'ig.DH', 'ig.DHO', 'ig.DN', 'ig.DO', 'ig.DS', 'ig.F', 'ig.F+', 'ig.F-', 'ig.F10Mo2', 'ig.F10S2', 'ig.F15Mo3', 'ig.F2', 'ig.F2Fe', 'ig.F2H2Si', 'ig.F2Hg', 'ig.F2K-', 'ig.F2K2', 'ig.F2Li-', 'ig.F2Li2', 'ig.F2Mg', 'ig.F2Mg+', 'ig.F2Mo', 'ig.F2N', 'ig.F2N2', 'ig.F2N2_1', 'ig.F2Na-', 'ig.F2Na2', 'ig.F2O', 'ig.F2O2S', 'ig.F2OS', 'ig.F2OSi', 'ig.F2OTi', 'ig.F2P', 'ig.F2P+', 'ig.F2Pb', 'ig.F2S', 'ig.F2S+', 'ig.F2S-', 'ig.F2S2', 'ig.F2S2_1', 'ig.F2Si', 'ig.F2Sr', 'ig.F2Ti', 'ig.F2Zr', 'ig.F3Fe', 'ig.F3HSi', 'ig.F3Li3', 'ig.F3Mo', 'ig.F3N', 'ig.F3NO', 'ig.F3OP', 'ig.F3P', 'ig.F3PS', 'ig.F3S', 'ig.F3S+', 'ig.F3S-', 'ig.F3Si', 'ig.F3Ti', 'ig.F3Zr', 'ig.F4Mg2', 'ig.F4Mo', 'ig.F4MoO', 'ig.F4N2', 'ig.F4OW',
                  'ig.F4Pb', 'ig.F4S', 'ig.F4S+', 'ig.F4S-', 'ig.F4Si', 'ig.F4Ti', 'ig.F4Zr', 'ig.F5I', 'ig.F5Mo', 'ig.F5P', 'ig.F5S', 'ig.F5S+', 'ig.F5S-', 'ig.F6Mo', 'ig.F6S', 'ig.F6S-', 'ig.F6W', 'ig.F7I', 'ig.FFe', 'ig.FH', 'ig.FH3Si', 'ig.FHO', 'ig.FHO3S', 'ig.FHg', 'ig.FI', 'ig.FK', 'ig.FLi', 'ig.FLiO', 'ig.FMg', 'ig.FMg+', 'ig.FMo', 'ig.FN', 'ig.FNO', 'ig.FNO2', 'ig.FNO3', 'ig.FNa', 'ig.FO', 'ig.FO2', 'ig.FOTi', 'ig.FP', 'ig.FP+', 'ig.FP-', 'ig.FPS', 'ig.FPb', 'ig.FS', 'ig.FS+', 'ig.FS-', 'ig.FSi', 'ig.FSr', 'ig.FSr+', 'ig.FTi', 'ig.FW', 'ig.FZr', 'ig.Fe', 'ig.Fe+', 'ig.Fe-', 'ig.Fe2I4', 'ig.FeH2O2', 'ig.FeI2', 'ig.FeO', 'ig.FeS', 'ig.Ga', 'ig.H', 'ig.H+', 'ig.H-', 'ig.H2', 'ig.H2+', 'ig.H2-', 'ig.H2B', 'ig.H2BaO2', 'ig.H2BeO2', 'ig.H2Br2Si', 'ig.H2CaO2', 'ig.H2Cl2Si', 'ig.H2Cs2O2', 'ig.H2F2', 'ig.H2F2Si', 'ig.H2FN', 'ig.H2FeO2', 'ig.H2I2Si', 'ig.H2K2O2', 'ig.H2Li2O2', 'ig.H2MgO2', 'ig.H2MoO4', 'ig.H2N', 'ig.H2N2', 'ig.H2N2O2', 'ig.H2Na2O2', 'ig.H2O', 'ig.H2O+', 'ig.H2O2',
                  'ig.H2O2Sr', 'ig.H2O4S', 'ig.H2O4W', 'ig.H2P', 'ig.H2S', 'ig.H2Si', 'ig.H3B', 'ig.H3B3O3', 'ig.H3B3O6', 'ig.H3BrSi', 'ig.H3ClSi', 'ig.H3F3', 'ig.H3FSi', 'ig.H3ISi', 'ig.H3N', 'ig.H3NO', 'ig.H3O+', 'ig.H3P', 'ig.H3Si', 'ig.H4F4', 'ig.H4N+', 'ig.H4N2', 'ig.H4Si', 'ig.H5F5', 'ig.H6F6', 'ig.H7F7', 'ig.HAl', 'ig.HAlO', 'ig.HAlO+', 'ig.HAlO-', 'ig.HAlO2', 'ig.HB', 'ig.HBF2', 'ig.HBO', 'ig.HBO+', 'ig.HBO-', 'ig.HBO2', 'ig.HBS', 'ig.HBS+', 'ig.HBaO', 'ig.HBaO+', 'ig.HBe', 'ig.HBe+', 'ig.HBeO', 'ig.HBeO+', 'ig.HBr', 'ig.HBr3Si', 'ig.HCaO', 'ig.HCaO+', 'ig.HCl', 'ig.HCl3Si', 'ig.HClO', 'ig.HCsO', 'ig.HCsO+', 'ig.HD', 'ig.HD+', 'ig.HD-', 'ig.HDO', 'ig.HF', 'ig.HF2N', 'ig.HF3Si', 'ig.HFN', 'ig.HFO', 'ig.HFO3S', 'ig.HHg', 'ig.HI', 'ig.HI3Si', 'ig.HK', 'ig.HKO', 'ig.HKO+', 'ig.HLi', 'ig.HLiO', 'ig.HLiO+', 'ig.HMg', 'ig.HMgO', 'ig.HMgO+', 'ig.HN', 'ig.HN+', 'ig.HN3', 'ig.HNO', 'ig.HNO2', 'ig.HNO3', 'ig.HNa', 'ig.HNaO', 'ig.HNaO+', 'ig.HO', 'ig.HO+', 'ig.HO-', 'ig.HO2', 'ig.HOSr',
                  'ig.HOSr+', 'ig.HP', 'ig.HPb', 'ig.HS', 'ig.HSi', 'ig.HSi+', 'ig.HZr', 'ig.He', 'ig.He+', 'ig.Hf', 'ig.Hg', 'ig.HgI', 'ig.HgI2', 'ig.HgO', 'ig.I', 'ig.I2', 'ig.I2K2', 'ig.I2Li2', 'ig.I2Mg', 'ig.I2Mo', 'ig.I2Pb', 'ig.I2Si', 'ig.I2Sr', 'ig.I2Ti', 'ig.I2Zr', 'ig.I3Mo', 'ig.I3Si', 'ig.I3Ti', 'ig.I3Zr', 'ig.I4Mo', 'ig.I4Pb', 'ig.I4Si', 'ig.I4Ti', 'ig.I4Zr', 'ig.IK', 'ig.ILi', 'ig.IMg', 'ig.INO', 'ig.INa', 'ig.IPb', 'ig.ISi', 'ig.ISr', 'ig.ITi', 'ig.IZr', 'ig.K', 'ig.K+', 'ig.K2', 'ig.K2O4S', 'ig.KO', 'ig.KO-', 'ig.Kr', 'ig.Kr+', 'ig.Li', 'ig.Li+', 'ig.Li2', 'ig.Li2O', 'ig.Li2O2', 'ig.Li2O4S', 'ig.LiN', 'ig.LiNO', 'ig.LiNaO', 'ig.LiO', 'ig.LiO-', 'ig.Mg', 'ig.Mg+', 'ig.Mg2', 'ig.MgN', 'ig.MgO', 'ig.MgS', 'ig.Mn', 'ig.Mo', 'ig.Mo2O6', 'ig.Mo3O9', 'ig.Mo4O12', 'ig.Mo5O15', 'ig.MoO', 'ig.MoO2', 'ig.MoO3', 'ig.N', 'ig.N+', 'ig.N-', 'ig.N2', 'ig.N2+', 'ig.N2-', 'ig.N2O', 'ig.N2O+', 'ig.N2O3', 'ig.N2O4', 'ig.N2O5', 'ig.N3', 'ig.NO', 'ig.NO+', 'ig.NO2', 'ig.NO2-', 'ig.NO3',
                  'ig.NO3-', 'ig.NP', 'ig.NS', 'ig.NSi', 'ig.NSi2', 'ig.NV', 'ig.NZr', 'ig.Na', 'ig.Na+', 'ig.Na2', 'ig.Na2O', 'ig.Na2O4S', 'ig.NaO', 'ig.NaO-', 'ig.Nb', 'ig.NbO', 'ig.NbO2', 'ig.Ne', 'ig.Ne+', 'ig.Ni', 'ig.NiO', 'ig.NiS', 'ig.O', 'ig.O+', 'ig.O-', 'ig.O10P4', 'ig.O12W4', 'ig.O2', 'ig.O2+', 'ig.O2-', 'ig.O2P', 'ig.O2S', 'ig.O2Si', 'ig.O2Ta', 'ig.O2Ti', 'ig.O2V', 'ig.O2W', 'ig.O2Zr', 'ig.O3', 'ig.O3S', 'ig.O3W', 'ig.O6P4', 'ig.O6W2', 'ig.O8W3', 'ig.O9W3', 'ig.OP', 'ig.OPb', 'ig.OS', 'ig.OS2', 'ig.OSi', 'ig.OSr', 'ig.OTa', 'ig.OTi', 'ig.OV', 'ig.OW', 'ig.OZr', 'ig.P', 'ig.P+', 'ig.P2', 'ig.P4', 'ig.PS', 'ig.Pb', 'ig.Pb2', 'ig.PbS', 'ig.Rb', 'ig.Rb2', 'ig.S', 'ig.S+', 'ig.S-', 'ig.S2', 'ig.S3', 'ig.S4', 'ig.S5', 'ig.S6', 'ig.S7', 'ig.S8', 'ig.SSi', 'ig.SSr', 'ig.Si', 'ig.Si+', 'ig.Si2', 'ig.Si3', 'ig.Sr', 'ig.Ta', 'ig.Ti', 'ig.Ti+', 'ig.Ti-', 'ig.V', 'ig.Xe', 'ig.Xe+', 'ig.Zn', 'ig.Zn-', 'ig.Zr', 'ig.air', 'ig.e', 'ig.f5', 'ig.h35', 'mp.C2H2F4', 'mp.C3H2F4_1', 'mp.CH4',
                  'mp.CO2', 'mp.H2O', 'mp.N2', 'mp.O2', ]


def get_saturation_properties(substance_code: str, T: float) -> dict:
    import pyromat as pm
    pm.config['unit_pressure'] = 'kPa'
    pm.config['unit_temperature'] = 'K'
    pm.config['unit_energy'] = 'kJ'
    pm.config['unit_mass'] = 'kg'
    pm.config['unit_volume'] = 'm3'
    """
    給定物質名稱與溫度 (K)，回傳飽和壓力、比容、焓、熵與估算內能。

    :param substance_code: 物質代碼，如 "mp.H2O"
    :param T: 溫度 (K)
    :return: 包含飽和壓力與飽和液態/氣態的 thermodynamic 屬性 dict
    """
    try:
        material = pm.get(substance_code)
    except Exception as e:
        return {"error": f"找不到物質 '{substance_code}': {e}"}

    try:
        psat = material.ps(T).item()

        vf = material.v(T=T, x=0).item()
        hf = material.h(T=T, x=0).item()
        sf = material.s(T=T, x=0).item()
        uf = hf - psat * vf

        vg = material.v(T=T, x=1).item()
        hg = material.h(T=T, x=1).item()
        sg = material.s(T=T, x=1).item()
        ug = hg - psat * vg

        return {
            "T": T,
            "psat_kPa": psat,
            "liquid": {
                "v": vf,
                "h": hf,
                "s": sf,
                "u_est": uf
            },
            "vapor": {
                "v": vg,
                "h": hg,
                "s": sg,
                "u_est": ug
            }
        }
    except Exception as e:
        return {"error": f"{e}"}

