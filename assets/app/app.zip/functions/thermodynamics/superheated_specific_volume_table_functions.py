def get_superheated_properties(substance_code: str, T: float, P_MPa: float) -> dict:
    import pyromat as pm
    # 設定單位（壓力改為 MPa）
    pm.config['unit_pressure'] = 'MPa'
    pm.config['unit_temperature'] = 'K'
    pm.config['unit_energy'] = 'kJ'
    pm.config['unit_mass'] = 'kg'
    pm.config['unit_volume'] = 'm3'
    """
    給定物質名稱、溫度 (K)、壓力 (MPa)，回傳過熱蒸氣的熱力學性質。

    :param substance_code: 物質代碼，如 "mp.H2O"
    :param T: 溫度 (K)
    :param P_MPa: 壓力 (MPa)
    :return: 包含比容、焓、熵、內能的 dict
    """
    try:
        material = pm.get(substance_code)
    except Exception as e:
        return {"error": f"找不到物質 '{substance_code}': {e}"}

    try:
        v = material.v(T=T, p=P_MPa).item()
        h = material.h(T=T, p=P_MPa).item()
        s = material.s(T=T, p=P_MPa).item()
        u = material.e(T=T, p=P_MPa).item()

        return {
            "T": T,
            "P_MPa": P_MPa,
            "v": v,
            "h": h,
            "s": s,
            "u": u
        }
    except Exception as e:
        return {"error": str(e)}
