import pint
import itertools

from sympy.physics.units import radian

ureg = pint.UnitRegistry()

mass_unit_symbol_list = ['g', 'mg', 'kg', 'μg', 'tonne', 'lb', 'oz', 'ct', 'ton', 'amu']
mass_unit_symbol_name_dict = {
    'g': '克',
    'mg': '毫克',
    'kg': '公斤',
    'μg': '微克',
    'tonne': '公噸',
    'lb': '磅',
    'oz': '盎司',
    'ct': '克拉',
    'ton': '短噸（美制）',
    'amu': '原子質量單位'
}

length_unit_symbol_list = ['m', 'cm', 'km', 'mm', 'dm', 'ft', 'in', 'Å', 'nmi', 'µm', 'nm']
length_unit_symbol_name_dict = {
    'm': '公尺',
    'cm': '公分',
    'km': '公里',
    'mm': '毫米',
    'nm': '奈米',
    'dm': '公寸',
    'ft': '英尺',
    'in': '英吋',
    'Å': '埃（Ångström）',
    'nmi': '海里',
    'µm': '微米',
}

time_unit_symbol_list = ['s', 'min', 'h', 'd', 'week', 'month', 'year']
time_unit_symbol_name_dict = {
    's': '秒',
    'h': '小時',
    'min': '分鐘',
    'd': '天',
    'week': '週',
    'month': '月',
    'year': '年'
}

pressure_unit_symbol_list = ['atm', 'Pa', 'kPa', 'bar', 'torr', 'psi', 'mmHg', 'cmH2O', 'cmHg', 'inHg']
pressure_unit_symbol_name_dict = {
    'atm': '大氣壓',
    'Pa': '帕',
    'kPa': '千帕',
    'MPa': '百萬帕',
    'bar': '巴',
    'torr': '托',
    'psi': '磅每平方英吋',
    'mmHg': '毫米汞柱',
    'cmH2O': '公分水柱',
    'cmHg': '公分汞柱',
    'inHg': '英吋汞柱'
}

volume_unit_symbol_list = ['L', 'm³', 'cm³', 'mm³', 'mL', 'µl', 'gallon', 'pint']
volume_unit_symbol_name_dict = {
    'L': '公升',
    'm³': '立方公尺',
    'cm³': '立方公分',
    'mm³': '立方毫米',
    'mL': '毫升',
    'µl': '微升',
    'gallon': '加侖',
    'pint': '品脫'
}

temperature_unit_symbol_list = ['K', '°C', '°F']
temperature_unit_symbol_name_dict = {
    'K': '克耳文',
    '°C': '攝氏度',
    '°F': '華氏度'
}

force_unit_symbol_list = ['N']
force_unit_symbol_name_dict = {
    'N': '牛頓'
}

number_unit_symbol_list = ['mole']
number_unit_symbol_name_dict = {
    'mole': '莫耳'
}

electric_current_unit_symbol_list = ['A']
electric_current_unit_symbol_name_dict = {'A': '安培'}

electric_quantity_unit_symbol_list = ['C']
electric_quantity_unit_symbol_name_dict = {'C': '庫倫'}

electric_field_strength_unit_symbol_list = ['V/m', 'N/C']
electric_field_strength_unit_symbol_name_dict = {
    'V/m': '伏特/公尺',
    'N/C': '牛頓/庫倫',
}

voltage_unit_symbol_list = ['V']
voltage_unit_symbol_name_dict = {'V': '伏特'}

energy_unit_symbol_list = ['J', 'kJ', 'cal', 'eV', 'kcal', 'kWh']
energy_unit_symbol_name_dict = {
    'J': '焦耳',
    'kJ': '千焦耳',
    'cal': '卡',
    'kcal': '大卡',
    'eV': '電子伏特',
    'kWh': '度',
}

acceleration_unit_symbol_list = ['m/s²']
acceleration_unit_symbol_name_dict = {
    'm/s²': 'm/s²'
}

molecular_mass_unit_symbol_list = ['g/mole']
molecular_mass_unit_symbol_name_dict = {'g/mole': '分子量'}

charge_unit_symbol_name_dict = {'dimensionless': '無單位'}
dimensionless_unit_symbol_name_dict = {'dimensionless': '無單位'}

density_unit_symbol_list = ['g/cm³', 'kg/m³']
density_unit_symbol_name_dict = {
    'g/cm³': 'g/cm³',
    'kg/m³': 'kg/m³',
}


def generate_unit_combinations(unit_lists, format_func):
    """
    通用單位組合函數
    :param unit_lists: 一個包含多個單位列表的 list，例如 [mass_list, length_list, time_list]
    :param format_func: 接收 tuple，返回格式化字串的函數，例如 lambda comb: f"{comb[0]}/{comb[1]}"
    :return: (unit_list, unit_dict)
    """
    unit_list = []
    unit_dict = {}
    for comb in itertools.product(*unit_lists):
        unit = format_func(comb)
        unit_list.append(unit)
        unit_dict[unit] = unit
    return unit_list, unit_dict


velocity_unit_symbol_list, velocity_unit_symbol_name_dict = generate_unit_combinations(
    [length_unit_symbol_list[:3], time_unit_symbol_list[:3]],
    lambda comb: f"{comb[0]}/{comb[1]}"
)
momentum_unit_symbol_list, momentum_unit_symbol_name_dict = generate_unit_combinations(
    [['g', 'kg'], ['m', 'km'], ['s', 'h']],
    lambda comb: f"{comb[0]}*{comb[1]}/{comb[2]}"
)
momentum_unit_symbol_name_dict['kg*m/s'] = 'N*s'

file_size_unit_symbol_list = ['bit', 'byte', 'kB', 'MB', 'GB', 'TB']
file_size_unit_symbol_name_dict = {
    'bit': 'bit',
    'byte': 'byte',
    'kB': 'KB',
    'MB': 'MB',
    'GB': 'GB',
    'TB': 'TB'
}

magnetic_field_unit_symbol_list = ['T']
magnetic_field_unit_symbol_name_dict = {
    'T': '特斯拉',
}

frequency_unit_symbol_list = ['Hz']
frequency_unit_symbol_name_dict = {
    'Hz': '赫茲',
}

Resistance_unit_symbol_list = ['Ω']
Resistance_unit_symbol_name_dict = {
    'Ω': '歐姆'
}
radian_unit_symbol_list = ['rad']
radian_unit_symbol_name_dict = {
    'rad': '弧度',
}
angular_velocity_unit_symbol_list = ['rad/s', 'rpm']
angular_velocity_unit_symbol_name_dict = {
    'rad/s': 'rad/s',
    'rpm': 'rpm'
}
power_unit_symbol_list = ['W', 'kW', 'hp']
power_unit_symbol_name_dict = {
    'W': '瓦特',
    'kW': '千瓦',
    'hp': '馬力'
}
area_unit_symbol_list = ['m²', 'cm²', 'mm²', 'km²', 'ft²', 'in²', 'hectare', 'are']
area_unit_symbol_name_dict = {
    'm²': '平方公尺',
    'cm²': '平方公分',
    'mm²': '平方毫米',
    'km²': '平方公里',
    'ft²': '平方英尺',
    'in²': '平方英吋',
    'hectare': '公頃',
    'are': '公畝'
}
cv_cp_unit_symbol_list = ['kJ/(mole*K)']
cv_cp_unit_symbol_name_dict = {
    'kJ/(mole*K)': 'kJ/(mole*K)'
}
entropy_unit_symbol_list = ['kJ/(kg*K)']
entropy_unit_symbol_name_dict = {
    'kJ/(kg*K)': 'kJ/(kg*K)'
}

torque_unit_symbol_list = ['N*m']
torque_unit_symbol_name_dict = {
    'N*m': 'N*m'
}
specific_volume_unit_symbol_list = ['m³/kg']
specific_volume_unit_symbol_name_dict = {
    'm³/kg': 'm³/kg',
    'cm³/g': 'cm³/g',
}
specific_enthalpy_unit_symbol_list = ['kJ/kg']
specific_enthalpy_unit_symbol_name_dict = {
    'kJ/kg': 'kJ/kg'
}
specific_entropy_unit_symbol_list = ['kJ/(kg*K)']
specific_entropy_unit_symbol_name_dict = {
    'kJ/(kg*K)': 'kJ/(kg*K)'
}

all_unit_dict_dict = {
    'Mass': mass_unit_symbol_name_dict,
    'Length': length_unit_symbol_name_dict,
    'Time': time_unit_symbol_name_dict,
    'Pressure': pressure_unit_symbol_name_dict,
    'Temperature': temperature_unit_symbol_name_dict,
    'Volume': volume_unit_symbol_name_dict,
    'Velocity': velocity_unit_symbol_name_dict,
    'Acceleration': acceleration_unit_symbol_name_dict,
    'Force': force_unit_symbol_name_dict,
    'Molecular_mass': molecular_mass_unit_symbol_name_dict,
    'Electricity_quantity': electric_quantity_unit_symbol_name_dict,
    'Charge': charge_unit_symbol_name_dict,
    'Number': number_unit_symbol_name_dict,
    'File_size': file_size_unit_symbol_name_dict,
    'Energy': energy_unit_symbol_name_dict,
    'Magnetic_field': magnetic_field_unit_symbol_name_dict,
    'Voltage': voltage_unit_symbol_name_dict,
    'Current': electric_current_unit_symbol_name_dict,
    'Electric_field_strength': electric_field_strength_unit_symbol_name_dict,
    'Frequency': frequency_unit_symbol_name_dict,
    'Resistance': Resistance_unit_symbol_name_dict,
    'Angle': {'∘': '度'},
    'Dimensionless': dimensionless_unit_symbol_name_dict,
    'Radian': radian_unit_symbol_name_dict,
    'Angular_velocity': angular_velocity_unit_symbol_name_dict,
    'Momentum': momentum_unit_symbol_name_dict,
    'Power': power_unit_symbol_name_dict,
    'Area': area_unit_symbol_name_dict,
    'Cv': cv_cp_unit_symbol_name_dict,
    'Entropy': entropy_unit_symbol_name_dict,
    'Density': density_unit_symbol_name_dict,
    'Torque': torque_unit_symbol_name_dict,
    'Specific_volume': specific_volume_unit_symbol_name_dict,
    'Specific_enthalpy': specific_enthalpy_unit_symbol_name_dict,
    'Specific_entropy': specific_entropy_unit_symbol_name_dict,
}

all_unit_name_dict = {
    'Mass': '質量',
    'Length': '長度',
    'Time': '時間',
    'Pressure': '壓力',
    'Temperature': '溫度',
    'Volume': '體積',
    'Velocity': '速率',
    'Acceleration': '加速度',
    'Force': '力',
    'Molecular_mass': '分子量',
    'Electricity_quantity': '電量',
    'Charge': '電荷',
    'Number': '莫爾數',
    'File_size': '檔案大小',
    'Energy': '能量',
    'Voltage': '電壓',
    'Magnetic_field': '磁場',
    'Electric_field_strength': '電場強度',
    'Frequency': '頻率',
    'Resistance': '電阻',
    'Current': '電流',
    'Angle': '角度',
    'Radian': '弧度',
    'Angular_velocity': '角速度',
    'Dimensionless': '無單位',
    'Momentum': '動量',
    'Power': '功率',
    'Area': '面積',
    'Cv': 'Cv',
    'Entropy': '熵',
    'Density': '密度',
    'Torque': '扭矩',
    'Specific_volume': '比容',
    'Specific_enthalpy': '比焓',
    'Specific_entropy': '比熵',

}
exclude_unit_list = ['Acceleration', 'Force', 'Molecular_mass', 'Electricity_quantity', 'Charge', 'Number', 'Magnetic_field', 'Voltage', 'Frequency', 'Resistance', 'Angle', 'Dimensionless', 'Current', 'Cv', 'Torque',
                     'Specific_enthalpy', 'Specific_entropy']


def get_temperature_ureg(value1, temperature_unit):
    Q_ = ureg.Quantity
    if temperature_unit == '°C' or temperature_unit == 'degC':
        temperature_ureg = Q_(float(value1), ureg.degC)
    elif temperature_unit == '°F' or temperature_unit == 'degF':
        temperature_ureg = Q_(float(value1), ureg.degF)
    elif temperature_unit == 'K':
        temperature_ureg = float(value1) * ureg.K
    return temperature_ureg


def temperature_conversion(value1, input_unit1, output_unit2, is_with_unit=False):
    input_temperature = get_temperature_ureg(value1, input_unit1)
    if output_unit2 == '°C' or output_unit2 == 'degC':
        output_str = 'degC'
    elif output_unit2 == '°F' or output_unit2 == 'degF':
        output_str = 'degF'
    elif output_unit2 == 'K':
        output_str = 'K'
    new_value = input_temperature.to(output_str)
    if is_with_unit:
        return new_value
    new_value = round(float(str(new_value).split()[0]), 6)
    return new_value


planck_constant = 6.626 * 10 ** -34 * ureg.J * ureg.s
light_speed = 3 * 10 ** 8 * ureg.m / ureg.s
gravitational_acceleration = 9.81 * ureg.m / ureg.s ** 2


def test_temperature_conversion():
    number_ureg = ureg.parse_expression('2')
    print(number_ureg)
    number_ureg = ureg.parse_expression('2dimensionless')
    print(number_ureg)
    number_ureg = ureg.parse_expression('2 g/mole')
    print(number_ureg)


def test1():
    all_unit_list = list(ureg._units.keys())
    for unit in all_unit_list:
        a = ureg.parse_expression(unit)
        if '[mass] / [time] ** 2 / [current]' in str(a.dimensionality):
            print(a, a.dimensionality)


def test2():
    a = ureg.parse_expression('Mbps')
    print(a)


def test_energy():
    a = ureg.parse_expression('J')
    print(a)
    a = ureg.parse_expression('cal')
    print(a)
    a = a.to('J')
    print(a)
    a = a.to('eV')
    print(a)
    a = a.to('kWh')
    print(a)


def test_magnetic_field():
    aaa = 5 * ureg.T
    # 使用 N/C 表示
    E = 5 * ureg('newton / coulomb')
    print(E.to('V/m'))  # 輸出：5.0 volt / meter
    # print(aaa.to('G'))
    # a = ureg.parse_expression('G')
    # print(a)
    # print(a.to('T'))
    # print(a.to('G'))


def test_frequency():
    E = 5 * ureg('Hz')
    print(E)


def test3():
    a = ureg.parse_expression('Ω')
    print(a)
    a = ureg.parse_expression('ohm')
    print(a)


def test_rad():
    a = ureg.parse_expression('rad')
    print(a)
    a = ureg.parse_expression('rpm')
    print(a)
    print(a.to('rad/s'))


def test4():
    a = ureg.parse_expression('kg*m/s')
    print(a)


def test_power_unit():
    for unit in power_unit_symbol_list:
        a = ureg.parse_expression(unit)
        print(a)


def test_area_unit():
    for unit in area_unit_symbol_list:
        a = ureg.parse_expression(unit)
        print(a)
