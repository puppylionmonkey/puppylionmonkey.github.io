import os

import flet as ft
from functions.language_dict_functions import get_language, set_text_by_language
from views.route_dicts import route_name_dict, route_english_name_dict
from views.navigation_view import NavigationView


def main(page: ft.Page):
    page.adaptive = True
    page.vertical_alignment = 'center'
    page.horizontal_alignment = 'center'
    page.theme_mode = 'dark'
    page.window_icon = "app_icon.png"
    lang = get_language()
    title = f"{set_text_by_language('科學', lang)}{set_text_by_language('加速', lang)}"
    page.title = title

    # 載入畫面
    page.splash = ft.Image(src='../assets/app_icon.png')
    page.add(
        ft.Container(
            ft.Column(
                [
                    ft.Row([ft.Image(src='../assets/app_icon.png', width=150, height=150, fit=ft.ImageFit.CONTAIN, ), ], alignment=ft.MainAxisAlignment.CENTER, ),
                    ft.Row([ft.Text(title, style=ft.TextThemeStyle.HEADLINE_SMALL), ], alignment=ft.MainAxisAlignment.CENTER, ),
                    ft.Row([ft.ProgressBar(width=400, color=ft.Colors.AMBER, bgcolor="#eeeeee"), ], alignment=ft.MainAxisAlignment.CENTER, ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                expand=True,
            )
        )
    )
    # content ###############################################################
    from views.route_class_dict_view import route_class_dict
    my_route_list = list()

    def route_change(route_e):
        # print(route_e)
        route = route_e.route
        if route == '/':
            page.views.clear()
            page.go('/')
            my_route_list.clear()
            my_route_list.append('/')
        # print('route', route)
        page.views.append(route_class_dict.get(route.replace('/', ''))(page).get_view())
        if route != my_route_list[-1]:
            my_route_list.append(route)
        # 左上角箭頭
        app_bar_container.content = ft.Row([title_row, logo_image]) if my_route_list[-1] == '/' else ft.Row([back_button, title_row, logo_image])
        title_text.value = get_title(route)
        page.update()
        # print('page.change', page.views, route)
        # print(my_route_list)

    def click_back_button(back_e):
        view_pop(page.views[-1])

    def view_pop(view):
        if len(my_route_list) > 1:
            my_route_list.pop()
            if len(my_route_list) >= 2 and my_route_list[-1] == my_route_list[-2]:
                my_route_list.pop()
            page.go(my_route_list[-1])
        else:
            page.go('/')

    def get_title(route):
        new_route_name_dict = route_name_dict if get_language() == 'zh' else route_english_name_dict
        route = route.replace('/', '')
        return new_route_name_dict.get(route)

    # 上方bar
    title_text = ft.Text(get_title(page.route), size=20, text_align=ft.TextAlign.CENTER)
    logo_image = ft.Image(src='assets/app_icon.png', width=30, height=30, fit=ft.ImageFit.CONTAIN)
    title_row = ft.Row(controls=[title_text], alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER, expand=True, )
    back_button = ft.IconButton(icon=ft.Icons.ARROW_BACK, on_click=click_back_button, icon_color=ft.Colors.WHITE, icon_size=30)
    app_bar_container = ft.Container(
        content=ft.Row([back_button, title_row, logo_image]),
        alignment=ft.alignment.center,
        height=30,
        top=30 if page.platform == ft.PagePlatform.ANDROID else 0,
        left=0,
        right=0,
    )
    # 上下bar
    page.overlay.append(
        ft.Stack(
            controls=[
                app_bar_container,
                NavigationView(page).get_navigation_bar(),
            ],
            expand=True
        )
    )
    page.on_route_change = route_change
    page.on_view_pop = view_pop
    # 正確的非同步初始化流程
    page.go("/")
    my_route_list.append('/')
    page.window_visible = True


ft.app(target=main)
# port = int(os.environ.get("PORT", 8000))
# app = ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=port)