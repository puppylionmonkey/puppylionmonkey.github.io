import flet as ft

def main(page: ft.Page):
    page.title = "Flet 靜態網頁範例"
    page.add(ft.Text("Hello, Flet Web!"))

app = ft.app(target=main, view=ft.AppView.WEB_BROWSER)
