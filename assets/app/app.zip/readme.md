安裝教學
https://www.youtube.com/watch?v=OqMYfspxKi0&ab_channel=SriEdyNurcahyo
flet build apk的時候要刪除.venv

flet 文件
text
https://flet.dev/docs/controls/text/

input
https://flet.qiannianlu.com/docs/controls/textfield/


icon
https://gallery.flet.dev/icons-browser/
輸入*搜尋全部

google play
簽署換app名稱圖示
https://www.jianshu.com/p/f91b4e84cec8
https://yanwei-liu.medium.com/flutter-%E6%89%93%E5%8C%85android-app-8ec9668ca7ce


app icon from chatgpt
https://chatgpt.com/share/67ea7360-b524-800a-a69b-dc0a3afe7996


D:\science_acceleration\build\flutter\android\app/build.gradle
裡面的defaultConfig
改版號


proplem
1.
Error: PathNotFoundException: Cannot copy file to
           'C:\Users\puppy\AppData\Local\Temp\serious_python_temp63e9356e\.venv\Scripts\libcrypto-3.dll', path =
           'D:\science_acceleration\.venv\Scripts\libcrypto-3.dll' (OS Error: 系統找不到指定的檔案。
           , errno = 2)
           Deleting temp directory
移除.venv

https://chatgpt.com/c/67fdd8af-66a4-800a-9582-d033c94c2680


pyproject.toml
# 科學加速

## Template variables

* `scienceacceleration` - project name - lowercase, no spaces, i.e. "snake_case" identifier - used as a package name, iOS/macOS/Android bundle name and Windows/Linux executable file name.
* `` - project description.
* `科學加速` - project display name that is shown in window titles and about app dialogs.
* `com.chengan` - org name in reverse domain name notation, e.g. `com.mycompany.myproject`.
* `Your Company` - the name of the company.
* `Copyright (c) 2023 Your Company` - the name of the company.

## Icons

* iOS - `assets/icon_ios.png` (or any supported image format). Recommended minimum image size is 1024 px. Image should not be transparent (have alpha channel). Defaults to `assets/icon.png` with alpha-channel automatically removed.
* Android - `assets/icon_android.png` (or any supported image format). Recommended minimum image size is 192 px. Defaults to `assets/icon.png`.
* Web - `assets/icon_web.png` (or any supported image format). Recommended minimum image size is 512 px. Defaults to `assets/icon.png`. If `assets/favicon.png` file is provided it will be used unmodified (copied to `web/favicon.png`).
* Windows - `assets/icon_windows.png` (or any supported image format). ICO will be produced of 256 px size. Defaults to `assets/icon.png`. If `assets/icon_windows.ico` file is provided it will be just copied to `windows/runner/resources/app_icon.ico` unmodified.
* macOS - `assets/icon_macos.png` (or any supported image format). Recommended minimum image size is 1024 px. Defaults to `assets/icon.png`.

## Splash screens

* iOS (light) - `assets/splash_ios.png` (or any supported image format). Defaults to `assets/splash.png` and then `assets/icon.png`.
* iOS (dark) - `assets/splash_dark_ios.png` (or any supported image format). Defaults to light iOS splash, then to `assets/splash_dark.png`, then to `assets/splash.png` and then `assets/icon.png`.
* Android (light) - `assets/splash_android.png` (or any supported image format). Defaults to `assets/splash.png` and then `assets/icon.png`.
* Android (dark) - `assets/splash_dark_android.png` (or any supported image format).  Defaults to light Android splash, then to `assets/splash_dark.png`, then to `assets/splash.png` and then `assets/icon.png`.
* Web (light) - `assets/splash_web.png` (or any supported image format). Defaults to `assets/splash.png` and then `assets/icon.png`.
* Web (dark) - `assets/splash_dark_web.png` (or any supported image format). Defaults to light web splash, then `assets/splash_dark.png`, then to `assets/splash.png` and then `assets/icon.png`.

flet build apk 
           FAILURE: Build completed with 2 failures.

           1: Task failed with an exception.
           -----------
           * What went wrong:
           A problem occurred configuring project ':file_picker'.
           > Failed to notify project evaluation listener.
              > Could not get unknown property 'android' for project ':file_picker' of type org.gradle.api.Project.
              > Could not find method implementation() for arguments  on object of type
           org.gradle.api.internal.artifacts.dsl.dependencies.DefaultDependencyHandler.
              > Could not get unknown property 'android' for project ':file_picker' of type org.gradle.api.Project.

           * Try:
           > Run with --stacktrace option to get the stack trace.
           > Run with --info or --debug option to get more log output.
           > Run with --scan to get full insights.
           > Get more help at https://help.gradle.org.
           ==============================================================================

           2: Task failed with an exception.
           -----------
           * What went wrong:
           Failed to query the value of property 'buildFlowServiceProperty'.
           > Could not isolate value
           org.jetbrains.kotlin.gradle.plugin.statistics.BuildFlowService$Parameters_Decorated@2b4d10a0 of type
           BuildFlowService.Parameters
              > A problem occurred configuring project ':file_picker'.
                 > Failed to notify project evaluation listener.
                    > Could not get unknown property 'android' for project ':file_picker' of type
           org.gradle.api.Project.
                    > Could not find method implementation() for arguments  on object of type
           org.gradle.api.internal.artifacts.dsl.dependencies.DefaultDependencyHandler.
                    > Could not get unknown property 'android' for project ':file_picker' of type
           org.gradle.api.Project.

           * Try:
           > Run with --stacktrace option to get the stack trace.
           > Run with --info or --debug option to get more log output.
           > Run with --scan to get full insights.
           > Get more help at https://help.gradle.org.
           ==============================================================================

           BUILD FAILED in 21s           Gradle task assembleRelease failed with exit code 1
以上問題是flet 版本衝突問題

flet build 會把所有 跟目錄/下的所有檔案打包