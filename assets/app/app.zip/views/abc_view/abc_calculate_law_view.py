from abc import ABC, abstractmethod
import flet as ft

from functions.language_dict_functions import set_text_by_language
from views.route_dicts import route_formula_dict
from functions.unit_functions import *
from views.abc_view.abc_view import AbcView


class CalculateLawViewClass(AbcView, ABC):
    def __init__(self, page):
        super().__init__(page)
        self.font_size = 20
        self.font_color = 'white'
        self.dropdown_width = 133

        # 文字
        self.result_str = f'{set_text_by_language('輸入', self.lang)}{set_text_by_language('錯誤', self.lang)}'
        self.calculate_text = set_text_by_language('計算', self.lang)

        self.equation_text = ft.Text(self.get_equation_text(), size=self.font_size)
        self.equal_sign_text = ft.Text("=", size=self.font_size)

        self.all_ccc_list_symbol_dict = self.get_all_ccc_list_symbol_dict()
        self.all_symbol_calculate_on_change_function_dict = self.get_all_symbol_calculate_on_change_function_dict()
        self.all_ccc_list = list(self.all_ccc_list_symbol_dict.values())
        self.all_symbol_aa_list = list(self.all_ccc_list_symbol_dict.keys())
        self.selected_unit = None
        self.calculate_ui = None
        self.ccc_list = None

        self.all_symbol_option_name_dict = self.get_all_symbol_option_name_dict()

        self.calculate_selector = ft.Dropdown(
            options=[
                ft.dropdown.Option(key=symbol, text=f"{self.calculate_text} {option_name} {symbol}") for symbol, option_name in self.all_symbol_option_name_dict.items()
            ],
            on_change=self.calculate_selector_on_change,
            border_color=ft.Colors.WHITE,
        )

        self.textfield_list = [
            self.get_textfield(
                keyboard_type=ft.KeyboardType.PHONE,
                color=self.font_color,
                border_color=ft.Colors.WHITE,
                expand=True,
                height=50
            )
            for _ in range(len(self.all_ccc_list) - 1)]

        def create_on_dropdown_change(i):
            def handler(e):
                self.calculate_ui(e)
                if self.textfield_list[i].value == '':  # 如果textfield沒有值 -> 選dropdown完focus
                    self.textfield_list[i].focus()
                self.page.update()

            return handler

        self.dropdown_list = [
            ft.Dropdown(
                on_change=create_on_dropdown_change(i),
                width=self.dropdown_width,
                color=self.font_color,
                border_color=ft.Colors.WHITE
            )
            for i in range(len(self.all_ccc_list) - 1)]

        self.result_text = ft.Text(
            value='1',
            width=self.dropdown_width,
            color=self.font_color,
            size=self.font_size,
            expand=True,
            selectable=True
        )
        self.result_dropdown = ft.Dropdown(
            width=self.dropdown_width,
            color=self.font_color,
            border_color=ft.Colors.WHITE
        )
        constant_str_list = self.get_constant_str_list()
        controls_list = [ft.Row([self.equation_text], alignment=ft.MainAxisAlignment.CENTER)]
        controls_list += [ft.Row([ft.Text(str1, size=12)], alignment=ft.MainAxisAlignment.CENTER) for str1 in constant_str_list]
        controls_list.append(ft.Row([self.calculate_selector], alignment=ft.MainAxisAlignment.CENTER))
        controls_list += [ft.Row([self.textfield_list[i], self.dropdown_list[i]], alignment=ft.MainAxisAlignment.CENTER) for i in range(len(self.all_ccc_list) - 1)]
        controls_list += [ft.Row([self.equal_sign_text, self.result_text, self.result_dropdown], alignment=ft.MainAxisAlignment.CENTER)]
        self.main_column = ft.Column(
            controls=controls_list,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
        )
        self.init_page()

    def update_result_from_input(self):
        self.calculate_selector.value = self.selected_unit
        self.ccc_list = self.all_ccc_list.copy()
        self.ccc_list.remove(self.all_ccc_list_symbol_dict[self.selected_unit])
        symbol_aa_list = self.all_symbol_aa_list.copy()
        symbol_aa_list.remove(self.selected_unit)
        resultccc = self.all_ccc_list_symbol_dict[self.selected_unit]
        # 一開始進去
        self.calculate_ui = self.calculate1
        textfield_label_list = [f"{self.all_symbol_option_name_dict[symbol_aa_list[i]]} {symbol_aa_list[i]}" for i in range(len(self.ccc_list))]
        textfield_value_list = [self.get_textfield_value(symbol_aa_list[i]) for i in range(len(self.ccc_list))]
        dropdown_option_list_list = [self.get_zh_dropdown_list(ccc) for ccc in self.ccc_list] if self.lang == 'zh' else [self.get_dropdown_list(ccc) for ccc in self.ccc_list]
        dropdown_value_list = [self.get_default_dropdown_unit_symbol(list(all_unit_dict_dict[ccc].keys())) for ccc in self.ccc_list]
        result_dropdown_option_list = self.get_zh_dropdown_list(resultccc) if self.lang == 'zh' else self.get_dropdown_list(resultccc)
        result_dropdown_value = self.get_default_dropdown_unit_symbol(list(all_unit_dict_dict[resultccc].keys()))
        self.textfield_list[0].autofocus = True
        for i in range(len(self.ccc_list)):
            self.textfield_list[i].label = textfield_label_list[i]
            self.textfield_list[i].value = textfield_value_list[i]
            self.dropdown_list[i].options = dropdown_option_list_list[i]
            self.dropdown_list[i].value = dropdown_value_list[i]
            self.textfield_list[i].on_change = self.calculate_ui
        self.result_dropdown.options = result_dropdown_option_list
        self.result_dropdown.value = result_dropdown_value
        self.result_dropdown.on_change = self.calculate_ui
        self.page.update()

    def init_page(self):
        self.selected_unit = list(self.all_symbol_option_name_dict.keys())[0]
        self.update_result_from_input()

    def calculate_selector_on_change(self, e):
        self.selected_unit = self.calculate_selector.value
        self.update_result_from_input()
        self.calculate_ui(None)

    @abstractmethod
    def calculate1(self, e):
        pass

    @abstractmethod
    def get_all_ccc_list_symbol_dict(self):
        pass

    @abstractmethod
    def get_all_symbol_option_name_dict(self):
        pass

    @abstractmethod
    def get_all_symbol_calculate_on_change_function_dict(self):
        pass

    def get_route(self):
        return self.route

    def get_equation_text(self):
        route = self.route.replace('/', '')
        return route_formula_dict.get(route)

    def get_constant_str_list(self):
        return []

    # dropdown_unit 預設dropdown選項
    def get_default_dropdown_unit_symbol(self, unit_list):
        return unit_list[0]

    # textfield_value 預設
    def get_textfield_value(self, ccc=''):
        return '1'
