from abc import ABC
import flet as ft
from views.route_dicts import *
from views.abc_view.abc_view import AbcView


class AbcMenuView(AbcView, ABC):
    def __init__(self, page):
        super().__init__(page)
        self.button_height = 100
        self.subject = self.route.replace('/', '').split('_')[0]
        self.route_list = subject_route_dict.get(self.subject) if self.subject != '' else self.new_route_name_dict.keys()
        self.button_list = self.create_button_list_from_route_list(self.route_list)
        if len(self.route_list) > 10:
            self.main_column = ft.Column(
                [
                    ft.Row(button_pair, alignment=ft.MainAxisAlignment.SPACE_EVENLY)
                    for button_pair in [self.button_list[i:i + 2] for i in range(0, len(self.button_list), 2)]
                ],
                expand=True,
                alignment=ft.MainAxisAlignment.CENTER,
                scroll=ft.core.types.ScrollMode.ADAPTIVE,
            )
        else:
            self.button_width = 200
            self.main_column = ft.Column(
                self.button_list,
                expand=True,
                alignment=ft.MainAxisAlignment.CENTER,
                scroll=ft.core.types.ScrollMode.ADAPTIVE
            )

    def create_button_list_from_route_list(self, route_list):
        button_height = self.button_height
        button_width = 170 if len(route_list) > 10 else 200
        button_style = ft.ButtonStyle(side=ft.BorderSide(1, ft.Colors.WHITE))
        button_name_dict = {
            '/' + route: (
                f"{self.new_route_name_dict.get(route)}"
                if route_formula_dict.get(route, '') == ''
                else f"{self.new_route_name_dict.get(route, '')}\n{route_formula_dict.get(route, '')}"
            )
            for route in route_list
        }
        return [
            ft.ElevatedButton(
                title, on_click=lambda _, route=route1: self.page.go(route), height=button_height, width=button_width, style=button_style
            )
            for route1, title in button_name_dict.items()
        ]
