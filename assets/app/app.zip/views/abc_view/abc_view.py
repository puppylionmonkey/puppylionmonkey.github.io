from abc import ABC
import flet as ft
from functions.common_funtions import format_number
from functions.language_dict_functions import get_language
from views.route_dicts import *
from functions.unit_functions import all_unit_dict_dict, ureg


class AbcView(ABC):
    def __init__(self, page):
        self.page = page
        self.route = self.page.route
        self.main_column = None
        self.lang = get_language()
        # language
        self.new_route_name_dict = route_name_dict if self.lang == 'zh' else route_english_name_dict

    def get_view(self):
        return ft.View(
            self.route,
            controls=[
                ft.Container(content=self.main_column, expand=True, alignment=ft.alignment.top_center),
            ],
            padding=ft.padding.only(bottom=120 if self.page.platform == ft.PagePlatform.ANDROID else 70, left=10, right=10, top=70 if self.page.platform == ft.PagePlatform.ANDROID else 40),
        )

    @staticmethod
    def get_dropdown_list(unit):
        return [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in all_unit_dict_dict[unit].items()]

    @staticmethod
    def get_zh_dropdown_list(unit):
        return [ft.dropdown.Option(text=f'{name} ({unit_symbol})' if unit_symbol != name else unit_symbol, key=unit_symbol) for unit_symbol, name in all_unit_dict_dict[unit].items()]

    def get_unit_conversion_row(self, base_value, base_unit, unit, label):  # todo:refactor
        base_value_ureg = ureg.parse_expression(f'{base_value} {base_unit}')
        value_text = ft.Text(format_number(base_value_ureg.magnitude), width=100, selectable=True)

        def on_unit_change(e):
            new_ureg = base_value_ureg.to(dropdown.value)
            value_text.value = format_number(new_ureg.magnitude)
            value_text.update()

        dropdown = ft.Dropdown(
            options=self.get_dropdown_list(unit),
            value=base_unit,
            width=133,
            on_change=on_unit_change
        )

        return ft.Row(
            [ft.Text(label, width=130) if label != '' else None, value_text, dropdown],
            alignment=ft.MainAxisAlignment.CENTER
        )

    @staticmethod
    def get_textfield(label='', value='', on_change=None, expand=False, autofocus=False,
                      border_color=None, hint_text='', keyboard_type=None, on_focus=None,
                      color=None, height=50, dense=False, visible=True, width=150,
                      icon=None,
                      multiline=False,
                      min_lines=1,
                      max_lines=1,
                      ):
        tf = ft.TextField(
            label=label,
            value=value,
            expand=expand,
            autofocus=autofocus,
            border_color=border_color,
            hint_text=hint_text,
            keyboard_type=keyboard_type,
            on_focus=on_focus,
            on_change=on_change,
            color=color,
            height=height,
            dense=dense,
            visible=visible,
            width=width,
            icon=icon,
            multiline=multiline,
            min_lines=min_lines,
            max_lines=max_lines,
        )

        def clear_text(e):
            tf.value = ""
            tf.update()

        tf.suffix = ft.IconButton(icon=ft.Icons.CLOSE, on_click=clear_text, icon_color=ft.Colors.GREY_500, icon_size=15)
        tf.on_change = on_change
        return tf
