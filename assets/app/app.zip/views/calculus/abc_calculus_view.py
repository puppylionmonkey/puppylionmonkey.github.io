import flet as ft
from abc import ABC

from functions.language_dict_functions import set_text_by_language
from views.abc_view.abc_view import AbcView


class AbcCalculusView(AbcView, ABC):
    def __init__(self, page):
        super().__init__(page)
        self.font_size = 20

        #########################################
        # 範例
        example_label = "x**2\nsin(x)\nx*sin(x)\ne**x\nlog(x, 底數)\nasin(x)\nsinh(x)"
        self.example_dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(set_text_by_language("範例", self.lang)),
            content=ft.Text(example_label, size=self.font_size, selectable=True),
            actions_alignment=ft.MainAxisAlignment.END,
            actions=[
                ft.TextButton(set_text_by_language("關閉", self.lang), on_click=lambda e: page.close(self.example_dialog)),
            ],
        )
        self.input_example_button = ft.IconButton(
            icon=ft.Icons.INFO_OUTLINE,
            tooltip=set_text_by_language("範例", self.lang),
            on_click=lambda e: page.open(self.example_dialog)
        )
        #########################################
    # x=5, y=3 -> {x:5, y:3}
    @staticmethod
    def parse_variable_input(text: str):
        try:
            return {k.strip(): float(v.strip()) for k, v in (pair.split('=') for pair in text.split(','))}
        except:
            raise ValueError("變數值格式錯誤，請使用 x=1 或 x=1, y=2")
