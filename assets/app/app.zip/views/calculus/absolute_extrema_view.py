import flet as ft
from sympy import symbols
from sympy.parsing.sympy_parser import (
    parse_expr, standard_transformations,
    implicit_multiplication_application, convert_xor
)
from functions.language_dict_functions import set_text_by_language
from functions.common_funtions import format_number
from views.calculus.abc_calculus_view import AbcCalculusView

transformations = standard_transformations + (implicit_multiplication_application, convert_xor)

from functions.math.derivative_integral_functions import evaluate_absolute_extrema

class AbsoluteExtremaView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        self.expr_label = set_text_by_language("輸入函數", self.lang)
        self.points_label = set_text_by_language("輸入點（格式如 x=1,y=2；每行一個）", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        self.input_expr = self.get_textfield(label=self.expr_label, expand=True, autofocus=True, on_change=self.calculate)
        self.input_points = ft.TextField(label=self.points_label, multiline=True, min_lines=3, max_lines=5, expand=True, on_change=self.calculate)

        self.result_table = ft.DataTable(
            columns=[
                ft.DataColumn(label=ft.Text("點")),
                ft.DataColumn(label=ft.Text("f 值")),
            ],
            rows=[]
        )

        self.max_text = ft.Text(size=self.font_size)
        self.min_text = ft.Text(size=self.font_size)

        self.main_column = ft.Column([
            ft.Row([self.input_expr, self.input_example_button]),
            self.input_points,
            self.result_table,
            self.max_text,
            self.min_text,
        ],
        alignment=ft.MainAxisAlignment.START,
        expand=True,
        scroll=ft.ScrollMode.ADAPTIVE,
        spacing=15)

        self.init_view()

    def init_view(self):
        self.input_expr.value = "3*x*y - 6*x - 3*y + 5"
        self.input_points.value = "x=0,y=0\nx=4,y=0\nx=0,y=5"
        self.calculate(None)

    def parse_points(self):
        lines = self.input_points.value.strip().split("\n")
        point_list = []
        for line in lines:
            try:
                pairs = [kv.split("=") for kv in line.split(",") if "=" in kv]
                point = {symbols(k.strip()): float(v.strip()) for k, v in pairs}
                point_list.append(point)
            except:
                continue
        return point_list

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            points = self.parse_points()
            result = evaluate_absolute_extrema(expr_str, points)

            self.result_table.rows.clear()
            for pt, val in result["all"]:
                pt_str = ", ".join([f"{k}={format_number(v)}" for k, v in pt.items()])
                self.result_table.rows.append(
                    ft.DataRow(cells=[
                        ft.DataCell(ft.Text(pt_str)),
                        ft.DataCell(ft.Text(format_number(val))),
                    ])
                )

            max_pt, max_val = result["max"]
            min_pt, min_val = result["min"]

            max_str = ", ".join([f"{k}={format_number(v)}" for k, v in max_pt.items()])
            min_str = ", ".join([f"{k}={format_number(v)}" for k, v in min_pt.items()])

            self.max_text.value = f"最大值：f({max_str}) = {format_number(max_val)}"
            self.min_text.value = f"最小值：f({min_str}) = {format_number(min_val)}"

        except Exception as ex:
            self.result_table.rows.clear()
            self.result_table.rows.append(
                ft.DataRow(cells=[
                    ft.DataCell(ft.Text(f"{self.error_prefix_text}：{str(ex)}")),
                    ft.DataCell(ft.Text("")),
                ])
            )
            self.max_text.value = ""
            self.min_text.value = ""

        self.page.update()
