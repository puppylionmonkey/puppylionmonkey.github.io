import flet as ft
from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import analyze_critical_points
from sympy.parsing.sympy_parser import standard_transformations, implicit_multiplication_application, convert_xor

from views.calculus.abc_calculus_view import AbcCalculusView


class AnalyzeCriticalPointsView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20
        self.transforms = standard_transformations + (
            implicit_multiplication_application, convert_xor
        )

        input_expr_label = set_text_by_language("輸入函數", self.lang)
        self.result_prefix_text = set_text_by_language("臨界點分析結果", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        self.input_expr = self.get_textfield(
            label=input_expr_label, expand=True, autofocus=True, on_change=self.calculate
        )

        self.data_table = ft.DataTable(
            columns=[
                ft.DataColumn(label=ft.Text("臨界點")),
                ft.DataColumn(label=ft.Text("類型")),
                ft.DataColumn(label=ft.Text("Hessian 行列式")),
            ],
            rows=[],
        )

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                self.data_table,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            spacing=15,
        )
        self.init_view()

    def init_view(self):
        self.input_expr.value = "3*x*y**2 - 2*x**2*y + 36*x*y"
        self.calculate(None)

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            results = analyze_critical_points(expr_str)

            self.data_table.rows.clear()
            for r in results:
                point_str = ", ".join([f"{k}={format_number(v)}" for k, v in r["point"].items()])
                row = ft.DataRow(cells=[
                    ft.DataCell(ft.Text(point_str)),
                    ft.DataCell(ft.Text(r["type"])),
                    ft.DataCell(ft.Text(str(r["det"]))),
                ])
                self.data_table.rows.append(row)

        except Exception as ex:
            self.data_table.rows.clear()
            self.data_table.rows.append(
                ft.DataRow(cells=[
                    ft.DataCell(ft.Text(f"{self.error_prefix_text}：{str(ex)}")),
                    ft.DataCell(ft.Text("")),
                    ft.DataCell(ft.Text("")),
                ])
            )

        self.page.update()
