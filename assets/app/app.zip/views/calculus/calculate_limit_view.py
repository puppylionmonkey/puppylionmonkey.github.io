import flet as ft
from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import limit_expression
from views.calculus.abc_calculus_view import AbcCalculusView


# todo:英文 預先填入
class CalculateLimitView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        self.expr_input = self.get_textfield(label=set_text_by_language("輸入函數", self.lang), autofocus=True, on_change=self.calculate_limit, border_color=ft.Colors.WHITE, expand=True)
        self.approach_input = self.get_textfield(label="x 趨近於", hint_text="例如：oo, -oo, 0, 5, 3+, 3-", on_change=self.calculate_limit, border_color=ft.Colors.WHITE, expand=True)
        self.result_text = ft.Text(size=20, selectable=True, )

        self.down_text = ft.Text(f'x->{self.approach_input.value}', size=15)
        self.expr_str_text = ft.Text(self.expr_input.value, size=20)

        self.left_column = ft.Column([ft.Text('lim', size=30), self.down_text], spacing=0)
        self.equation_row = ft.Row([self.left_column, self.expr_str_text, self.result_text], spacing=-1, alignment=ft.MainAxisAlignment.CENTER)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.expr_input, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.approach_input], alignment=ft.MainAxisAlignment.CENTER),
                self.equation_row,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )
        self.init_view()

    def init_view(self):
        self.expr_input.value = '(3 - 4x)/(5x + 6)'
        self.approach_input.value = 'oo'
        self.calculate_limit(None)

    def calculate_limit(self, e):
        try:
            result = limit_expression(self.expr_input.value, self.approach_input.value)
            self.expr_str_text.value = convert_expression_to_pretty(self.expr_input.value)
            self.down_text.value = f'x->{self.approach_input.value}'
            self.result_text.value = f" = {format_number(result)}"
        except Exception as ex:
            self.result_text.value = f"❌ 錯誤：{ex}"
        self.page.update()
