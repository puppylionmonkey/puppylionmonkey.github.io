import flet as ft
from functions.language_dict_functions import set_text_by_language
from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.math.calculate_sigma_functions import calculate_sigma
from views.calculus.abc_calculus_view import AbcCalculusView


class CalculateSigmaView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        # Labels
        expr_label = set_text_by_language("輸入一個總和公式（如 3x + 4）", self.lang)
        start_label = set_text_by_language("起始值", self.lang)
        end_label = set_text_by_language("結束值", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        # Input fields
        self.input_expr = self.get_textfield(label=expr_label, value="", on_change=self.calculate, expand=True)
        self.input_start = self.get_textfield(label=start_label, expand=True, value="", on_change=self.calculate)
        self.input_end = self.get_textfield(label=end_label, expand=True, value="", on_change=self.calculate)

        # Result text
        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)

        # equation_row
        self.input_start_value_text = ft.Text()
        self.input_end_value_text = ft.Text()
        self.left_column = ft.Column([self.input_end_value_text, ft.Text('∑', size=30), self.input_start_value_text], spacing=0)
        self.expr_str_text = ft.Text(size=20)
        self.equation_row = ft.Row([self.left_column, self.expr_str_text, self.result_text], spacing=-1, alignment=ft.MainAxisAlignment.CENTER)

        # Layout
        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_start, self.input_end], alignment=ft.MainAxisAlignment.CENTER),
                self.equation_row,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_page()

    def init_page(self):
        self.input_expr.value = '3x+4'
        self.input_start.value = '1'
        self.input_end.value = '10'
        self.calculate(None)

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            start = int(self.input_start.value.strip())
            end = int(self.input_end.value.strip())
            result = calculate_sigma(expr_str, start, end)
            self.input_start_value_text.value = f'x={start}'
            self.input_end_value_text.value = end
            self.expr_str_text.value = convert_expression_to_pretty(expr_str)
            self.result_text.value = f" = {format_number(result)}"
        except Exception as ex:
            self.result_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()
