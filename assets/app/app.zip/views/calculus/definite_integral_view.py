import flet as ft

from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import definite_integral
from views.calculus.abc_calculus_view import AbcCalculusView


class DefiniteIntegralView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        self.label_expr = set_text_by_language("輸入函數", self.lang)
        self.label_lower = set_text_by_language("下限（如 0）", self.lang)
        self.label_upper = set_text_by_language("上限（如 2）", self.lang)
        self.result_prefix_text = set_text_by_language("結果", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        self.input_expr = self.get_textfield(label=self.label_expr, expand=True, autofocus=True, on_change=self.calculate)
        self.input_lower = self.get_textfield(label=self.label_lower, expand=True, on_change=self.calculate)
        self.input_upper = self.get_textfield(label=self.label_upper, expand=True, on_change=self.calculate)

        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)

        # show equation
        self.input_lower_text = ft.Text(self.input_lower.value, size=16)
        self.input_upper_text = ft.Text(self.input_upper.value, size=16)
        self.expr_str_text = ft.Text(f'{self.input_expr.value}dx', size=20)
        self.equation_row = ft.Row([ft.Text('∫', size=30), ft.Column([self.input_upper_text, self.input_lower_text]), self.expr_str_text, self.result_text])

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_lower, self.input_upper], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.equation_row], alignment=ft.MainAxisAlignment.CENTER),
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_view()

    def init_view(self):
        self.input_expr.value = '3x-2'
        self.input_lower.value = '-4'
        self.input_upper.value = '2'
        self.calculate(None)

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            lower_str = self.input_lower.value.strip()
            upper_str = self.input_upper.value.strip()

            if not expr_str or not lower_str or not upper_str:
                self.result_text.value = ""
                self.page.update()
                return

            result = definite_integral(expr_str, float(lower_str), float(upper_str))
            self.input_lower_text.value = self.input_lower.value
            self.input_upper_text.value = self.input_upper.value
            self.expr_str_text.value = f'{convert_expression_to_pretty(self.input_expr.value)}dx'
            self.result_text.value = f" = {format_number(result)}"

        except Exception as ex:
            self.result_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()
