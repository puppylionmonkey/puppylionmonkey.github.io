import flet as ft
from functions.common_funtions import format_number
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import directional_derivative
from views.calculus.abc_calculus_view import AbcCalculusView


class DirectionalDerivativeView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        # UI Labels
        input_expr_label = set_text_by_language("輸入函數", self.lang)
        input_point_label = set_text_by_language("輸入變數值（如 x=1, y=3）", self.lang)
        input_vector_label = set_text_by_language("方向向量（如 3,4）", self.lang)
        self.result_prefix_text = set_text_by_language("結果", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        # UI Inputs
        self.input_expr = self.get_textfield(label=input_expr_label, expand=True, autofocus=True, on_change=self.calculate)
        self.input_values = self.get_textfield(label=input_point_label, expand=True, on_change=self.calculate)
        self.input_vector = self.get_textfield(label=input_vector_label, expand=True, on_change=self.calculate)

        # UI Outputs
        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_values], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_vector], alignment=ft.MainAxisAlignment.CENTER),
                self.result_text,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
            spacing=15,
        )
        self.init_view()

    def init_view(self):
        self.input_expr.value = "xy + 4x"
        self.input_values.value = "x=1, y=3"
        self.input_vector.value = "3,4"
        self.calculate(None)

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()

            # 解析變數點 x=1, y=3 → {'x':1, 'y':3}
            var_dict = self.parse_variable_input(self.input_values.value)
            point = [v for k, v in sorted(var_dict.items())]

            # 解析方向向量 3,4 → [3, 4]
            direction = [float(v.strip()) for v in self.input_vector.value.strip().split(",")]

            result = directional_derivative(expr_str, tuple(point), tuple(direction))

            self.result_text.value = f"{self.result_prefix_text}：{format_number(result)}"
        except Exception as ex:
            self.result_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()
