import flet as ft
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import get_extrema
from views.calculus.abc_calculus_view import AbcCalculusView


class ExtremaOnIntervalView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        input_expr_label = set_text_by_language("輸入函數", self.lang)
        input_range_label = set_text_by_language("輸入區間（如 -2,2）", self.lang)
        self.result_max_text = set_text_by_language("區間最大值", self.lang)
        self.result_min_text = set_text_by_language("區間最小值", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        self.input_expr_textfield = self.get_textfield(label=input_expr_label, expand=True, autofocus=True, on_change=self.calculate)
        self.input_range_textfield = self.get_textfield(label=input_range_label, expand=True, on_change=self.calculate)
        self.result_max = ft.Text(value="", selectable=True, size=self.font_size)
        self.result_min = ft.Text(value="", selectable=True, size=self.font_size)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr_textfield, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_range_textfield], alignment=ft.MainAxisAlignment.CENTER),
                self.result_max,
                self.result_min
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_view()

    def init_view(self):
        self.input_expr_textfield.value = "x**3"
        self.input_range_textfield.value = "-2, 2"
        self.calculate(None)

    def calculate(self, e):
        try:
            expr_str = self.input_expr_textfield.value.strip()
            a_str, b_str = self.input_range_textfield.value.strip().split(',')
            a = float(a_str.strip())
            b = float(b_str.strip())

            result = get_extrema(expr_str, a, b)
            max_x, max_y = result["max"]
            min_x, min_y = result["min"]

            self.result_max.value = f"{self.result_max_text}：x = {max_x}, f(x) = {round(max_y, 5)}"
            self.result_min.value = f"{self.result_min_text}：x = {min_x}, f(x) = {round(min_y, 5)}"

        except Exception as ex:
            self.result_max.value = f"{self.error_prefix_text}：{str(ex)}"
            self.result_min.value = ""

        self.page.update()
