import flet as ft
from sympy.parsing.sympy_parser import standard_transformations, implicit_multiplication_application, convert_xor

from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import compute_gradient, gradient_at_point
from views.calculus.abc_calculus_view import AbcCalculusView


class GradientView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20
        self.transforms = standard_transformations + (implicit_multiplication_application, convert_xor)

        input_expr_label = set_text_by_language("輸入函數", self.lang)
        input_value_label = set_text_by_language("輸入變數值（x=1, y=2）", self.lang)
        self.result_prefix_text = set_text_by_language("梯度向量", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        self.input_expr = self.get_textfield(label=input_expr_label, expand=True, autofocus=True, on_change=self.calculate)
        self.input_values = self.get_textfield(label=input_value_label, expand=True, on_change=self.get_input_values_result)
        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)
        self.eval_text = ft.Text(value="", selectable=True, size=self.font_size)

        self.expr_str = ""

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                self.result_text,
                ft.Divider(),
                ft.Row([self.input_values], alignment=ft.MainAxisAlignment.CENTER),
                self.eval_text,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_view()

    def init_view(self):
        self.input_expr.value = "z**2 - 2*x**2 - 2*y**2 - 21"
        self.input_values.value = "x=1, y=-1, z=5"
        self.calculate(None)
        self.get_input_values_result(None)

    def calculate(self, e):
        try:
            self.expr_str = self.input_expr.value.strip()
            grad_expr = compute_gradient(self.expr_str)
            pretty_grad = ', '.join([convert_expression_to_pretty(str(term)) for term in grad_expr])
            self.result_text.value = f"{self.result_prefix_text}：[{pretty_grad}]"
            self.get_input_values_result(e)
        except Exception as ex:
            self.result_text.value = ""
            self.eval_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()

    def get_input_values_result(self, e):
        try:
            values = self.parse_variable_input(self.input_values.value)
            evaluated = gradient_at_point(self.expr_str, values)
            result_str = ', '.join([format_number(v) for v in evaluated])
            self.eval_text.value = f"代入變數結果：[{result_str}]"
        except Exception as ex:
            self.eval_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()
