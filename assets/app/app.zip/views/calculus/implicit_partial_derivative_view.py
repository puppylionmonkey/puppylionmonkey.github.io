import flet as ft

from functions.common_funtions import convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import implicit_derivative
from views.calculus.abc_calculus_view import AbcCalculusView


# todo: 偏微分重複?
class ImplicitPartialDerivativeView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        # 輸入欄位
        self.input_eq = self.get_textfield(label="輸入等式", value="", on_change=self.calculate, expand=True)
        self.input_num = self.get_textfield(label="分子（如 y）", value="", on_change=self.calculate, width=100)
        self.input_denom = self.get_textfield(label="分母（如 x）", value="", on_change=self.calculate, width=100)
        self.input_order = self.get_textfield(label="階數（1 或 2）", value="1", on_change=self.calculate, width=100)

        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)

        # 展示列：顯示 dy/dx = ...
        self.formula_display = ft.Row(controls=[], alignment=ft.MainAxisAlignment.CENTER)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_eq, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_num, self.input_denom, self.input_order], alignment=ft.MainAxisAlignment.CENTER),
                self.formula_display,
                self.result_text
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_page()

    def calculate(self, e):
        try:
            equation = self.input_eq.value.strip()
            numerator = self.input_num.value.strip()
            denominator = self.input_denom.value.strip()
            order = int(self.input_order.value.strip())

            result = implicit_derivative(equation, numerator, denominator, order)

            display_label = f"d{numerator}/d{denominator}" if order == 1 else f"d²{numerator}/d{denominator}²"

            self.formula_display.controls = [
                ft.Text(f"{display_label} =", size=self.font_size, selectable=True),
                ft.Text(convert_expression_to_pretty(str(result)), size=self.font_size, weight=ft.FontWeight.BOLD, selectable=True)
            ]
            self.result_text.value = ""

        except Exception as ex:
            self.formula_display.controls = []
            self.result_text.value = f"{self.error_prefix_text}：{str(ex)}"

        self.page.update()

    def init_page(self):
        self.input_eq.value = "6x-3y+15=0"
        self.input_num.value = "y"
        self.input_denom.value = "x"
        self.input_order.value = "1"
        self.calculate(None)
