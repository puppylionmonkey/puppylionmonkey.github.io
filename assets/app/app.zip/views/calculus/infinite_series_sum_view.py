import flet as ft
from functions.language_dict_functions import set_text_by_language
from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.math.derivative_integral_functions import infinite_series_sum
from views.calculus.abc_calculus_view import AbcCalculusView


class InfiniteSeriesSumView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        # Labels
        expr_label = set_text_by_language("輸入通項（如 3k/2**k）", self.lang)
        start_label = set_text_by_language("起始值（如 1）", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)
        self.divergent_text = set_text_by_language("此級數發散", self.lang)

        # Input fields
        self.input_expr = self.get_textfield(label=expr_label, value="", on_change=self.calculate, expand=True)
        self.input_start = self.get_textfield(label=start_label, value="1", on_change=self.calculate, expand=True)

        # Result display
        self.input_start_value_text = ft.Text()
        self.left_column = ft.Column([ft.Text("∞"), ft.Text('∑', size=30), self.input_start_value_text], spacing=0)
        self.expr_str_text = ft.Text(size=self.font_size)
        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)
        self.equation_row = ft.Row([self.left_column, self.expr_str_text, self.result_text], spacing=-1, alignment=ft.MainAxisAlignment.CENTER)

        # Layout
        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                self.input_start,
                self.equation_row,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_page()

    def init_page(self):
        self.input_expr.value = '(3**k + 2**k)/(4**k)'
        self.input_start.value = '1'
        self.calculate(None)

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            start = int(self.input_start.value.strip())
            result, is_convergent = infinite_series_sum(expr_str, start)

            self.input_start_value_text.value = f'k={start}'
            self.expr_str_text.value = convert_expression_to_pretty(expr_str)

            if is_convergent:
                self.result_text.value = f" = {format_number(result)}"
            else:
                self.result_text.value = f" = {self.divergent_text}"
        except Exception as ex:
            self.result_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()
