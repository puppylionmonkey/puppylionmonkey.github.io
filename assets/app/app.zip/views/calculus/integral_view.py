import flet as ft
from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.calculate_equation_functions import evaluate_expression_multi
from functions.math.derivative_integral_functions import *
from sympy.parsing.sympy_parser import standard_transformations, implicit_multiplication_application, convert_xor

from views.calculus.abc_calculus_view import AbcCalculusView


# todo:分開calculate
# todo美化:拿掉結果，用等式
class IntegralView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20
        self.transforms = standard_transformations + (implicit_multiplication_application, convert_xor)

        input_expr_label = set_text_by_language("輸入一個方程式", self.lang)
        input_value_label = set_text_by_language("輸入變數值（如 x=2 或 x=2, y=3）", self.lang)
        self.error_no_variable_text = set_text_by_language("錯誤：找不到變數", self.lang)
        self.result_prefix_text = set_text_by_language("結果", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        self.input_expr = self.get_textfield(label=input_expr_label, expand=True, autofocus=True, on_change=self.calculate)
        self.input_values = self.get_textfield(label=input_value_label, expand=True, on_change=self.calculate)
        self.eval_text = ft.Text(value="", selectable=True, size=self.font_size)
        self.integrate_expr = ''
        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                self.result_text,
                ft.Divider(),
                ft.Row([self.input_values], alignment=ft.MainAxisAlignment.CENTER),
                self.eval_text,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_view()

    def init_view(self):
        self.input_expr.value = 'x**5'
        self.input_values.value = 'x=2'
        self.calculate(None)
        self.get_input_values_result(None)

    def get_input_values_result(self, e):
        values = self.parse_variable_input(self.input_values.value)
        evaluated = evaluate_expression_multi(str(self.integrate_expr), values)
        self.eval_text.value = f"代入變數結果：{format_number(evaluated)}"

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            self.integrate_expr = integrate_expression(expr_str)
            result_str = f"{self.result_prefix_text}：{convert_expression_to_pretty(str(self.integrate_expr))}"
            self.get_input_values_result(e)
            self.result_text.value = result_str
        except Exception as ex:
            self.eval_text.value = f"{self.error_prefix_text}：{str(ex)}"

        self.page.update()
