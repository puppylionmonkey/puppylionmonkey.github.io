import flet as ft
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import is_differentiable
from views.calculus.abc_calculus_view import AbcCalculusView


class IsDifferentiableView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        # 多語系文字
        input_expr_label = set_text_by_language("輸入函數", self.lang)
        input_point_label = set_text_by_language("輸入判斷點（x=1, y=2）", self.lang)
        self.result_prefix_text = set_text_by_language("是否可微", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        # UI 元件
        self.input_expr = self.get_textfield(label=input_expr_label, expand=True, autofocus=True, on_change=self.check_differentiability)
        self.input_values = self.get_textfield(label=input_point_label, expand=True, on_change=self.check_differentiability)
        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_values], alignment=ft.MainAxisAlignment.CENTER),
                self.result_text
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
            spacing=15
        )

        self.init_view()

    def init_view(self):
        self.input_expr.value = "3x + xy"
        self.input_values.value = "x=1, y=2"
        self.check_differentiability(None)

    def check_differentiability(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            x0y0 = self.parse_variable_input(self.input_values.value)
            x0, y0 = x0y0.get("x"), x0y0.get("y")

            if x0 is None or y0 is None:
                raise ValueError("請輸入 x 與 y 的數值")

            if is_differentiable(expr_str, x0, y0):
                result = f"{self.result_prefix_text}：✅"
            else:
                result = f"{self.result_prefix_text}：❌"

            self.result_text.value = result
        except Exception as ex:
            self.result_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()


