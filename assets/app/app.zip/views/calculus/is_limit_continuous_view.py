import flet as ft
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import check_continuity_piecewise
from views.calculus.abc_calculus_view import AbcCalculusView


# todo:英文 預先填入
class IsLimitContinuousView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        self.multiline_input = self.get_textfield(
            label="輸入分段函數（每行格式如：3x, x>3）",
            height=200,
            multiline=True,
            min_lines=4,
            max_lines=10,
            expand=True,
            on_change=self.check_continuity,
            border_color=ft.Colors.WHITE,
        )
        self.point_input = self.get_textfield(
            label="判斷連續的 x 值", width=150,
            on_change=self.check_continuity,
            border_color=ft.Colors.WHITE,
        )
        self.result_text = ft.Text(size=16)

        example_label = f"{set_text_by_language('範例', self.lang)}：\n3x, x>3\n9, x=3\nx+6, x<3"
        self.example_text = ft.Text(example_label, size=16, color=ft.Colors.GREY_500, italic=True, selectable=True)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.multiline_input, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.point_input], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.example_text], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.result_text], alignment=ft.MainAxisAlignment.CENTER),
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
        )
        self.init_view()

    def init_view(self):
        self.multiline_input.value = '3x, x>3\n9, x=3\nx+6, x<3'
        self.point_input.value = '3'
        self.check_continuity(None)

    def check_continuity(self, e):
        try:
            lines = self.multiline_input.value.strip().splitlines()
            point_val = float(self.point_input.value.strip())
            pieces = []

            for line in lines:
                if not line.strip():
                    continue
                if "，" not in line and "," not in line:
                    self.result_text.value = "❌ 格式錯誤，請使用,分隔表達式與條件"
                    self.page.update()
                    return
                if "，" in line:
                    expr, cond = line.split("，")
                elif ',' in line:
                    expr, cond = line.split(',')
                pieces.append((expr.strip(), cond.strip()))

            is_continuous = check_continuity_piecewise(pieces, point_val)
            self.result_text.value = "✅ 是連續的" if is_continuous else "❌ 不連續"

        except Exception as ex:
            self.result_text.value = f"❌ 錯誤：{ex}"

        self.page.update()
