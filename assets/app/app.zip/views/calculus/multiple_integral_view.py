import flet as ft
from sympy.parsing.sympy_parser import (
    parse_expr, standard_transformations, implicit_multiplication_application, convert_xor
)
from functions.common_funtions import convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import multiple_integral
from views.calculus.abc_calculus_view import AbcCalculusView


class MultipleIntegralView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20
        self.transforms = standard_transformations + (
            implicit_multiplication_application, convert_xor
        )

        # 多語系設定
        expr_label = set_text_by_language("輸入函數", self.lang)
        limits_label = set_text_by_language("輸入積分順序與上下限，以;分隔多重積分，如(y,x**2,2*x);(x,0,1)", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        # 控制元件
        self.input_expr_textfield = self.get_textfield(label=expr_label, expand=True, autofocus=True, on_change=self.calculate)
        self.input_limits_textfield = self.get_textfield(label=limits_label, expand=True, on_change=self.calculate)

        # 顯示整體式子（積分符號、上下限、dx dy、結果）
        self.integral_expression_container = ft.Column()

        # 主畫面
        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr_textfield, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_limits_textfield], alignment=ft.MainAxisAlignment.CENTER),
                self.integral_expression_container,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.ScrollMode.ADAPTIVE,
            spacing=15,
        )

        self.init_view()

    def init_view(self):
        self.input_expr_textfield.value = "2*y + 4*x"
        self.input_limits_textfield.value = "(y,x**2,2*x);(x,0,1)"
        self.calculate(None)

    def parse_limits_input(self, limits_str: str) -> list[tuple[str, str, str]]:
        """
        將輸入字串 (y,x**2,2*x);(x,0,1) 解析為 [("y", "x**2", "2*x"), ("x", "0", "1")]
        """
        limits = []
        for part in limits_str.split(";"):
            part = part.strip()
            if part.startswith("(") and part.endswith(")"):
                part = part[1:-1]
            else:
                raise ValueError(f"每組積分範圍必須以括號包住：{part}")
            items = part.split(",")
            if len(items) != 3:
                raise ValueError(f"格式錯誤，應為三個項目：{part}")
            var, lower, upper = map(str.strip, items)
            limits.append((var, lower, upper))
        return limits

    def calculate(self, e):
        try:
            expr_str = self.input_expr_textfield.value.strip()
            limits_str = self.input_limits_textfield.value.strip()
            limits = self.parse_limits_input(limits_str)
            result = multiple_integral(expr_str, limits)

            # 重建視覺表示 Row
            self.integral_expression_container.controls.clear()
            full_row = ft.Row(spacing=10, alignment=ft.MainAxisAlignment.CENTER)

            # 每層積分：∫ + 上下限（Column）
            for var, lower, upper in limits[::-1]:  # 外層在右
                full_row.controls.append(
                    ft.Row(
                        [
                            ft.Text("∫", size=24, text_align=ft.TextAlign.CENTER),
                            ft.Column(
                                [
                                    ft.Text(convert_expression_to_pretty(upper), size=14, text_align=ft.TextAlign.CENTER),
                                    ft.Text(convert_expression_to_pretty(lower), size=14, text_align=ft.TextAlign.CENTER),
                                ],
                                spacing=0,
                                alignment=ft.MainAxisAlignment.CENTER
                            )
                        ],
                        spacing=2,
                        alignment=ft.MainAxisAlignment.CENTER
                    )
                )

            # 加上 integrand、dx dy、結果
            integrand_with_differentials = convert_expression_to_pretty(
                f"({expr_str}) " + " ".join(f"d{var}" for var, _, _ in limits[::-1])
            )
            full_row.controls.append(ft.Text(integrand_with_differentials, size=self.font_size))
            full_row.controls.append(ft.Text("=", size=self.font_size))
            full_row.controls.append(ft.Text(convert_expression_to_pretty(str(result)), size=self.font_size))

            self.integral_expression_container.controls.append(full_row)

        except Exception as ex:
            self.integral_expression_container.controls.clear()
            self.integral_expression_container.controls.append(
                ft.Text(f"{self.error_prefix_text}：{str(ex)}", color=ft.Colors.RED, size=self.font_size)
            )

        self.page.update()
