import flet as ft
from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.derivative_integral_functions import multivariable_limit
from views.calculus.abc_calculus_view import AbcCalculusView


# todo:支援oo -oo 5+ 5-
class MultivariableLimitView(AbcCalculusView):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.font_size = 20

        self.expr_input = self.get_textfield(
            label="輸入多變數函數，例如: (x**2 + y**2)/(x**2 + y**2 + 1)",
            autofocus=True,
            on_change=self.calculate_limit,
            border_color=ft.Colors.WHITE,
            expand=True
        )

        self.approach_input = self.get_textfield(
            label="變數趨近值，格式如 x:0, y:0",
            hint_text="例如：x:0, y:0",
            on_change=self.calculate_limit,
            border_color=ft.Colors.WHITE,
            expand=True
        )

        self.result_text = ft.Text(size=20, selectable=True)
        self.expr_str_text = ft.Text(self.expr_input.value, size=20)
        self.down_text = ft.Text(f"({self.approach_input.value})", size=15)
        self.left_column = ft.Column([ft.Text('lim', size=30), self.down_text], spacing=0)
        self.equation_row = ft.Row([self.left_column, self.expr_str_text, self.result_text], spacing=-1, alignment=ft.MainAxisAlignment.CENTER)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.expr_input, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.approach_input], alignment=ft.MainAxisAlignment.CENTER),
                self.equation_row,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )
        self.init_view()

    def init_view(self):
        self.expr_input.value = "x+y"
        self.approach_input.value = "x=0, y=5"
        self.calculate_limit(None)

    def calculate_limit(self, e):
        try:
            var_limits = self.parse_variable_input(self.approach_input.value)
            result = multivariable_limit(self.expr_input.value, var_limits)
            self.expr_str_text.value = convert_expression_to_pretty(self.expr_input.value)
            self.down_text.value = f'({self.approach_input.value})'
            self.result_text.value = f" = {format_number(result)}"
        except Exception as ex:
            self.result_text.value = f"❌ {ex}"
        self.page.update()
