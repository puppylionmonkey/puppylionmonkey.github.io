import flet as ft
from sympy.parsing.sympy_parser import standard_transformations, implicit_multiplication_application, convert_xor
from functions.common_funtions import format_number, convert_expression_to_pretty
from functions.language_dict_functions import set_text_by_language
from functions.math.calculate_equation_functions import evaluate_expression_multi
from functions.math.derivative_integral_functions import partial_derivative
from views.calculus.abc_calculus_view import AbcCalculusView


class PartialDerivativeView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20
        self.transforms = standard_transformations + (implicit_multiplication_application, convert_xor)

        # 多語系設定
        input_expr_label = set_text_by_language("輸入一個方程式", self.lang)
        input_diff_var_label = set_text_by_language("偏微分（如 x, y, xx, yy, xy）", self.lang)
        input_value_label = set_text_by_language("輸入變數值（如x=2, y=3）", self.lang)  # todo:系統找出xy input數字就好
        self.error_no_variable_text = set_text_by_language("錯誤：找不到變數", self.lang)
        self.result_prefix_text = set_text_by_language("結果", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)

        # 控制元件
        self.input_expr_textfield = self.get_textfield(label=input_expr_label, expand=True, autofocus=True, on_change=self.get_partial_derivative_result)
        self.input_diff_var_textfield = self.get_textfield(label=input_diff_var_label, expand=True, on_change=self.get_partial_derivative_result)
        self.input_values_textfield = self.get_textfield(label=input_value_label, expand=True, on_change=self.get_input_values_result)

        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)
        self.eval_text = ft.Text(value="", selectable=True, size=self.font_size)

        # 視覺化
        self.left_up = ft.Text(size=20, text_align=ft.TextAlign.CENTER, selectable=True)
        self.left_down = ft.Text(size=18, text_align=ft.TextAlign.CENTER, selectable=True)
        self.left_column = ft.Column(
            [self.left_up,
             ft.Text("―", size=25),
             self.left_down,
             ]
            , spacing=-5
        )
        self.expr_str_text = ft.Text(size=20)
        self.equation_row = ft.Row([self.left_column, ft.Text(' = ', selectable=True), self.result_text]
                                   , alignment=ft.MainAxisAlignment.CENTER)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr_textfield, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.input_diff_var_textfield], alignment=ft.MainAxisAlignment.CENTER),
                self.equation_row,
                ft.Divider(),
                ft.Row([self.input_values_textfield], alignment=ft.MainAxisAlignment.CENTER),
                self.eval_text,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_view()

    def init_view(self):
        expr_str = "x**4 + 6*x**3*y**2 + 6*x"
        diff_vars = "x"
        input_values_textfield_value = 'x=5, y=1'
        self.input_expr_textfield.value = expr_str
        self.input_diff_var_textfield.value = diff_vars
        self.input_values_textfield.value = input_values_textfield_value
        self.get_partial_derivative_result(None)
        self.get_input_values_result(None)

    def get_partial_derivative_result(self, e):
        expr_str = self.input_expr_textfield.value.strip()
        diff_vars = self.input_diff_var_textfield.value.strip()
        result_expr = partial_derivative(expr_str, diff_vars)
        self.left_up.value = convert_expression_to_pretty(f'∂**{len(diff_vars)}f')
        self.left_down.value = ''.join(f'∂{v}' for v in reversed(diff_vars))
        self.result_text.value = convert_expression_to_pretty(str(result_expr))
        self.get_input_values_result(None)
        self.page.update()

    def get_input_values_result(self, e):
        try:
            input_values_textfield_value = self.input_values_textfield.value.strip()
            result_expr = self.result_text.value
            values = self.parse_variable_input(input_values_textfield_value)
            evaluated = evaluate_expression_multi(str(result_expr), values)
            self.eval_text.value = f"代入變數結果：{format_number(evaluated)}"
        except Exception as ex:
            self.eval_text.value = f"{self.error_prefix_text}：{str(ex)}"
        self.page.update()
