import flet as ft
from sympy import EmptySet, diff
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application, convert_xor
from sympy.solvers.inequalities import solve_univariate_inequality
from functions.language_dict_functions import set_text_by_language
from views.calculus.abc_calculus_view import AbcCalculusView


class StrictlyIntervalsView(AbcCalculusView):
    def __init__(self, page: ft.Page):
        super().__init__(page)
        self.page = page
        self.font_size = 20
        self.transforms = standard_transformations + (implicit_multiplication_application, convert_xor)

        input_label = set_text_by_language("輸入一個方程式", self.lang)
        self.error_prefix_text = set_text_by_language("錯誤", self.lang)
        self.result_prefix_inc = set_text_by_language("嚴格遞增區間", self.lang)
        self.result_prefix_dec = set_text_by_language("嚴格遞減區間", self.lang)

        self.input_expr = self.get_textfield(label=input_label, expand=True, autofocus=True, on_change=self.calculate)
        self.result_inc = ft.Text(value="", selectable=True, size=self.font_size)
        self.result_dec = ft.Text(value="", selectable=True, size=self.font_size)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.input_expr, self.input_example_button], alignment=ft.MainAxisAlignment.CENTER),
                self.result_inc,
                self.result_dec,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            spacing=15
        )
        self.init_view()

    def init_view(self):
        self.input_expr.value = 'x**2'
        self.calculate(None)

    def calculate(self, e):
        try:
            expr_str = self.input_expr.value.strip()
            expr = parse_expr(expr_str, transformations=self.transforms)

            free_vars = sorted(expr.free_symbols, key=lambda s: s.name)
            if not free_vars:
                self.result_inc.value = f"{self.result_prefix_inc}：{EmptySet()}"
                self.result_dec.value = f"{self.result_prefix_dec}：{EmptySet()}"
            else:
                var = free_vars[0]
                derivative = diff(expr, var)
                inc = solve_univariate_inequality(derivative > 0, var, relational=False)
                dec = solve_univariate_inequality(derivative < 0, var, relational=False)

                self.result_inc.value = f"{self.result_prefix_inc}：{inc}"
                self.result_dec.value = f"{self.result_prefix_dec}：{dec}"

        except Exception as ex:
            self.result_inc.value = f"{self.error_prefix_text}：{str(ex)}"
            self.result_dec.value = ""

        self.page.update()
