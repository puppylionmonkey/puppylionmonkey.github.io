import flet as ft

from functions.chemistry.balance_functions import balance_equation
from functions.language_dict_functions import get_language, set_text_by_language
from views.abc_view.abc_view import AbcView
from functions.common_funtions import *


class BalanceChemicalEquationView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        font_size = 20
        lang = get_language()
        self.lang = lang
        self.reactant_count_label = set_text_by_language('反應物數量', self.lang)
        self.product_count_label = set_text_by_language('產物數量', self.lang)
        self.start_btn_text = set_text_by_language('確認', self.lang)
        self.name_textfield_label = set_text_by_language('輸入化學式', self.lang)
        self.charge_label_value = set_text_by_language('電荷：', self.lang)
        self.next_btn_text = set_text_by_language('輸入', self.lang)
        self.undo_btn_text = set_text_by_language('上一步', self.lang)
        self.reset_btn_text = set_text_by_language('重設', self.lang)
        self.formula_input_text = set_text_by_language('化學式：', self.lang)
        self.balanced_formula_input_text = set_text_by_language('平衡後化學式：', self.lang)
        self.enter_reactants_and_products_text = set_text_by_language('請輸入反應物與產物的數量', self.lang)
        self.enter_integer_message = set_text_by_language('請輸入正整數（不含 0、負數、小數點）', self.lang)
        self.balanced_equation_error = set_text_by_language('輸入錯誤', self.lang)
        # 狀態變數
        self.stage = {
            "step": 0,
            "total": 0,
            "reactants": 0,
            "products": 0,
            "entries": list()
        }

        # 電荷狀態
        self.charge_value = 0
        self.charge_display = ft.Text(value="0", size=18, width=40, text_align="center")
        self.charge_minus_btn = ft.ElevatedButton("-", on_click=self.decrease_charge)
        self.charge_plus_btn = ft.ElevatedButton("+", on_click=self.increase_charge)
        self.charge_label = ft.Text(value=self.charge_label_value, size=16, color="white")

        # UI 元件
        self.reactant_count = self.get_textfield(
            label=self.reactant_count_label,
            keyboard_type=ft.KeyboardType.PHONE,
            expand=True,
            autofocus=True,
        )
        self.product_count = self.get_textfield(
            label=self.product_count_label,
            keyboard_type=ft.KeyboardType.PHONE,
            expand=True
        )
        self.start_btn = ft.ElevatedButton(self.start_btn_text, expand=True, on_click=self.start_input)

        self.name_textfield = self.get_textfield(label=self.name_textfield_label, visible=False, expand=True)

        self.charge_row = ft.Row(
            controls=[
                self.charge_label,
                self.charge_minus_btn,
                self.charge_display,
                self.charge_plus_btn
            ],
            spacing=5,
            alignment=ft.MainAxisAlignment.START,
            visible=False
        )
        self.input_row = ft.Row(
            controls=[
                self.name_textfield,
                self.charge_row
            ],
            alignment=ft.MainAxisAlignment.START,
            spacing=10
        )

        self.next_btn = ft.ElevatedButton(self.next_btn_text, visible=False, expand=True, on_click=self.next_entry)
        self.current_label = ft.Text(value="", size=18, weight="bold", color="white", visible=False)
        self.undo_btn = ft.ElevatedButton(self.undo_btn_text, visible=False, expand=True, on_click=self.undo_entry)
        self.reset_btn = ft.OutlinedButton(self.reset_btn_text, expand=True, on_click=self.reset_all)
        self.formula_display = ft.Text(value="", size=font_size, color="white", selectable=True)
        self.balanced_formula_display = ft.Text(value="", size=font_size, color="white", visible=False, selectable=True)

        self.input_area = ft.Column(
            controls=[
                self.current_label,
                self.input_row,
                ft.Row([self.undo_btn, self.next_btn], spacing=10),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=15
        )

        # 組合頁面元件
        self.main_column = ft.Column(
            controls=[
                ft.Text(self.enter_reactants_and_products_text, size=18, weight="bold", color="white"),
                ft.Row([self.reactant_count, self.product_count, self.start_btn], spacing=10),
                ft.Divider(),
                self.input_area,
                ft.Divider(),
                ft.Text(self.formula_input_text, size=16, color="white", selectable=True),
                self.formula_display,
                ft.Text(self.balanced_formula_input_text, size=16, color="white", selectable=True),
                self.balanced_formula_display,
                ft.Row([self.reset_btn], alignment=ft.MainAxisAlignment.CENTER),
            ],
            expand=True,
            alignment=ft.MainAxisAlignment.START,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )

    def update_current_step(self):
        i = self.stage["step"]

        if i < self.stage["reactants"]:
            self.current_label.value = f"輸入第 {i + 1} 個反應物" if self.lang == 'zh' else f'Enter the {i + 1}th reactant'
        elif i < self.stage["total"]:
            self.current_label.value = f"輸入第 {i + 1 - self.stage['reactants']} 個產物" if self.lang == 'zh' else f'Enter the {i + 1 - self.stage["reactants"]}th product'
        else:
            self.input_row.visible = False
            self.next_btn.visible = False
            self.undo_btn.visible = False
            self.current_label.visible = False

        reactants = " + ".join(self.stage["entries"][:min(i, self.stage["reactants"])])
        products = " + ".join(self.stage["entries"][self.stage["reactants"]:i])
        arrow = " → " if products else ""
        self.formula_display.value = f"{reactants}{arrow}{products}"

        self.page.update()

    def undo_entry(self, e):
        if self.stage["step"] > 0:
            self.stage["step"] -= 1
            self.stage["entries"].pop()
            self.name_textfield.value = ""
            self.charge_value = 0
            self.charge_display.value = "0"
            self.next_btn.visible = True
            self.update_current_step()

    def reset_all(self, e):
        self.stage = {
            "step": 0,
            "total": 0,
            "reactants": 0,
            "products": 0,
            "entries": []
        }
        self.reactant_count.value = ""
        self.product_count.value = ""
        self.name_textfield.visible = False
        self.charge_row.visible = False
        self.next_btn.visible = False
        self.undo_btn.visible = False
        self.current_label.visible = False
        self.name_textfield.value = ""
        self.charge_value = 0
        self.charge_display.value = "0"
        self.formula_display.value = ""
        self.balanced_formula_display.value = ""
        self.balanced_formula_display.visible = False
        self.next_btn.disabled = False
        self.reactant_count.focus()
        self.page.update()

    def start_input(self, e):
        if self.reactant_count.value.isdigit() and self.product_count.value.isdigit():
            self.stage["reactants"] = int(self.reactant_count.value)
            self.stage["products"] = int(self.product_count.value)
            self.stage["total"] = self.stage["reactants"] + self.stage["products"]
            self.stage["step"] = 0
            self.stage["entries"] = []
            self.name_textfield.visible = True
            self.charge_row.visible = True
            self.next_btn.visible = True
            self.undo_btn.visible = True
            self.current_label.visible = True
            self.formula_display.value = ""
            self.next_entry(None)
            self.name_textfield.focus()
            self.update_current_step()
        else:
            self.formula_display.value = self.enter_integer_message

        self.page.update()

    def increase_charge(self, e):
        self.charge_value += 1
        self.charge_display.value = str(self.charge_value)
        self.page.update()

    def decrease_charge(self, e):
        self.charge_value -= 1
        self.charge_display.value = str(self.charge_value)
        self.page.update()

    def next_entry(self, e):
        name = self.name_textfield.value.strip()
        charge = self.charge_value

        if charge == 0:
            entry = f"{to_subscript(name)}"
        else:
            entry = f"{to_subscript(name)}{to_superscript2(str(charge))}"

        if name:
            self.stage["entries"].append(entry)
            self.name_textfield.value = ""
            self.charge_value = 0
            self.charge_display.value = "0"
            self.stage["step"] += 1

        i = self.stage["step"]

        if i < self.stage["reactants"]:
            self.current_label.value = f"輸入第 {i + 1} 個反應物" if self.lang == 'zh' else f'Enter the {i + 1}th reactant'
        elif i < self.stage["total"]:
            self.current_label.value = f"輸入第 {i + 1 - self.stage['reactants']} 個產物" if self.lang == 'zh' else f'Enter the {i + 1 - self.stage["reactants"]}th product'
        else:
            self.next_btn.visible = False
            self.current_label.value = ""
            self.name_textfield.read_only = True
            self.name_textfield.update()

        reactants = " + ".join(self.stage["entries"][:min(i, self.stage["reactants"])])
        products = " + ".join(self.stage["entries"][self.stage["reactants"]:i])
        arrow = " → " if products else ""
        self.formula_display.value = f"{reactants}{arrow}{products}"

        if i == self.stage["total"]:
            try:
                self.balanced_formula_display.value = balance_equation(self.formula_display.value)
            except:
                self.balanced_formula_display.value = self.balanced_equation_error
            self.balanced_formula_display.visible = True
        self.page.update()
        self.name_textfield.read_only = False
