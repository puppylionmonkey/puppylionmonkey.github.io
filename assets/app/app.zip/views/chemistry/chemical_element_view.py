import flet as ft

from functions.chemistry.periodic_table_element_functions import *
from functions.language_dict_functions import set_text_by_language
from views.abc_view.abc_view import AbcView


class ChemicalElementView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        content = ft.Column()
        self.name = set_text_by_language('名稱', self.lang)
        self.symbol = set_text_by_language('元素符號', self.lang)
        self.atomic_number = set_text_by_language('原子序', self.lang)
        self.proton_number = set_text_by_language('質子數', self.lang)
        self.neutron_number = set_text_by_language('中子數', self.lang)
        self.atomic_mass = set_text_by_language('原子質量', self.lang)
        self.electronegativity = set_text_by_language('電負度', self.lang)
        self.electron_configuration = set_text_by_language('電子組態', self.lang)
        # 用可滾動視圖包裝
        self.periodic_table_scroll_element = ft.Row(
            controls=[
                ft.Container(
                    content=content,
                    expand=True,
                    padding=10,
                )
            ],
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
        )
        pte = Element()
        element_symbol = self.route.replace('/', '')
        element_obj = pte.create_element(element_symbol)
        self.main_column = ft.Column(
            [
                ft.Text(f"{self.name}：{element_obj.name}", size=20, selectable=True),
                ft.Text(f"{self.symbol}：{element_obj.symbol}", size=20, selectable=True),
                ft.Text(f"{self.atomic_number}：{element_obj.atomic_number}", size=20, selectable=True),
                ft.Text(f"{self.proton_number}：{element_obj.proton_number}", size=20, selectable=True),
                ft.Text(f"{self.neutron_number}：{element_obj.neutron_number}", size=20, selectable=True),
                ft.Text(f"{self.atomic_mass}：{element_obj.atomic_mass}", size=20, selectable=True),
                ft.Text(f"{self.electronegativity}：{element_obj.electronegativity}", size=20, selectable=True),
                ft.Text(f"{self.electron_configuration}：{simplify_electron_configuration(element_obj.electron_configuration)}", size=20, selectable=True),
            ],
            spacing=10,
            expand=True,
            horizontal_alignment=ft.CrossAxisAlignment.START
        )
