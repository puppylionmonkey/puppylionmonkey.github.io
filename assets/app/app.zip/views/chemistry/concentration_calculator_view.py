import flet as ft

from functions.common_funtions import format_number
from functions.language_dict_functions import set_text_by_language
from views.abc_view.abc_view import AbcView
from functions.unit_functions import *


# todo: 用計算類?
class ConcentrationCalculatorView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        font_size = 20
        dropdown_width = 150
        text_select_concentration = set_text_by_language("選擇計算濃度", self.lang)
        text_molarity = set_text_by_language("莫耳濃度", self.lang)
        text_mass_percent = set_text_by_language("重量百分濃度", self.lang)
        text_volume_percent = set_text_by_language("體積百分濃度", self.lang)
        text_solute = set_text_by_language("溶質", self.lang)
        text_solution = set_text_by_language("溶液", self.lang)
        self.text_result_prefix = set_text_by_language("濃度", self.lang)
        self.text_input_error = set_text_by_language("請輸入正確的數值！", self.lang)

        def on_concentration_type_change(e):
            selected = self.concentration_type_dropdown.value
            if selected == 'M':
                unit_symbol_dict1 = number_unit_symbol_name_dict
                unit_symbol_dict2 = volume_unit_symbol_name_dict
            elif selected == 'W%':
                unit_symbol_dict1 = mass_unit_symbol_name_dict
                unit_symbol_dict2 = mass_unit_symbol_name_dict
            elif selected == 'V%':
                unit_symbol_dict1 = volume_unit_symbol_name_dict
                unit_symbol_dict2 = volume_unit_symbol_name_dict

            if self.lang == "zh":
                dropdown_option_list1 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in unit_symbol_dict1.items()]
                dropdown_option_list2 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in unit_symbol_dict2.items()]
            else:
                dropdown_option_list1 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in unit_symbol_dict1.items()]
                dropdown_option_list2 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in unit_symbol_dict2.items()]

            numerator_unit_symbol_name = list(unit_symbol_dict1.items())[0]
            denominator_unit_symbol_name = list(unit_symbol_dict2.items())[0]

            self.numerator_unit_dropdown.value = numerator_unit_symbol_name[0]
            self.denominator_unit_dropdown.value = denominator_unit_symbol_name[0]
            self.numerator_unit_dropdown.options = dropdown_option_list1
            self.denominator_unit_dropdown.options = dropdown_option_list2
            self.page.update()
            self.calculate_concentration(None)

        self.concentration_type_dropdown = ft.Dropdown(
            label=text_select_concentration,
            options=[
                ft.dropdown.Option("M", f"{text_molarity} (M)"),
                ft.dropdown.Option("W%", f"{text_mass_percent} (W%)"),
                ft.dropdown.Option("V%", f"{text_volume_percent} (V%)"),
            ],
            value="M",  # 預設值
            width=250,
            on_change=on_concentration_type_change,
        )

        # 預設
        unit_symbol_dict1 = number_unit_symbol_name_dict
        unit_symbol_dict2 = volume_unit_symbol_name_dict
        if self.lang == "zh":
            dropdown_option_list1 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in unit_symbol_dict1.items()]
            dropdown_option_list2 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in unit_symbol_dict2.items()]
        else:
            dropdown_option_list1 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in unit_symbol_dict1.items()]
            dropdown_option_list2 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in unit_symbol_dict2.items()]

        # 濃度輸入區域
        self.numerator_textfield = self.get_textfield(
            label=text_solute,
            expand=True,
            keyboard_type=ft.KeyboardType.PHONE,
            on_change=self.calculate_concentration,
            value='1',
            autofocus=True,
        )

        self.numerator_unit_dropdown = ft.Dropdown(

            width=dropdown_width,
            options=dropdown_option_list1,
            value="mole",  # 預設值
            on_change=self.calculate_concentration,
        )

        self.denominator_textfield = self.get_textfield(
            label=text_solution,
            expand=True,
            keyboard_type=ft.KeyboardType.PHONE,
            on_change=self.calculate_concentration,
            value='1',
        )

        self.denominator_unit_dropdown = ft.Dropdown(
            width=dropdown_width,
            options=dropdown_option_list2,
            value="L",  # 預設值
            on_change=self.calculate_concentration,
        )

        self.result_text = ft.Text(
            value="",
            size=font_size,
            weight=ft.FontWeight.BOLD,
            selectable=True,
        )

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.concentration_type_dropdown, ], alignment=ft.MainAxisAlignment.CENTER, ),
                ft.Row([self.numerator_textfield, self.numerator_unit_dropdown, ], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.denominator_textfield, self.denominator_unit_dropdown, ], alignment=ft.MainAxisAlignment.CENTER, ),
                self.result_text,
            ],
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
        )
        self.calculate_concentration(None)

    def calculate_concentration(self, e):
        try:
            numerator_value = self.numerator_textfield.value
            numerator_unit_value = self.numerator_unit_dropdown.value
            denominator_value = self.denominator_textfield.value
            denominator_unit = self.denominator_unit_dropdown.value

            numerator_ureg = ureg.parse_expression(numerator_value + numerator_unit_value)
            denominator_ureg = ureg.parse_expression(denominator_value + denominator_unit)
            result_ureg = numerator_ureg / denominator_ureg
            if self.concentration_type_dropdown.value == 'M':
                result_ureg = result_ureg.to('M')
                result = result_ureg
                result = f'{result:.6f}'
            elif self.concentration_type_dropdown.value == 'W%':
                result_ureg = numerator_ureg.to('g') / denominator_ureg.to('g')
                result = result_ureg.magnitude * 100
                result = format_number(result) + ' W%'
                ppm_result = float(str(result_ureg.to('ppm')).split()[0]) * 100
                result += f'\n{ppm_result:.6f} ppm'
            elif self.concentration_type_dropdown.value == 'V%':
                result_ureg = numerator_ureg.to('mL') / denominator_ureg.to('mL')
                result = result_ureg.magnitude * 100
                result = format_number(result) + ' V%'
                ppm_result = float(str(result_ureg.to('ppm')).split()[0]) * 100
                result += f'\n{ppm_result:.6f} ppm'
            self.result_text.value = f"{self.text_result_prefix} = {result}"
        except ValueError:
            self.result_text.value = f"❌ {self.text_input_error}！"
        self.page.update()
