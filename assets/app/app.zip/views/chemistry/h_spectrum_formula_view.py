from functions.common_funtions import format_number
from functions.chemistry.h_spectrum_formula_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass


class HSpectrumFormulaView(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            result_ureg = function1(ureg1, ureg2)
            if selected_unit == 'λ':
                result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
                new_value = result_ureg.magnitude
            else:
                new_value = result_ureg
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'λ': 'Length',
            'n1': 'Dimensionless',
            'n2': 'Dimensionless',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'λ': calculate_wavelength,
            'n1': calculate_n1_from_wavelength,
            'n2': calculate_n2_from_wavelength,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'λ': '波長',
                'n1': '主量子數(起始)',
                'n2': '主量子數(結束)',
            }
        else:
            return {
                'λ': 'Wavelength',
                'n1': 'Principal Quantum Number(Start)',
                'n2': 'Principal Quantum Number(End)',
            }

    def get_constant_str_list(self):
        return [f"Rₕ = {format_number(R_H.magnitude)} × m⁻¹"]

    def get_default_dropdown_unit_symbol(self, unit_list):
        if 'nm' in unit_list:
            return 'nm'
        else:
            return unit_list[0]
