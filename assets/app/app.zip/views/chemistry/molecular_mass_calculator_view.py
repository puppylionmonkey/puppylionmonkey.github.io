import flet as ft
from functions.common_funtions import to_subscript
from functions.chemistry.get_molecular_functions import calculate_molecular_mass
from functions.language_dict_functions import set_text_by_language
from views.abc_view.abc_view import AbcView


class MolecularMassCalculatorView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        font_size = 20
        self.formula_label = set_text_by_language("輸入化學式", self.lang)
        self.mole_label = set_text_by_language("輸入莫爾數 (mole)", self.lang)
        self.molar_mass_label = set_text_by_language("分子量", self.lang)
        self.mass_label = set_text_by_language("質量", self.lang)
        self.error_message = set_text_by_language("錯誤", self.lang)

        self.formula_input = self.get_textfield(label=self.formula_label, expand=True, autofocus=True)
        self.mole_input = self.get_textfield(label=self.mole_label, expand=True)
        self.display_formula = ft.Text("", size=font_size, weight="bold", text_align=ft.TextAlign.CENTER)
        self.molar_mass_text = ft.Text(f"{self.molar_mass_label}: 0 g/mole", size=font_size, text_align=ft.TextAlign.CENTER, selectable=True)
        self.mass_text = ft.Text(f"{self.mass_label}: 0 g", size=font_size, text_align=ft.TextAlign.CENTER, selectable=True)

        self.formula_input.on_change = self.auto_calculate
        self.mole_input.on_change = self.auto_calculate

        self.main_column = ft.Column(
            controls=[
                self.formula_input,
                self.mole_input,
                self.display_formula,
                self.molar_mass_text,
                self.mass_text,
            ],
            expand=True,
            alignment=ft.MainAxisAlignment.START,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )

    def auto_calculate(self, e=None):
        try:
            formula = self.formula_input.value.strip()
            mole_str = self.mole_input.value.strip()

            self.display_formula.value = to_subscript(formula) if formula else ""

            if not formula:
                self.molar_mass_text.value = f"{self.molar_mass_label}: 0 g/mol"
                self.mass_text.value = f"{self.mass_label}: 0 g"
                self.page.update()
                return

            molar_mass = calculate_molecular_mass(formula)
            self.molar_mass_text.value = f"{self.molar_mass_label}: {molar_mass:.4f} g/mol"

            if mole_str:
                moles = float(mole_str)
                mass = moles * molar_mass
                self.mass_text.value = f"{self.mass_label}: {mass:.4f} g"
            else:
                self.mass_text.value = f"{self.mass_label}: 0 g"

        except Exception as ex:
            self.molar_mass_text.value = self.error_message
            self.mass_text.value = str(ex)
        self.page.update()
