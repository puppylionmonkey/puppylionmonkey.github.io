import flet as ft
from functions.common_funtions import to_subscript, to_charge_superscript
from functions.language_dict_functions import get_language
from functions.chemistry.oxidation_number_functions import calculate_oxidation_number
from views.abc_view.abc_view import AbcView


class OxidationNumberView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        font_size = 20

        label_formula = "輸入化學式" if self.lang == "zh" else "Enter chemical formula"
        label_charge = "電荷" if self.lang == "zh" else "Charge:"
        self.oxidation_label_prefix = "氧化數" if self.lang == "zh" else "Oxidation Numbers"

        self.formula_input = self.get_textfield(label=label_formula, expand=True, on_change=self.auto_calculate_oxidation_number, autofocus=True)
        self.display_formula = ft.Text("", size=font_size, weight="bold", text_align=ft.TextAlign.CENTER)
        self.result_text = ft.Text(f"{self.oxidation_label_prefix}:", size=font_size, text_align=ft.TextAlign.CENTER, selectable=True)

        # charge
        def increase_charge(e):
            self.charge_value += 1
            self.charge_display.value = str(self.charge_value)
            self.auto_calculate_oxidation_number()
            self.page.update()

        def decrease_charge(e):
            self.charge_value -= 1
            self.charge_display.value = str(self.charge_value)
            self.auto_calculate_oxidation_number()
            self.page.update()

        self.charge_value = 0
        self.charge_display = ft.Text(value="0", size=18, width=40, text_align="center")
        self.charge_minus_btn = ft.ElevatedButton("-", on_click=decrease_charge)
        self.charge_plus_btn = ft.ElevatedButton("+", on_click=increase_charge)
        self.charge_label = ft.Text(value=f"{label_charge}：", size=16, color="white")
        self.charge_row = ft.Row(
            controls=[
                self.charge_label,
                self.charge_minus_btn,
                self.charge_display,
                self.charge_plus_btn
            ],
            spacing=5,
            alignment=ft.MainAxisAlignment.START,
        )
        self.main_column = ft.Column(
            controls=[
                ft.Row(controls=[self.formula_input, self.charge_row], alignment=ft.MainAxisAlignment.START, spacing=10),
                self.display_formula,
                self.result_text,
            ],
            alignment=ft.MainAxisAlignment.START,
            expand=True,
        )

    def auto_calculate_oxidation_number(self, e=None):
        try:
            formula = self.formula_input.value.strip()
            str1 = to_subscript(formula) if formula else ""
            str1 += to_charge_superscript(str(self.charge_value))
            self.display_formula.value = str1

            oxidation_number_dict = calculate_oxidation_number(formula, int(self.charge_value))
            self.result_text.value = f"{self.oxidation_label_prefix}: {str(oxidation_number_dict)}"

        except Exception as ex:
            self.result_text.value = str(ex)

        self.page.update()
