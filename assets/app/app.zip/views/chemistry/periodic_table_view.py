import flet as ft

from views.abc_view.abc_view import AbcView


class PeriodicTableView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        self.periodic_table_elements = [
            ["H", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "He"],
            ["Li", "Be", "", "", "", "", "", "", "", "", "", "", "B", "C", "N", "O", "F", "Ne"],
            ["Na", "Mg", "", "", "", "", "", "", "", "", "", "", "Al", "Si", "P", "S", "Cl", "Ar"],
            ["K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr"],
            ["Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe"],
            ["Cs", "Ba", "", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn"],
            ["Fr", "Ra", "", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"],
            ["" for i in range(18)],
            ["", "", "", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu"],
            ["", "", "", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr"],
        ]
        self.element_symbols = [
            "H", "He",
            "Li", "Be", "B", "C", "N", "O", "F", "Ne",
            "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
            "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr",
            "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "I", "Te", "Xe",
            "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
            "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
            "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm",
            "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds",
            "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"
        ]

        def open_element_page(element):
            def navigate(e):
                page.go("/" + element)

            return navigate

        content = ft.Column(
            spacing=5,
            controls=[
                ft.Row(
                    spacing=5,
                    controls=[
                        ft.Container(
                            content=ft.ElevatedButton(
                                text=symbol,
                                on_click=open_element_page(symbol)
                            ) if symbol else ft.Text(symbol),
                            width=50,
                            height=50,
                            bgcolor=ft.Colors.BLUE_GREY_200 if symbol else ft.Colors.TRANSPARENT,
                            alignment=ft.alignment.center,
                        )
                        for symbol in row
                    ],
                )
                for row in self.periodic_table_elements
            ],
        )

        # 用可滾動視圖包裝
        self.periodic_table_scroll_element = ft.Column(
            controls=[ft.Row(
                controls=[
                    ft.Container(
                        content=content,
                        expand=True,
                        padding=10,
                    )
                ],
                scroll=ft.core.types.ScrollMode.ADAPTIVE,
            )],
            alignment=ft.MainAxisAlignment.CENTER,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
        )

    def get_view(self):
        return ft.View(
            '/periodic_table',
            controls=[
                # self.app_bar,
                ft.Container(content=self.periodic_table_scroll_element, expand=True, alignment=ft.alignment.center),
            ],
            padding=ft.padding.only(bottom=120 if self.page.platform == ft.PagePlatform.ANDROID else 70, left=10, right=10, top=70 if self.page.platform == ft.PagePlatform.ANDROID else 40),
        )
