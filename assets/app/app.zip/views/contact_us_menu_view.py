import flet as ft

from functions.language_dict_functions import set_text_by_language
from views.abc_view.abc_view import AbcView


class ContactUsMenuView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        button_height = 100
        button_width = 200
        button_style = ft.ButtonStyle(side=ft.BorderSide(1, ft.Colors.WHITE))

        send_email_str = set_text_by_language('發送郵件', self.lang)
        send_email_button = ft.ElevatedButton(
            send_email_str,
            icon=ft.Icons.EMAIL,
            on_click=lambda e: page.launch_url("mailto:puppylionmonkey33@gmail.com?subject=&body="),
            height=button_height,
            width=button_width,
            style=button_style
        )

        self.main_column = ft.Column(
            [
                send_email_button,
            ],
            expand=True,
            alignment=ft.MainAxisAlignment.CENTER,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )
