import flet as ft
from views.abc_view.abc_view import AbcView
from views.route_dicts import subject_route_dict


class HomeMenuView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        route_list = ['unit_conversion'] + [f'{subject}_menu' for subject in list(subject_route_dict.keys()) if subject !='policy']
        # route_list = ['unit_conversion', 'math_menu', 'chemistry_menu', 'physics_menu', 'thermodynamics_menu', 'other_menu']
        self.button_list = self.create_button_list_from_route_list(route_list)
        self.main_column = ft.Column(
            self.button_list,
            expand=True,
            alignment=ft.MainAxisAlignment.CENTER,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )

    def create_button_list_from_route_list(self, route_list):
        button_height = 100
        button_width = 200
        button_style = ft.ButtonStyle(side=ft.BorderSide(1, ft.Colors.WHITE))
        button_name_dict = {
            '/' + route: (
                f"{self.new_route_name_dict.get(route)}"
            )
            for route in route_list
        }
        return [
            ft.ElevatedButton(
                title, on_click=lambda _, route=route1: self.page.go(route), height=button_height, width=button_width, style=button_style
            )
            for route1, title in button_name_dict.items()
        ]
