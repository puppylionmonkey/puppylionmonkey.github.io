import flet as ft
from sympy.parsing.sympy_parser import standard_transformations, implicit_multiplication_application, convert_xor

from functions.language_dict_functions import set_text_by_language
from functions.math.solve_equation_funcitons import solve_equation_list
from views.abc_view.abc_view import AbcView


class SolveEquationView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        self.font_size = 20
        button_style = ft.ButtonStyle(side=ft.BorderSide(1, ft.Colors.WHITE))

        self.equations = list()  # 每個元素是 dict：{'text': 原始文字}
        equation_input_label = set_text_by_language('請輸入一個方程式（如 2x + y = 3）', self.lang)
        add_equation_button_text = set_text_by_language('輸入', self.lang)
        solve_button_text = set_text_by_language('計算', self.lang)
        reset_button_text = set_text_by_language('重設', self.lang)
        show_equation_text = set_text_by_language('方程式', self.lang)
        self.delete_text = set_text_by_language('刪除', self.lang)

        self.equation_input = self.get_textfield(label=equation_input_label, expand=True, dense=True, autofocus=True)
        self.equation_list_column = ft.Column(spacing=5)  # 顯示方程式與刪除按鈕
        self.result_text = ft.Text(value="", selectable=True, size=self.font_size)

        self.add_equation_button = ft.ElevatedButton(add_equation_button_text, on_click=self.add_equation, style=button_style)
        self.solve_button = ft.ElevatedButton(solve_button_text, on_click=self.solve_equations, width=100, style=button_style)
        self.reset_button = ft.TextButton(f"🔄{reset_button_text}", on_click=self.reset_equations, style=button_style)

        self.main_column = ft.Column(
            controls=[
                ft.Row([self.equation_input, self.add_equation_button], alignment=ft.MainAxisAlignment.CENTER),  # 加入方程式按鈕靠右
                ft.Row([ft.Text(f"{show_equation_text}：", weight="bold", selectable=True)], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.equation_list_column], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([self.reset_button, self.solve_button], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([self.result_text], alignment=ft.MainAxisAlignment.CENTER),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            expand=True,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )

        self.transforms = standard_transformations + (implicit_multiplication_application, convert_xor)

    def add_equation(self, e):
        eq = self.equation_input.value.strip()
        if eq:
            self.equations.append({'text': eq})
            self.equation_input.value = ""
            self.update_equation_list()
            self.page.update()

    def delete_equation(self, index):
        del self.equations[index]
        self.update_equation_list()
        self.page.update()

    def reset_equations(self, e):
        self.equations.clear()
        self.result_text.value = ""
        self.update_equation_list()
        self.page.update()

    def update_equation_list(self):
        self.equation_list_column.controls.clear()
        for i, item in enumerate(self.equations):
            row = ft.Row(
                controls=[
                    ft.Text(item['text'], size=self.font_size),
                    ft.IconButton(
                        icon=ft.Icons.DELETE,
                        tooltip=self.delete_text,
                        on_click=lambda e, index=i: self.delete_equation(index)
                    )
                ],
                alignment=ft.MainAxisAlignment.CENTER,
            )
            self.equation_list_column.controls.append(row)

    def solve_equations(self, e):
        equation_texts = [item['text'] for item in self.equations]
        self.result_text.value = solve_equation_list(equation_texts)
        self.page.update()
