from views.abc_view.abc_menu_view import AbcMenuView
import flet as ft


class ChemistryMenuView(AbcMenuView):
    def __init__(self, page):
        super().__init__(page)


class MathMenuView(AbcMenuView):
    def __init__(self, page):
        super().__init__(page)


class CalculusMenuView(AbcMenuView):
    def __init__(self, page):
        super().__init__(page)


class PhysicsMenuView(AbcMenuView):
    def __init__(self, page):
        super().__init__(page)


class ThermodynamicsMenuView(AbcMenuView):
    def __init__(self, page):
        super().__init__(page)


class OtherMenuView(AbcMenuView):
    def __init__(self, page):
        super().__init__(page)


class PolicyMenuView(AbcMenuView):
    def __init__(self, page):
        super().__init__(page)

        # 建立新按鈕，點擊後開啟外部連結
        privacy_button = ft.ElevatedButton(
            "🔒 隱私權政策",
            on_click=lambda e: self.page.launch_url("https://puppylionmonkey.github.io/privacy_policy.html"),
            height=self.button_height,
            width=200,
            style=ft.ButtonStyle(side=ft.BorderSide(1, ft.Colors.WHITE))
        )

        # 將按鈕加到最上方（或你也可以放最下方）
        self.button_list.insert(0, privacy_button)

        # 重新組合 main_column，避免原本的按鈕排列不更新
        if len(self.button_list) > 10:
            self.main_column = ft.Column(
                [
                    ft.Row(pair, alignment=ft.MainAxisAlignment.SPACE_EVENLY)
                    for pair in [self.button_list[i:i + 2] for i in range(0, len(self.button_list), 2)]
                ],
                expand=True,
                alignment=ft.MainAxisAlignment.CENTER,
                scroll=ft.core.types.ScrollMode.ADAPTIVE,
            )
        else:
            self.main_column = ft.Column(
                self.button_list,
                expand=True,
                alignment=ft.MainAxisAlignment.CENTER,
                scroll=ft.core.types.ScrollMode.ADAPTIVE
            )

