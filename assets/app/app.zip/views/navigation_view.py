import flet as ft
import flet_ads as ads
from functions.language_dict_functions import get_language, set_text_by_language


class NavigationView:
    def __init__(self, page):
        self.page = page
        self.lang = get_language()
        privacy_policy_str = set_text_by_language('隱私政策', self.lang)
        search_str = set_text_by_language('搜尋', self.lang)
        settings_str = set_text_by_language('設定', self.lang)
        contact_us_str = set_text_by_language('聯絡我們', self.lang)
        home_str = set_text_by_language('回到主頁', self.lang)

        self.privacy_policy_button = ft.IconButton(
            icon=ft.Icons.PRIVACY_TIP_OUTLINED,
            tooltip=search_str,
            icon_size=30,
            icon_color=ft.Colors.WHITE,
            on_click=lambda _: page.go("/policy_menu")
        )
        self.search_button = ft.IconButton(
            icon=ft.Icons.SEARCH,
            tooltip=search_str,
            icon_size=30,
            icon_color=ft.Colors.WHITE,
            on_click=lambda _: page.go("/search_menu")
        )
        self.setting_button = ft.IconButton(
            icon=ft.Icons.SETTINGS_SHARP,
            tooltip=settings_str,
            icon_size=30,
            icon_color=ft.Colors.WHITE,
            on_click=lambda _: page.go("/setting_menu")
        )
        self.contact_us_button = ft.IconButton(
            icon=ft.Icons.CONTACT_MAIL_OUTLINED,
            tooltip=contact_us_str,
            icon_size=30,
            icon_color=ft.Colors.WHITE,
            on_click=lambda _: page.go("/contact_us")
        )
        self.home_button = ft.IconButton(
            icon=ft.Icons.HOME_OUTLINED,
            tooltip=home_str,
            icon_size=30,
            icon_color=ft.Colors.WHITE,
            on_click=lambda _: page.go("/")
        )
        # banner_ad_id = "ca-app-pub-3940256099942544/6300978111"  # test
        banner_ad_id = "ca-app-pub-6191200390333168/7874475760"  # pub

        ad_container = ft.Container(
            content=ads.BannerAd(
                unit_id=banner_ad_id,
                on_click=lambda e: print("BannerAd clicked"),
                on_load=lambda e: print("BannerAd loaded"),
                on_error=lambda e: print("BannerAd error", e.data),
                on_open=lambda e: print("BannerAd opened"),
                on_close=lambda e: print("BannerAd closed"),
                on_impression=lambda e: print("BannerAd impression"),
                on_will_dismiss=lambda e: print("BannerAd will dismiss"),
            ),
            bgcolor=ft.Colors.TRANSPARENT,
            expand=True,
        )

        self.bottom_buttons = ft.Row(
            [
                ft.Container(self.home_button, expand=1, alignment=ft.alignment.center),
                ft.Container(self.search_button, expand=1, alignment=ft.alignment.center),
                ft.Container(self.contact_us_button, expand=1, alignment=ft.alignment.center),
                ft.Container(self.privacy_policy_button, expand=1, alignment=ft.alignment.center),
                ft.Container(self.setting_button, expand=1, alignment=ft.alignment.center),
            ],
            alignment=ft.MainAxisAlignment.SPACE_EVENLY,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )
        if page.platform == ft.PagePlatform.ANDROID:
            self.main_column = ft.Column(
                [
                    ad_container,
                    self.bottom_buttons
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            )
        else:
            self.main_column = ft.Column(
                [
                    self.bottom_buttons
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            )

    def get_navigation_bar(self):
        return ft.Container(
            content=self.main_column,
            bgcolor=ft.Colors.BLACK,
            alignment=ft.alignment.bottom_center,
            shadow=ft.BoxShadow(blur_radius=10, color=ft.Colors.BLACK38, offset=ft.Offset(0, -2)),
            height=110 if self.page.platform == ft.PagePlatform.ANDROID else 60,
            # height=60,
            bottom=0,
            left=0,
            right=0,
        )
