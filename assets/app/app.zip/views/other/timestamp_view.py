import flet as ft
import calendar

from functions.language_dict_functions import set_text_by_language
from functions.other.timestamp_functions import *
from views.abc_view.abc_view import AbcView


class TimestampView(AbcView):
    def __init__(self, page):
        super().__init__(page)

        timestamp_text = set_text_by_language('時間戳', self.lang)
        times_text = set_text_by_language('時間', self.lang)
        mode_text = set_text_by_language('轉換模式', self.lang)
        year_text = set_text_by_language('年', self.lang)
        month_text = set_text_by_language('月', self.lang)
        day_text = set_text_by_language('日', self.lang)
        hour_text = set_text_by_language('時', self.lang)
        min_text = set_text_by_language('分', self.lang)
        second_text = set_text_by_language('秒', self.lang)
        self.result_str = set_text_by_language('輸入錯誤', self.lang)

        years = [str(y) for y in range(2000, 2031)]
        months = [f"{m:02d}" for m in range(1, 13)]
        hours = [f"{h:02d}" for h in range(0, 24)]
        minutes_seconds = [f"{i:02d}" for i in range(0, 60)]

        now = datetime.datetime.now()
        now_year, now_month, now_day = now.year, now.month, now.day
        now_hour, now_minute, now_second = now.hour, now.minute, now.second
        now_timestamp = calculate_timestamp(now_year, now_month, now_day, now_hour, now_minute, now_second)
        days_in_month = calendar.monthrange(now.year, now.month)[1]
        day_options = [ft.dropdown.Option(f"{d:02d}") for d in range(1, days_in_month + 1)]

        # 模式選擇 Dropdown
        self.mode_dd = ft.Dropdown(
            label=mode_text,
            options=[
                ft.dropdown.Option("datetime_to_timestamp", f"{times_text} ➜ {timestamp_text}"),
                ft.dropdown.Option("timestamp_to_datetime", f"{timestamp_text} ➜ {times_text}"),
            ],
            value="datetime_to_timestamp",
            width=200,
            on_change=lambda e: self.switch_mode()
        )

        # 時間欄位
        self.year_dd = ft.Dropdown(label=year_text, options=[ft.dropdown.Option(y) for y in years], width=100)
        self.month_dd = ft.Dropdown(label=month_text, options=[ft.dropdown.Option(m) for m in months], width=100)
        self.day_dd = ft.Dropdown(label=day_text, options=day_options, width=100)
        self.hour_dd = ft.Dropdown(label=hour_text, options=[ft.dropdown.Option(h) for h in hours], width=100)
        self.minute_dd = ft.Dropdown(label=min_text, options=[ft.dropdown.Option(m) for m in minutes_seconds], width=100)
        self.second_dd = ft.Dropdown(label=second_text, options=[ft.dropdown.Option(s) for s in minutes_seconds], width=100)

        self.timestamp_input = self.get_textfield(label=timestamp_text, width=250, visible=False, value=f'{now_timestamp}')

        self.result_text = ft.Text(f"{timestamp_text}: {now_timestamp}", size=20, selectable=True)

        # 預設值
        self.year_dd.value = str(now_year)
        self.month_dd.value = f"{now_month:02d}"
        self.day_dd.value = f"{now_day:02d}"
        self.hour_dd.value = f"{now_hour:02d}"
        self.minute_dd.value = f"{now_minute:02d}"
        self.second_dd.value = f"{now_second:02d}"

        # 更新結果（依據模式）
        def update_result():
            try:
                if self.mode_dd.value == "datetime_to_timestamp":
                    timestamp1 = calculate_timestamp(
                        int(self.year_dd.value),
                        int(self.month_dd.value),
                        int(self.day_dd.value),
                        int(self.hour_dd.value),
                        int(self.minute_dd.value),
                        int(self.second_dd.value),
                    )
                    self.result_text.value = f"{timestamp_text}: {timestamp1}"
                elif self.mode_dd.value == "timestamp_to_datetime":
                    ts = int(self.timestamp_input.value)
                    self.result_text.value = timestamp_to_datetime(ts)
                else:
                    self.result_text.value = self.result_str
            except Exception:
                self.result_text.value = self.result_str
            self.result_text.update()

        # 切換模式
        def switch_mode():
            if self.mode_dd.value == "datetime_to_timestamp":
                self.timestamp_input.visible = False
                self.datetime_row.visible = True
            else:
                self.timestamp_input.visible = True
                self.datetime_row.visible = False
            self.timestamp_input.update()
            self.datetime_row.update()
            update_result()

        self.switch_mode = switch_mode  # 讓 lambda 裡可以用

        # 日期自動調整
        def update_day_options(e=None):
            try:
                year = int(self.year_dd.value)
                month = int(self.month_dd.value)
                days_in_month = calendar.monthrange(year, month)[1]
                self.day_dd.options = [ft.dropdown.Option(f"{d:02d}") for d in range(1, days_in_month + 1)]
                if int(self.day_dd.value or 1) > days_in_month:
                    self.day_dd.value = f"{1:02d}"
            except:
                self.day_dd.options = []
                self.day_dd.value = None
            self.day_dd.update()
            update_result()

        # 綁定事件
        self.year_dd.on_change = update_day_options
        self.month_dd.on_change = update_day_options
        self.day_dd.on_change = lambda e: update_result()
        self.hour_dd.on_change = lambda e: update_result()
        self.minute_dd.on_change = lambda e: update_result()
        self.second_dd.on_change = lambda e: update_result()
        self.timestamp_input.on_change = lambda e: update_result()

        # 初始畫面
        self.datetime_row = ft.Column([
            ft.Row([self.year_dd, self.month_dd, self.day_dd], spacing=10, alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([self.hour_dd, self.minute_dd, self.second_dd], spacing=10, alignment=ft.MainAxisAlignment.CENTER),
        ])

        self.main_column = ft.Column([
            ft.Row([self.mode_dd], alignment=ft.MainAxisAlignment.CENTER),
            self.datetime_row,
            ft.Row([self.timestamp_input], alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([ft.Icon(name=ft.Icons.ARROW_DOWNWARD)], alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([self.result_text], alignment=ft.MainAxisAlignment.CENTER),
        ])
