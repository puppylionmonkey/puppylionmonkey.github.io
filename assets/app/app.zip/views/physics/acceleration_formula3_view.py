from functions.common_funtions import format_number
from functions.physics.acceleration_formula3_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass


class AccelerationFormula3View(CalculateLawViewClass):

    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            result_ureg = function1(ureg1, ureg2, ureg3)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'v': 'Velocity',
            'v₀': 'Velocity',
            'a': 'Acceleration',
            'x': 'Length',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'v': calculate_final_velocity,
            'v₀': calculate_initial_velocity,
            'a': calculate_acceleration,
            'x': calculate_displacement,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'v': '末速度',
                'v₀': '初速度',
                'a': '加速度',
                'x': '位移',
            }
        else:
            return {
                'v': 'Final velocity',
                'v₀': 'Initial velocity',
                'a': 'Acceleration',
                'x': 'Displacement',
            }
