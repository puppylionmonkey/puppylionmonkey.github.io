from functions.common_funtions import format_number
from functions.physics.centripetal_acceleration_formula2_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
from functions.unit_functions import *


class CentripetalAccelerationFormula2View(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            result_ureg = function1(ureg1, ureg2)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'a': 'Acceleration',
            'r': 'Length',
            'ω': 'Angular_velocity',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'a': calculate_centripetal_acceleration,
            'r': calculate_radius,
            'ω': calculate_angular_velocity,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'a': '向心加速度',
                'r': '半徑',
                'ω': '角速度',
            }
        else:
            return {
                'a': 'Centripetal acceleration',
                'r': 'Radius',
                'ω': 'Angular velocity',
            }
