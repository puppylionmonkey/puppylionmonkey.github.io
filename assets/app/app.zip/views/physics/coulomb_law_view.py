from functions.physics.coulomb_law_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
from functions.common_funtions import format_number
from functions.unit_functions import *


class CoulombLawView(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            result_ureg = function1(ureg1, ureg2, ureg3)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'F': 'Force',
            'q1': 'Electricity_quantity',
            'q2': 'Electricity_quantity',
            'r': 'Length',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'F': calculate_force,
            'q1': calculate_q1,
            'q2': calculate_q2,
            'r': calculate_r,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'F': '力',
                'q1': '電量',
                'q2': '電量',
                'r': '距離',
            }
        else:
            return {
                'F': 'Force',
                'q1': 'Charge 1',
                'q2': 'Charge 2',
                'r': 'Distance',
            }

    def get_constant_str_list(self):
        return [f"k = {format_number(coulomb_law_constant.magnitude)} × N × m² × C²"]
