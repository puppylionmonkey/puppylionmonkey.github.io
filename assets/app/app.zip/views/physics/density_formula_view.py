from functions.language_dict_functions import set_text_by_language
from functions.physics.density_formula_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
from functions.common_funtions import format_number
from functions.unit_functions import *
import flet as ft

# unit = "g/cm³"
substance_density_dict = {
    "water": 1,  # 水
    "ice": 0.917,  # 冰
    "air": 0.001225,  # 空氣（海平面）
    "oxygen": 0.001429,  # 氧氣
    "hydrogen": 0.00008988,  # 氫氣
    "carbon_dioxide": 0.001977,  # 二氧化碳
    "ethanol": 0.789,  # 乙醇
    "mercury": 13.546,  # 汞
    "aluminum": 2.7,  # 鋁
    "iron": 7.874,  # 鐵
    "copper": 8.96,  # 銅
    "gold": 19.3,  # 金
    "silver": 10.49,  # 銀
    "lead": 11.34,  # 鉛
    "glass": 2.5,  # 玻璃（平均值）
    "concrete": 2.4,  # 混凝土
    "wood_oak": 0.71,  # 橡木
    "wood_pine": 0.5,  # 松木
    "oil_vegetable": 0.92,  # 植物油
    "gasoline": 0.74,  # 汽油
    "helium": 0.0001786  # 氦氣
}
substance_name_dict = {
    "water": "水",
    "ice": "冰",
    "air": "空氣",
    "oxygen": "氧氣",
    "hydrogen": "氫氣",
    "carbon_dioxide": "二氧化碳",
    "ethanol": "乙醇",
    "mercury": "汞",
    "aluminum": "鋁",
    "iron": "鐵",
    "copper": "銅",
    "gold": "金",
    "silver": "銀",
    "lead": "鉛",
    "glass": "玻璃",
    "concrete": "混凝土",
    "wood_oak": "橡木",
    "wood_pine": "松木",
    "oil_vegetable": "植物油",
    "gasoline": "汽油",
    "helium": "氦氣"
}


class DensityFormulaView(CalculateLawViewClass):
    def __init__(self, page):
        super().__init__(page)

        self.label1 = f"{set_text_by_language("密度", self.lang)}："

        # 建立下拉選單項目
        options = [
            ft.dropdown.Option(key, text=substance_name_dict[key] if self.lang == "zh" else key.replace('_', ' ').capitalize())
            for key in substance_density_dict
        ]
        self.substance_dropdown = ft.Dropdown(
            label=set_text_by_language("物質", self.lang),
            options=options,
            width=250,
            on_change=self.on_substance_change,
            value='water',
            border_color=ft.Colors.WHITE
        )
        key = 'water'
        density_unit_dict_dict = all_unit_dict_dict['Density']
        density_nuit_dropdown_option_list = self.get_zh_dropdown_list('Density') if self.lang == 'zh' else self.get_dropdown_list('Density')

        self.density_dropdown = ft.Dropdown(
            options=density_nuit_dropdown_option_list,
            value=list(density_unit_dict_dict.values())[0],
            on_change=self.density_dropdown_change,
            width=115,
            color=self.font_color,
            border_color=ft.Colors.WHITE
        )
        density = substance_density_dict[key]
        self.substance_density_display = ft.Text(value=f"{self.label1}{density}", size=16, selectable=True)
        self.main_column.controls.insert(0, ft.Row([self.substance_dropdown], alignment=ft.MainAxisAlignment.CENTER))
        self.main_column.controls.insert(1, ft.Row([self.substance_density_display, self.density_dropdown], alignment=ft.MainAxisAlignment.CENTER))

    def density_dropdown_change(self, e):
        key = self.substance_dropdown.value
        density = substance_density_dict[key]
        ureg1 = ureg.parse_expression(f'{density} g/cm³')
        result_ureg = ureg1.to(ureg.parse_expression(self.density_dropdown.value))
        new_value = result_ureg.magnitude
        self.substance_density_display.value = f"{self.label1}{format_number(new_value)}"
        self.substance_density_display.update()

    def on_substance_change(self, e):
        key = self.substance_dropdown.value
        if key and key in substance_density_dict:
            density = substance_density_dict[key]
            label = "密度：" if self.lang == "zh" else "Density: "
            self.substance_density_display.value = f"{label}{density}"
            self.substance_density_display.update()

            # 如果目前是要算質量或體積，可以把密度值自動填入欄位
            if self.calculate_selector.value in ['m', 'V']:
                self.textfield_list[0].value = format_number(density)
                self.dropdown_list[0].value = "g/cm^3"
                self.textfield_list[0].update()
                self.dropdown_list[0].update()
        self.density_dropdown_change(None)

    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            result_ureg = function1(ureg1, ureg2)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'd': 'Density',
            'm': 'Mass',
            'V': 'Volume',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'd': calculate_density,
            'm': calculate_mass,
            'V': calculate_volume,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'd': '密度',
                'm': '質量',
                'V': '體積',
            }
        else:
            return {
                'd': 'Density',
                'm': 'Mass',
                'V': 'Volume',
            }
