from functions.common_funtions import format_number
from functions.physics.elastic_collision_formula_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass


class ElasticCollisionFormulaView(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            ureg4 = ureg.parse_expression(self.textfield_list[3].value + self.dropdown_list[3].value)
            ureg5 = ureg.parse_expression(self.textfield_list[4].value + self.dropdown_list[4].value)
            result_ureg = function1(ureg1, ureg2, ureg3, ureg4, ureg5)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'm₁': 'Mass',
            'm₂': 'Mass',
            'v₁': 'Velocity',
            'v₂': 'Velocity',
            'v₁′': 'Velocity',
            'v₂′': 'Velocity',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'm₁': calculate_m1,
            'm₂': calculate_m2,
            'v₁': calculate_v1_before,
            'v₂': calculate_v2_before,
            'v₁′': calculate_v1_after,
            'v₂′': calculate_v2_after,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'm₁': '質量1',
                'm₂': '質量2',
                'v₁': '初速度1',
                'v₂': '初速度2',
                'v₁′': '末速度1',
                'v₂′': '末速度2',
            }
        else:
            return {
                'm₁': 'Mass 1',
                'm₂': 'Mass 2',
                'v₁': 'Initial Speed 1',
                'v₂': 'Initial Speed 2',
                'v₁′': 'Final Speed 1',
                'v₂′': 'Final Speed 2',
            }

    def get_textfield_value(self, ccc=''):
        if ccc == 'v₁′' or ccc == 'v₂′':
            return '0'
        return '1'
