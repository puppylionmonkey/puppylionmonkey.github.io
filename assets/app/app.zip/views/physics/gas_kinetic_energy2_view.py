from functions.common_funtions import format_number
from functions.physics.gas_kinetic_energy2_functions import *
from functions.unit_functions import get_temperature_ureg
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass


class GasKineticEnergy2View(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            if selected_unit == 'T':
                ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            else:
                ureg2 = get_temperature_ureg(self.textfield_list[1].value, self.dropdown_list[1].value)
            result_ureg = function1(ureg1, ureg2)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'E': 'Energy',
            'n': 'Number',
            'T': 'Temperature',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'E': calculate_internal_energy,
            'n': calculate_mole,
            'T': calculate_temperature,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'E': '能量',
                'n': '氣體莫爾數',
                'T': '溫度',
            }
        else:
            return {
                'E': 'Energy',
                'n': 'Mole of gas',
                'T': 'Temperature',
            }

    def get_constant_str_list(self):
        return [f"R = {R.magnitude} × atm × L × mole⁻¹ × K⁻¹", f"R = {R.magnitude} × J × mole⁻¹ × K⁻¹"]
