from functions.common_funtions import format_number
from functions.physics.gas_wall_force1_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass


class GasWallForce1View(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            ureg4 = ureg.parse_expression(self.textfield_list[3].value + self.dropdown_list[3].value)
            result_ureg = function1(ureg1, ureg2, ureg3, ureg4)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'F': 'Force',
            'N': 'Dimensionless',
            'm': 'Mass',
            'Vₓ': 'Velocity',
            'L': 'Length',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'F': calculate_force,
            'N': calculate_molecule_count,
            'm': calculate_mass,
            'Vₓ': calculate_average_velocity,
            'L': calculate_length,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'F': '力',
                'N': '氣體數量',
                'm': '質量',
                'Vₓ': '平均速率',
                'L': '邊長',
            }
        else:
            return {
                'F': 'Force',
                'N': 'Number of gas molecules',
                'm': 'Mass',
                'Vₓ': 'Average speed',
                'L': 'Edge length',
            }
