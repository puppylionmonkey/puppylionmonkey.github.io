from functions.common_funtions import format_number
from functions.physics.gas_wall_pressure_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass


class GasWallPressureView(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            ureg4 = ureg.parse_expression(self.textfield_list[3].value + self.dropdown_list[3].value)
            result_ureg = function1(ureg1, ureg2, ureg3, ureg4)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'P': 'Pressure',
            'N': 'Dimensionless',
            'm': 'Mass',
            'v': 'Velocity',
            'V': 'Volume',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'P': calculate_pressure,
            'N': calculate_molecule_count,
            'm': calculate_mass,
            'v': calculate_velocity,
            'V': calculate_volume,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'P': '壓力',
                'N': '氣體數量',
                'm': '質量',
                'v': '平均速率',
                'V': '體積',
            }
        else:
            return {
                'P': 'Pressure',
                'N': 'Number of gas molecules',
                'm': 'Mass',
                'v': 'Average speed',
                'V': 'Volume',
            }