from functions.common_funtions import format_number
from functions.physics.impulse_formula_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
from functions.unit_functions import *


class ImpulseFormulaView(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            result_ureg = function1(ureg1, ureg2)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'J': 'Momentum',
            'F': 'Force',
            't': 'Time',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'J': calculate_impulse,
            'F': calculate_force,
            't': calculate_time,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'J': '衝量',
                'F': '力',
                't': '時間',
            }
        else:
            return {
                'J': 'Impulse',
                'F': 'Force',
                't': 'Time',
            }

    def get_default_dropdown_unit_symbol(self, unit_list):
        if 'kg*m/s' in unit_list:
            return 'kg*m/s'
        else:
            return unit_list[0]
