from functions.common_funtions import format_number
from functions.physics.universal_gravitation_law_functions import *
from functions.physics.universal_gravitation_law_functions import universal_gravitation_law_constant
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass


class UniversalGravitationLawView(CalculateLawViewClass):

    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            result_ureg = function1(ureg1, ureg2, ureg3)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'F': 'Force',
            'm1': 'Mass',
            'm2': 'Mass',
            'r': 'Length',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'F': calculate_force,
            'm1': calculate_mass1,
            'm2': calculate_mass2,
            'r': calculate_r,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'F': '力',
                'm1': '質量',
                'm2': '質量',
                'r': '距離',
            }
        else:
            return {
                'F': 'Force',
                'm1': 'Mass 1',
                'm2': 'Mass 2',
                'r': 'Distance',
            }

    def get_constant_str_list(self):
        return [f"G = {format_number(universal_gravitation_law_constant.magnitude)} × m³ × kg⁻¹ × s⁻²"]
