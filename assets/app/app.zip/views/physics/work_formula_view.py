from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
from functions.common_funtions import format_number
from functions.physics.work_formula_functions import *


class WorkFormulaView(CalculateLawViewClass):
    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.get_all_symbol_calculate_on_change_function_dict()[selected_unit]
        try:
            if selected_unit == 'θ':
                ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            else:
                ureg3 = float(self.textfield_list[2].value)
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            result_ureg = function1(ureg1, ureg2, ureg3)
            if selected_unit == 'θ':
                new_value = result_ureg
            else:
                result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
                new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'W': 'Energy',
            'F': 'Force',
            'S': 'Length',
            'θ': 'Angle'
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'W': calculate_work,
            'F': calculate_force,
            'S': calculate_displacement,
            'θ': calculate_theta,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'W': '功',
                'F': '力',
                'S': '位移',
                'θ': '夾角角度',
            }
        else:
            return {
                'W': 'Work',
                'F': 'Force',
                'S': 'Displacement',
                'θ': 'Angle',
            }

    def get_textfield_value(self, ccc=''):
        if ccc == 'θ':
            return '0'
        return '1'
