import flet as ft
from views.abc_view.abc_view import AbcView


class DisclaimerView(AbcView):
    def __init__(self, page):
        super().__init__(page)

        # 中文與英文版本免責條款
        disclaimer_zh = (
            "本應用程式提供之計算結果僅供參考，開發者不對使用本程式所產生之結果或損失負責。\n"
            "請勿將本程式用於需要高度準確性的專業用途（如醫療、工程、財務等）。\n"
            "使用者應自行確認輸入資料的正確性，並理解本應用程式僅為輔助工具。"
        )

        disclaimer_en = (
            "The results provided by this app are for reference only. The developer is not liable for any outcomes or losses caused by using this app.\n"
            "Do not use this application for professional purposes requiring high accuracy (e.g., medical, engineering, finance).\n"
            "Users are responsible for ensuring the correctness of input data and acknowledge that this app is for educational or support purposes only."
        )

        disclaimer_text = disclaimer_zh if self.lang == "zh" else disclaimer_en

        self.main_column = ft.Column(
            [
                ft.Text(disclaimer_text, size=18),
            ],
            scroll=ft.ScrollMode.AUTO,
            expand=True,
            spacing=20,
        )
