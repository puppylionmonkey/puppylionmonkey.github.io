import flet as ft
from views.abc_view.abc_view import AbcView
from functions.language_dict_functions import set_text_by_language


class TermsOfUseView(AbcView):
    def __init__(self, page):
        super().__init__(page)

        terms_zh = (
            "1. 本應用程式之內容僅供教育與學習用途，請勿用於醫療、金融、工程等需要高度準確性的專業領域。\n"
            "2. 開發者不承擔任何因使用本應用程式所造成的直接或間接損失，包括但不限於財務損失、資料錯誤或作業延誤。\n"
            "3. 使用者應確認其輸入資料的正確性，並理解計算僅為輔助工具，無法取代專業判斷。\n"
            "4. 若使用者不同意上述條款，請勿使用本應用程式。"
        )

        terms_en = (
            "1. This app is intended for educational and learning purposes only. Do not use it for professional purposes requiring high precision, such as medical, financial, or engineering decisions.\n"
            "2. The developer is not responsible for any direct or indirect losses caused by the use of this app, including but not limited to financial loss, data errors, or work delays.\n"
            "3. Users should verify their input accuracy and understand that the results are only for assistance, not a substitute for professional judgment.\n"
            "4. If you do not agree with these terms, please do not use this application."
        )

        terms_text = terms_zh if self.lang == "zh" else terms_en

        self.main_column = ft.Column(
            [
                ft.Text(terms_text, size=18),
            ],
            scroll=ft.ScrollMode.AUTO,
            expand=True,
            spacing=20,
        )
