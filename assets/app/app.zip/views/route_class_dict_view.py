from functions.chemistry.periodic_table_element_functions import Element
from views.calculus.absolute_extrema_view import AbsoluteExtremaView
from views.calculus.analyze_critical_points_view import AnalyzeCriticalPointsView
from views.calculus.directional_derivative_view import DirectionalDerivativeView
from views.calculus.gradient_view import GradientView
from views.calculus.infinite_series_sum_view import InfiniteSeriesSumView
from views.calculus.is_differentiable_view import IsDifferentiableView
from views.calculus.multiple_integral_view import MultipleIntegralView
from views.calculus.partial_derivative_view import PartialDerivativeView
from views.chemistry.balance_chemical_equation_view import BalanceChemicalEquationView
from views.chemistry.chemical_element_view import ChemicalElementView
from views.chemistry.concentration_calculator_view import ConcentrationCalculatorView
from views.chemistry.electrolysis_law_view import ElectrolysisLawView
from views.chemistry.h_spectrum_formula_view import HSpectrumFormulaView
from views.chemistry.molecular_mass_calculator_view import MolecularMassCalculatorView
from views.chemistry.oxidation_number_view import OxidationNumberView
from views.chemistry.periodic_table_view import PeriodicTableView
from views.contact_us_menu_view import ContactUsMenuView
from views.home_menu_view import HomeMenuView
from views.calculus.calculate_limit_view import CalculateLimitView
from views.calculus.calculate_sigma_view import CalculateSigmaView
from views.math.circle_area_view import CircleAreaView
from views.math.circle_circumference import CircleCircumference
from views.calculus.definite_integral_view import DefiniteIntegralView
from views.calculus.derivative_view import DerivativeView
from views.calculus.extrema_on_interval_view import ExtremaOnIntervalView
from views.calculus.implicit_partial_derivative_view import ImplicitPartialDerivativeView
from views.calculus.integral_view import IntegralView
from views.calculus.is_limit_continuous_view import IsLimitContinuousView
from views.calculus.multivariable_limit_view import MultivariableLimitView
from views.math.solve_equation_view import SolveEquationView
from views.math.sphere_volume_view import SphereVolumeView
from views.calculus.strictly_intervals_view import StrictlyIntervalsView
from views.menu_view import *
from views.other.calculate_bmi_view import CalculateBmiView
from views.other.timestamp_view import TimestampView
from views.physics.acceleration_formula1_view import AccelerationFormula1View
from views.physics.acceleration_formula2_view import AccelerationFormula2View
from views.physics.acceleration_formula3_view import AccelerationFormula3View
from views.physics.angular_velocity_view import AngularVelocityView
from views.physics.centripetal_acceleration_formula1_view import CentripetalAccelerationFormula1View
from views.physics.centripetal_acceleration_formula2_view import CentripetalAccelerationFormula2View
from views.physics.coulomb_law_view import CoulombLawView
from views.physics.density_formula_view import DensityFormulaView
from views.physics.elastic_collision_formula_view import ElasticCollisionFormulaView
from views.physics.electromagnetic_force_law_view import ElectromagneticForceLawView
from views.physics.gas_average_kinetic_energy_view import GasAverageKineticEnergyView
from views.physics.gas_average_velocity_formula2_view import GasAverageVelocityFormula2View
from views.physics.gas_average_velocity_formula_view import GasAverageVelocityFormulaView
from views.physics.gas_kinetic_energy2_view import GasKineticEnergy2View
from views.physics.gas_kinetic_energy_view import GasKineticEnergyView
from views.physics.gas_wall_force1_view import GasWallForce1View
from views.physics.gas_wall_force2_view import GasWallForce2View
from views.physics.gas_wall_pressure_view import GasWallPressureView
from views.physics.impulse_formula_view import ImpulseFormulaView
from views.physics.kinetic_energy_formula_view import KineticEnergyFormulaView
from views.physics.mass_energy_formula_view import MassEnergyFormulaView
from views.physics.momentum_formula_view import MomentumFormulaView
from views.physics.motion_law_view import MotionLawView
from views.physics.ohm_law_view import OhmLawView
from views.physics.photon_energy_formula1_view import PhotonEnergyFormula1View
from views.physics.photon_energy_formula2_view import PhotonEnergyFormula2View
from views.physics.potential_energy_formula_view import PotentialEnergyFormulaView
from views.physics.power_formula1_view import PowerFormula1View
from views.physics.power_formula2_view import PowerFormula2View
from views.physics.pressure_formula_view import PressureFormulaView
from views.physics.rotational_work_view import RotationalWorkView
from views.physics.uniform_circular_formula1_view import UniformCircularFormula1View
from views.physics.uniform_circular_formula2_view import UniformCircularFormula2View
from views.physics.uniform_circular_formula3_view import UniformCircularFormula3View
from views.physics.universal_gravitation_law_view import UniversalGravitationLawView
from views.physics.wave_speed_formula_view import WaveSpeedFormulaView
from views.physics.work_formula_view import WorkFormulaView
from views.policy.disclaimer_view import DisclaimerView
from views.policy.terms_of_use_view import TermsOfUseView
from views.search_menu_view import SearchMenuView
from views.setting_menu_view import SettingMenuView
from views.thermodynamics.enthalpy_formula_view import EnthalpyFormulaView
from views.thermodynamics.heat_formula_view import HeatFormulaView
from views.thermodynamics.ideal_gas_entropy_formula1_view import IdealGasEntropyFormula1View
from views.thermodynamics.ideal_gas_entropy_formula2_view import IdealGasEntropyFormula2View
from views.thermodynamics.ideal_gas_law_view import IdealGasLawView
from views.thermodynamics.real_gas_law_view import RealGasLawView
from views.thermodynamics.specific_volume_table2_view import SpecificVolumeTable2View
from views.thermodynamics.specific_volume_table_view import SpecificVolumeTableView
from views.thermodynamics.specific_volume_view import SpecificVolumeView
from views.thermodynamics.superheated_specific_volume_table_view import SuperheatedSteamPropertiesView
from views.unit_conversion_view import UnitConversionView

route_class_dict = {
    '': HomeMenuView,
    'contact_us': ContactUsMenuView,
    'setting_menu': SettingMenuView,
    'search_menu': SearchMenuView,
    'unit_conversion': UnitConversionView,

    'policy_menu': PolicyMenuView,
    'disclaimer': DisclaimerView,
    'terms_of_use': TermsOfUseView,

    'math_menu': MathMenuView,
    'solve_equation': SolveEquationView,
    'circle_area': CircleAreaView,
    'circle_circumference': CircleCircumference,
    'sphere_volume': SphereVolumeView,

    'derivative': DerivativeView,
    'integral': IntegralView,
    'calculate_limit': CalculateLimitView,
    'definite_integral': DefiniteIntegralView,
    'calculate_sigma': CalculateSigmaView,
    'is_limit_continuous': IsLimitContinuousView,
    'strictly_intervals': StrictlyIntervalsView,
    'extrema_on_interval': ExtremaOnIntervalView,
    'multivariable_limit': MultivariableLimitView,
    'implicit_partial_derivative': ImplicitPartialDerivativeView,
    'partial_derivative': PartialDerivativeView,
    'is_differentiable': IsDifferentiableView,
    'directional_derivative': DirectionalDerivativeView,
    'gradient': GradientView,
    'analyze_critical_points': AnalyzeCriticalPointsView,
    'absolute_extrema': AbsoluteExtremaView,
    'multiple_integral': MultipleIntegralView,
    'infinite_series_sum': InfiniteSeriesSumView,

    'calculus_menu': CalculusMenuView,

    'density_formula': DensityFormulaView,
    'physics_menu': PhysicsMenuView,
    'motion_law': MotionLawView,
    'acceleration_formula1': AccelerationFormula1View,
    'acceleration_formula2': AccelerationFormula2View,
    'acceleration_formula3': AccelerationFormula3View,
    'kinetic_energy_formula': KineticEnergyFormulaView,
    'potential_energy_formula': PotentialEnergyFormulaView,
    'pressure_formula': PressureFormulaView,
    'work_formula': WorkFormulaView,
    'universal_gravitation_law': UniversalGravitationLawView,
    'coulomb_law': CoulombLawView,
    'ohm_law': OhmLawView,
    'electromagnetic_force_law': ElectromagneticForceLawView,
    'wave_speed_formula': WaveSpeedFormulaView,
    'photon_energy_formula1': PhotonEnergyFormula1View,
    'photon_energy_formula2': PhotonEnergyFormula2View,
    'mass_energy_formula': MassEnergyFormulaView,
    'h_spectrum_formula': HSpectrumFormulaView,
    'angular_velocity': AngularVelocityView,
    'rotational_work': RotationalWorkView,
    'uniform_circular_formula1': UniformCircularFormula1View,
    'uniform_circular_formula2': UniformCircularFormula2View,
    'uniform_circular_formula3': UniformCircularFormula3View,
    'centripetal_acceleration_formula1': CentripetalAccelerationFormula1View,
    'centripetal_acceleration_formula2': CentripetalAccelerationFormula2View,
    'momentum_formula': MomentumFormulaView,
    'impulse_formula': ImpulseFormulaView,
    'elastic_collision_formula': ElasticCollisionFormulaView,
    'power_formula1': PowerFormula1View,
    'power_formula2': PowerFormula2View,
    'gas_wall_force1': GasWallForce1View,
    'gas_wall_force2': GasWallForce2View,
    'gas_wall_pressure': GasWallPressureView,
    'gas_kinetic_energy': GasKineticEnergyView,
    'gas_kinetic_energy2': GasKineticEnergy2View,
    'gas_average_kinetic_energy': GasAverageKineticEnergyView,
    'gas_average_velocity_formula': GasAverageVelocityFormulaView,
    'gas_average_velocity_formula2': GasAverageVelocityFormula2View,

    'chemistry_menu': ChemistryMenuView,
    "periodic_table": PeriodicTableView,
    "balance_chemical_equation": BalanceChemicalEquationView,
    "molecular_mass_calculator": MolecularMassCalculatorView,
    "concentration_calculator": ConcentrationCalculatorView,
    "oxidation_number": OxidationNumberView,
    "electrolysis_law": ElectrolysisLawView,

    'thermodynamics_menu': ThermodynamicsMenuView,
    'enthalpy_formula': EnthalpyFormulaView,
    'specific_volume': SpecificVolumeView,
    'specific_volume_table': SpecificVolumeTableView,
    'specific_volume_table2': SpecificVolumeTable2View,
    'superheated_specific_volume_table': SuperheatedSteamPropertiesView,
    'ideal_gas_law': IdealGasLawView,
    'real_gas_law': RealGasLawView,
    'heat_formula': HeatFormulaView,
    'ideal_gas_entropy_formula1': IdealGasEntropyFormula1View,
    'ideal_gas_entropy_formula2': IdealGasEntropyFormula2View,

    'other_menu': OtherMenuView,
    'calculate_bmi': CalculateBmiView,
    'timestamp': TimestampView,
}
for element_symbol in Element().element_symbols:
    route_class_dict[element_symbol] = ChemicalElementView
