import flet as ft

from functions.common_funtions import search_str_in_dict
from functions.language_dict_functions import set_text_by_language
from views.route_dicts import route_name_dict, route_formula_dict
from views.abc_view.abc_view import AbcView


class SearchMenuView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        route_list = self.new_route_name_dict.keys()
        self.button_list = self.create_button_list_from_route_list(route_list)

        self.button_width = 200
        hint_text = set_text_by_language('搜尋名稱或公式...', self.lang)
        self.search_field = self.get_textfield(
            hint_text=hint_text,
            on_change=self.update_button_list,
            autofocus=True,
            icon=ft.Icons.SEARCH,
            expand=True,
            width=500,
        )
        self.button_column = ft.Column(
            controls=self.button_list,
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )

        self.main_column = ft.Column(
            [
                self.search_field,
                self.button_column,
            ],
            expand=True,
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )

    def update_button_list(self, e):
        text = self.search_field.value
        searched_route_name_dict = search_str_in_dict(text, route_name_dict)
        searched_route_name_dict.update(search_str_in_dict(text, route_formula_dict))
        route_list = searched_route_name_dict.keys()
        self.button_column.controls = self.create_button_list_from_route_list(route_list)
        self.page.update()

    def create_button_list_from_route_list(self, route_list):
        button_height = 100
        button_width = 200
        button_style = ft.ButtonStyle(side=ft.BorderSide(1, ft.Colors.WHITE))
        button_name_dict = {
            '/' + route: (
                f"{self.new_route_name_dict.get(route)}"
                if route_formula_dict.get(route, '') == ''
                else f"{self.new_route_name_dict.get(route, '')}\n{route_formula_dict.get(route, '')}"
            )
            for route in route_list
        }
        return [
            ft.ElevatedButton(
                title, on_click=lambda _, route=route1: self.page.go(route), height=button_height, width=button_width, style=button_style
            )
            for route1, title in button_name_dict.items()
        ]
