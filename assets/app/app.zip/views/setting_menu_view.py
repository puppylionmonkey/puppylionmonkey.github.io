from functions.language_dict_functions import set_language, set_text_by_language
from views.abc_view.abc_view import AbcView
import flet as ft


class SettingMenuView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        self.dropdown_label = set_text_by_language('語言', self.lang)
        self.dropdown = ft.Dropdown(
            label=self.dropdown_label,
            options=[
                ft.dropdown.Option("zh", "中文"),
                ft.dropdown.Option("en", "English")
            ],
            value=None,
            on_change=self.change_language,
            width=200
        )

        self.main_column = ft.Column(
            [self.dropdown],
            expand=True,
            alignment=ft.MainAxisAlignment.CENTER,
            scroll=ft.core.types.ScrollMode.ADAPTIVE
        )

    def change_language(self, e):
        set_language(e.control.value)
        self.page.update()
