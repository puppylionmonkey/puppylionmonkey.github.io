from functions.common_funtions import format_number
from functions.language_dict_functions import set_text_by_language
from functions.thermodynamics.heat_formula_functions import *
from functions.unit_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
import flet as ft

specific_heat_dict = {
    "water": 4186,
    "ice": 2100,
    "air": 1005,
    "steam": 2010,
    "aluminum": 900,
    "copper": 385,
    "iron": 450,
    "lead": 128,
    "silver": 235,
    "gold": 129,
    "mercury": 140,
    "glass": 840,
    "sand": 830,
    "O2": 918,
    "N2": 1040,
    "H2": 14300,
    "He": 5190,
    "CO2": 844,
    "ethanol": 2440,
    "glycerin": 2410,
    "oil (vegetable)": 2000,
    "wood": 1700,
    "concrete": 880,
    "granite": 790,
}

class HeatFormulaView(CalculateLawViewClass):
    def __init__(self, page):
        super().__init__(page)
        # 預設選第一個氣體，並計算 a b
        substance = list(specific_heat_dict.keys())[0]
        self.cap = specific_heat_dict[substance] * ureg.J / (ureg.kg * ureg.K)
        choice_gas_text = set_text_by_language("物質", self.lang)

        def on_gas_selected(e):
            substance = self.gas_dropdown.value
            if substance in specific_heat_dict:
                self.cap = specific_heat_dict[substance] * ureg.J / (ureg.kg * ureg.K)
                self.gas_result_text.value = f"c = {self.cap.magnitude:.3f}J/(kg·K)"
                self.gas_result_text.update()
            self.calculate1(None)

        self.gas_dropdown = ft.Dropdown(
            label=choice_gas_text,
            options=[ft.dropdown.Option(key=k, text=k) for k in specific_heat_dict.keys()],
            value=list(specific_heat_dict.keys())[0],
            on_change=on_gas_selected,
            width=200,
            color='white',
            border_color=ft.Colors.WHITE
        )
        self.gas_result_text = ft.Text("", size=14, color='white')
        self.gas_result_text.value = f"c = {self.cap.magnitude:.3f}J/(kg·K)"

        # 頁面中插入氣體下拉與結果
        self.main_column.controls.insert(1, ft.Row([self.gas_dropdown], alignment=ft.MainAxisAlignment.CENTER))
        self.main_column.controls.insert(2, ft.Row([self.gas_result_text], alignment=ft.MainAxisAlignment.CENTER))

    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            if selected_unit == 'T':
                ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            else:
                ureg2 = get_temperature_ureg(self.textfield_list[1].value, self.dropdown_list[1].value)
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            result_ureg = function1(ureg1, ureg2, self.cap)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'Q': 'Energy',
            'm': 'Mass',
            'T': 'Temperature',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'Q': calculate_heat,
            'm': calculate_mass,
            'T': calculate_temperature_change,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'Q': '熱量',
                'm': '質量',
                'T': '溫度變化',
            }
        else:
            return {
                'Q': 'Heat',
                'm': 'Mass',
                'T': 'Temperature change',
            }
