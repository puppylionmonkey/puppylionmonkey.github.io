from functions.common_funtions import format_number
from functions.language_dict_functions import set_text_by_language
from functions.thermodynamics.ideal_gas_entropy_formula1_functions import *
from functions.unit_functions import *
from functions.thermodynamics.ideal_gas_law_funtsions import gas_constant, gas_constant2
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
import flet as ft


class IdealGasEntropyFormula1View(CalculateLawViewClass):
    def __init__(self, page):
        super().__init__(page)
        selected_gas = list(temperature_standard_entropy_dict.keys())[0]
        R_gas = get_substance_R(selected_gas)

        def on_gas_selected(e):
            selected_gas = self.gas_dropdown.value
            R_gas = get_substance_R(selected_gas)
            self.selected_gas_text.value = f"R_gas = {R_gas}"
            self.selected_gas_text.update()
            self.calculate1(None)

        self.gas_dropdown = ft.Dropdown(
            label=set_text_by_language('選擇氣體', self.lang),
            options=[ft.dropdown.Option(key=k, text=k) for k in temperature_standard_entropy_dict.keys()],
            value=list(temperature_standard_entropy_dict.keys())[0],
            on_change=on_gas_selected,
            width=200,
            color='white',
            border_color=ft.Colors.WHITE
        )
        self.selected_gas_text = ft.Text("", size=14, color='white')
        self.selected_gas_text.value = f"{R_gas}"

        # 頁面中插入氣體下拉與結果
        self.main_column.controls.insert(3, ft.Row([self.gas_dropdown], alignment=ft.MainAxisAlignment.CENTER))
        self.main_column.controls.insert(4, ft.Row([self.selected_gas_text], alignment=ft.MainAxisAlignment.CENTER))

    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            if selected_unit == 'ΔS':
                ureg1 = get_temperature_ureg(self.textfield_list[0].value, self.dropdown_list[0].value)
                ureg2 = get_temperature_ureg(self.textfield_list[1].value, self.dropdown_list[1].value)
                ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
                ureg4 = ureg.parse_expression(self.textfield_list[3].value + self.dropdown_list[3].value)
            elif selected_unit == 'Ti' or selected_unit == 'Tf':
                ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
                ureg2 = get_temperature_ureg(self.textfield_list[1].value, self.dropdown_list[1].value)
                ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
                ureg4 = ureg.parse_expression(self.textfield_list[3].value + self.dropdown_list[3].value)
            else:
                ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
                ureg2 = get_temperature_ureg(self.textfield_list[1].value, self.dropdown_list[1].value)
                ureg3 = get_temperature_ureg(self.textfield_list[2].value, self.dropdown_list[2].value)
                ureg4 = ureg.parse_expression(self.textfield_list[3].value + self.dropdown_list[3].value)
            result_ureg = function1(ureg1, ureg2, ureg3, ureg4, self.gas_dropdown.value)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'ΔS': 'Entropy',
            'Ti': 'Temperature',
            'Tf': 'Temperature',
            'Pi': 'Pressure',
            'Pf': 'Pressure',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'ΔS': calculate_entropy_change_from_pressure_temperature,
            'Ti': calculate_ti,
            'Tf': calculate_tf,
            'Pi': calculate_Pi_from_temperature,
            'Pf': calculate_Pf_from_temperature,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'ΔS': '熵',
                'Ti': '初溫度',
                'Tf': '末溫度',
                'Pi': '初壓力',
                'Pf': '末壓力',
            }
        else:
            return {
                'ΔS': 'Entropy',
                'Ti': 'Initial Temperature',
                'Tf': 'Final Temperature',
                'Pi': 'Initial Pressure',
                'Pf': 'Final Pressure',
            }

    def get_constant_str_list(self):
        return [f"R = {gas_constant2.magnitude} × atm × L × mole⁻¹ × K⁻¹", f"R = {gas_constant.magnitude} × J × mole⁻¹ × K⁻¹"]
