from functions.common_funtions import format_number
from functions.language_dict_functions import set_text_by_language
from functions.thermodynamics.real_gas_formula_functions import *
from functions.unit_functions import *
from views.abc_view.abc_calculate_law_view import CalculateLawViewClass
import flet as ft

# 新增氣體臨界常數資料
gas_critical_data = {
    "Air": {"Tc": 132.5, "Pc": 3.77},
    "NH3": {"Tc": 405.5, "Pc": 11.28},
    "Ar": {"Tc": 151.0, "Pc": 4.86},
    "C6H6": {"Tc": 562.0, "Pc": 4.89},
    "Br2": {"Tc": 584.0, "Pc": 10.34},
    "C4H10": {"Tc": 425.2, "Pc": 3.80},
    "CO": {"Tc": 132.9, "Pc": 3.50},
    "CO2": {"Tc": 304.2, "Pc": 7.39},
    "C2Cl4": {"Tc": 556.4, "Pc": 4.56},
    "CCl4": {"Tc": 556.4, "Pc": 4.56},
    "CHCl3": {"Tc": 536.6, "Pc": 5.47},
    "CH2Cl2": {"Tc": 510.0, "Pc": 6.10},
    "C2H4": {"Tc": 282.4, "Pc": 5.04},
    "C6H14": {"Tc": 507.5, "Pc": 3.02},
    "H2": {"Tc": 33.3, "Pc": 1.30},
    "Kr": {"Tc": 209.4, "Pc": 5.50},
    "CH4": {"Tc": 191.1, "Pc": 4.60},
    "CH3OH": {"Tc": 512.6, "Pc": 8.09},
    "CH3Cl": {"Tc": 416.4, "Pc": 6.68},
    "Ne": {"Tc": 44.5, "Pc": 2.73},
    "N2": {"Tc": 126.2, "Pc": 3.40},
    "N2O": {"Tc": 309.7, "Pc": 7.24},
    "O2": {"Tc": 154.8, "Pc": 5.08},
    "C3H6": {"Tc": 370.0, "Pc": 4.64},
    "C3H8": {"Tc": 365.0, "Pc": 4.26},
    "SO2": {"Tc": 430.7, "Pc": 7.88},
    "CF3CH2F": {"Tc": 374.2, "Pc": 4.059},
    "CCl3F": {"Tc": 471.2, "Pc": 3.96},
    "H2O": {"Tc": 647.1, "Pc": 22.06},
    "Xe": {"Tc": 289.8, "Pc": 5.88},
}


class RealGasLawView(CalculateLawViewClass):
    def __init__(self, page):
        super().__init__(page)
        # 預設選第一個氣體，並計算 a b
        selected_gas = list(gas_critical_data.keys())[0]
        Tc = gas_critical_data[selected_gas]['Tc'] * ureg.K
        Pc = (gas_critical_data[selected_gas]['Pc'] * ureg.MPa).to('atm')
        self.vdw_a = calculate_a(Tc, Pc)
        self.vdw_b = calculate_b(Tc, Pc)
        choice_gas_text = set_text_by_language('選擇氣體', self.lang)

        def on_gas_selected(e):
            selected_gas = self.gas_dropdown.value
            if selected_gas in gas_critical_data:
                Tc = gas_critical_data[selected_gas]['Tc'] * ureg.K
                Pc = (gas_critical_data[selected_gas]['Pc'] * ureg.MPa).to('atm')
                self.vdw_a = calculate_a(Tc, Pc)
                self.vdw_b = calculate_b(Tc, Pc)
                self.gas_result_text.value = (
                    f"Tc = {Tc.magnitude:.3f} K\n"
                    f"Pc = {Pc.magnitude:.3f} atm\n"
                    f"a = {self.vdw_a.magnitude:.3f} L²atm/mole²\n"
                    f"b = {self.vdw_b.magnitude:.3f} L/mole\n"
                )
                self.gas_result_text.update()
            self.calculate1(None)

        self.gas_dropdown = ft.Dropdown(
            label=choice_gas_text,
            options=[ft.dropdown.Option(key=k, text=k) for k in gas_critical_data.keys()],
            value=list(gas_critical_data.keys())[0],
            on_change=on_gas_selected,
            width=200,
            color='white',
            border_color=ft.Colors.WHITE
        )
        self.gas_result_text = ft.Text("", size=14, color='white')
        self.gas_result_text.value = (
            f"Tc = {Tc.magnitude:.3f} K\n"
            f"Pc = {Pc.magnitude:.3f} atm\n"
            f"a = {self.vdw_a.magnitude:.3f} L²atm/mole²\n"
            f"b = {self.vdw_b.magnitude:.3f} L/mole\n"
        )

        # 頁面中插入氣體下拉與結果
        self.main_column.controls.insert(3, ft.Row([self.gas_dropdown], alignment=ft.MainAxisAlignment.CENTER))
        self.main_column.controls.insert(4, ft.Row([self.gas_result_text], alignment=ft.MainAxisAlignment.CENTER))

    def calculate1(self, e):
        selected_unit = self.calculate_selector.value
        function1 = self.all_symbol_calculate_on_change_function_dict[selected_unit]
        try:
            if selected_unit == 'T':
                ureg3 = ureg.parse_expression(self.textfield_list[2].value + self.dropdown_list[2].value)
            else:
                ureg3 = get_temperature_ureg(self.textfield_list[2].value, self.dropdown_list[2].value)
            ureg1 = ureg.parse_expression(self.textfield_list[0].value + self.dropdown_list[0].value)
            ureg2 = ureg.parse_expression(self.textfield_list[1].value + self.dropdown_list[1].value)
            result_ureg = function1(ureg1, ureg2, ureg3, self.vdw_a, self.vdw_b)
            result_ureg = result_ureg.to(ureg.parse_expression(self.result_dropdown.value))
            new_value = result_ureg.magnitude
            result_str = format_number(new_value)
        except:
            result_str = self.result_str
        self.result_text.value = result_str
        self.result_text.update()

    def get_all_ccc_list_symbol_dict(self):
        return {
            'P': 'Pressure',
            'V': 'Volume',
            'n': 'Number',
            'T': 'Temperature',
        }

    def get_all_symbol_calculate_on_change_function_dict(self):
        return {
            'P': calculate_pressure,
            'V': calculate_volume,
            'n': calculate_number,
            'T': calculate_temperature,
        }

    def get_all_symbol_option_name_dict(self):
        if self.lang == "zh":
            return {
                'P': '壓力',
                'V': '體積',
                'n': '氣體莫爾數',
                'T': '溫度',
            }
        else:
            return {
                'P': 'Pressure',
                'V': 'Volume',
                'n': 'Moles of Gas',
                'T': 'Temperature',
            }

    def get_constant_str_list(self):
        return [
            f"R = {gas_constant2.magnitude} × atm × L × mole⁻¹ × K⁻¹",
            f"R = {gas_constant.magnitude} × J × mole⁻¹ × K⁻¹"
        ]
