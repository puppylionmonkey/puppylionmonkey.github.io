import flet as ft
from functions.language_dict_functions import set_text_by_language
from functions.thermodynamics.specific_volume_table2_functions import get_saturation_properties_by_pressure
from functions.thermodynamics.specific_volume_table_functions import substance_list
from functions.unit_functions import ureg
from views.abc_view.abc_view import AbcView

substance_list = [substance for substance in substance_list if 'mp' in substance]


class SpecificVolumeTable2View(AbcView):
    def __init__(self, page):
        super().__init__(page)
        init_pressure = 101.325
        init_pressure_unit = 'kPa'
        init_result = get_saturation_properties_by_pressure('mp.H2O', init_pressure)

        self.substance_dropdown = ft.Dropdown(
            label=set_text_by_language('物質', self.lang),
            value='mp.H2O',
            options=[ft.dropdown.Option(text=substance.split('.')[1], key=substance) for substance in substance_list],
            width=200,
            on_change=self.update_output,
            enable_search=True,
            enable_filter=True,

        )
        self.pressure_input = self.get_textfield(label=set_text_by_language('壓力', self.lang), value=str(init_pressure), width=100, on_change=self.update_output)
        pressure_dropdown_option_list = self.get_zh_dropdown_list('Pressure') if self.lang == 'zh' else self.get_dropdown_list('Pressure')
        self.unit_dropdown = ft.Dropdown(
            options=pressure_dropdown_option_list,
            value=init_pressure_unit,
            width=133,
            on_change=self.update_output
        )
        self.output_rows = ft.Column([*self.render_output(init_result)], spacing=5)

        self.main_column = ft.Column([
            ft.Row([self.substance_dropdown], alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([self.pressure_input, self.unit_dropdown], alignment=ft.MainAxisAlignment.CENTER),
            self.output_rows,
        ], scroll='adaptive', spacing=10)

    def update_output(self, e):
        self.output_rows.controls.clear()

        if not self.substance_dropdown.value or not self.pressure_input.value:
            self.output_rows.controls.append(
                ft.Row([ft.Text(set_text_by_language('請輸入正確的數值', self.lang))], alignment=ft.MainAxisAlignment.CENTER))
            self.output_rows.update()
            return

        try:
            P_input = ureg.parse_expression(self.pressure_input.value + self.unit_dropdown.value)
            P = P_input.to('kPa').magnitude
            result = get_saturation_properties_by_pressure(self.substance_dropdown.value, P)
        except Exception as err:
            result = {"error": str(err)}

        if "error" in result:
            self.output_rows.controls.append(
                ft.Row([ft.Text(result["error"], max_lines=None, no_wrap=False, weight=ft.FontWeight.BOLD, selectable=True, width=300)],
                       alignment=ft.MainAxisAlignment.CENTER))
        else:
            self.output_rows.controls.extend(self.render_output(result))

        self.output_rows.update()

    def render_output(self, result: dict):
        return [
            self.get_unit_conversion_row(result['Tsat_K'], 'K', 'Temperature', f'{set_text_by_language("飽和溫度", self.lang)} Tsat'),
            ft.Row([ft.Text(f"{'-' * 15} {set_text_by_language('飽和液態', self.lang)} {'-' * 15}", weight=ft.FontWeight.BOLD, selectable=True)], alignment=ft.MainAxisAlignment.CENTER),
            self.get_unit_conversion_row(result['liquid']['v'], 'm³/kg', 'Specific_volume', f'{set_text_by_language("比容", self.lang)} vf'),
            self.get_unit_conversion_row(result['liquid']['h'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language("比焓", self.lang)} hf'),
            self.get_unit_conversion_row(result['liquid']['s'], 'kJ/(kg*K)', 'Specific_entropy', f'{set_text_by_language("比熵", self.lang)} sf'),
            self.get_unit_conversion_row(result['liquid']['u_est'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language("比內能", self.lang)} uf'),
            ft.Row([ft.Text(f"{'-' * 15} {set_text_by_language('飽和氣態', self.lang)} {'-' * 15}", weight=ft.FontWeight.BOLD, selectable=True)], alignment=ft.MainAxisAlignment.CENTER),
            self.get_unit_conversion_row(result['vapor']['v'], 'm³/kg', 'Specific_volume', f'{set_text_by_language("比容", self.lang)} vf'),
            self.get_unit_conversion_row(result['vapor']['h'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language("比焓", self.lang)} hf'),
            self.get_unit_conversion_row(result['vapor']['s'], 'kJ/(kg*K)', 'Specific_entropy', f'{set_text_by_language("比熵", self.lang)} sf'),
            self.get_unit_conversion_row(result['vapor']['u_est'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language("比內能", self.lang)} uf'),
        ]
