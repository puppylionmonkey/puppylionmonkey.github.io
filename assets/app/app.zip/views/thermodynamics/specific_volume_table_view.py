import flet as ft
from functions.language_dict_functions import language_dict, set_text_by_language
from functions.thermodynamics.specific_volume_table_functions import get_saturation_properties, substance_list
from functions.unit_functions import *
from views.abc_view.abc_view import AbcView

substance_list = [substance for substance in substance_list if 'mp' in substance]


class SpecificVolumeTableView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        init_temperature = 100
        init_temperature_unit = '°C'
        init_result = get_saturation_properties('mp.H2O', init_temperature + 273.15)

        self.substance_dropdown = ft.Dropdown(
            label=set_text_by_language('物質', self.lang),
            value='mp.H2O',
            options=[ft.dropdown.Option(text=substance.split('.')[1], key=substance) for substance in substance_list],
            width=200,
            on_change=self.update_output,
            enable_search=True,
            enable_filter=True,
        )
        self.temp_input = self.get_textfield(label=set_text_by_language('溫度', self.lang), value=str(init_temperature), width=100, on_change=self.update_output)
        temperature_dropdown_option_list = self.get_zh_dropdown_list('Temperature') if self.lang == 'zh' else self.get_dropdown_list('Temperature')
        self.unit_dropdown = ft.Dropdown(
            options=temperature_dropdown_option_list,
            value=init_temperature_unit,
            width=133,
            on_change=self.update_output
        )

        self.output_rows = ft.Column([
            self.get_unit_conversion_row(init_result['psat_kPa'], 'kPa', 'Pressure', f'{set_text_by_language('飽和壓力', self.lang)} Psat'),
            ft.Row([ft.Text(f"{'-' * 15} {set_text_by_language('飽和液態', self.lang)} {'-' * 15}", weight=ft.FontWeight.BOLD, selectable=True)], alignment=ft.MainAxisAlignment.CENTER),
            self.get_unit_conversion_row(init_result['liquid']['v'], 'm³/kg', 'Specific_volume', f'{set_text_by_language('比容', self.lang)} vf'),
            self.get_unit_conversion_row(init_result['liquid']['h'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比焓', self.lang)} hf'),
            self.get_unit_conversion_row(init_result['liquid']['s'], 'kJ/(kg*K)', 'Specific_entropy', f'{set_text_by_language('比熵', self.lang)} sf'),
            self.get_unit_conversion_row(init_result['liquid']['u_est'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比內能', self.lang)} uf'),
            ft.Row([ft.Text(f"{'-' * 15} {set_text_by_language('飽和氣態', self.lang)} {'-' * 15}", weight=ft.FontWeight.BOLD, selectable=True)], alignment=ft.MainAxisAlignment.CENTER),
            self.get_unit_conversion_row(init_result['vapor']['v'], 'm³/kg', 'Specific_volume', f'{set_text_by_language('比容', self.lang)} vf'),
            self.get_unit_conversion_row(init_result['vapor']['h'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比焓', self.lang)} hf'),
            self.get_unit_conversion_row(init_result['vapor']['s'], 'kJ/(kg*K)', 'Specific_entropy', f'{set_text_by_language('比熵', self.lang)} sf'),
            self.get_unit_conversion_row(init_result['vapor']['u_est'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比內能', self.lang)} uf'),
        ], spacing=5)

        self.main_column = ft.Column([
            ft.Row([self.substance_dropdown], alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([self.temp_input, self.unit_dropdown], alignment=ft.MainAxisAlignment.CENTER),
            self.output_rows,
        ]
            , scroll='adaptive'
            , spacing=10
        )

    def update_output(self, e):
        self.output_rows.controls.clear()
        if not self.substance_dropdown.value or not self.temp_input.value:
            self.output_rows.controls.append(ft.Row([ft.Text(set_text_by_language('請輸入正確的數值', self.lang))], alignment=ft.MainAxisAlignment.CENTER))
            self.output_rows.update()
            return

        # try:
        T_input = get_temperature_ureg(self.temp_input.value, self.unit_dropdown.value)
        T = T_input.to('K').magnitude
        result = get_saturation_properties(self.substance_dropdown.value, T)

        if "error" in result:
            self.output_rows.controls.append(ft.Row([ft.Text(result["error"], max_lines=None, no_wrap=False, weight=ft.FontWeight.BOLD, selectable=True, width=300)], alignment=ft.MainAxisAlignment.CENTER), )
        else:
            self.output_rows.controls.extend([
            self.get_unit_conversion_row(result['psat_kPa'], 'kPa', 'Pressure', f'{set_text_by_language('飽和壓力', self.lang)} Psat'),
            ft.Row([ft.Text(f"{'-' * 15} {set_text_by_language('飽和液態', self.lang)} {'-' * 15}", weight=ft.FontWeight.BOLD, selectable=True)], alignment=ft.MainAxisAlignment.CENTER),
            self.get_unit_conversion_row(result['liquid']['v'], 'm³/kg', 'Specific_volume', f'{set_text_by_language('比容', self.lang)} vf'),
            self.get_unit_conversion_row(result['liquid']['h'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比焓', self.lang)} hf'),
            self.get_unit_conversion_row(result['liquid']['s'], 'kJ/(kg*K)', 'Specific_entropy', f'{set_text_by_language('比熵', self.lang)} sf'),
            self.get_unit_conversion_row(result['liquid']['u_est'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比內能', self.lang)} uf'),
            ft.Row([ft.Text(f"{'-' * 15} {set_text_by_language('飽和氣態', self.lang)} {'-' * 15}", weight=ft.FontWeight.BOLD, selectable=True)], alignment=ft.MainAxisAlignment.CENTER),
            self.get_unit_conversion_row(result['vapor']['v'], 'm³/kg', 'Specific_volume', f'{set_text_by_language('比容', self.lang)} vf'),
            self.get_unit_conversion_row(result['vapor']['h'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比焓', self.lang)} hf'),
            self.get_unit_conversion_row(result['vapor']['s'], 'kJ/(kg*K)', 'Specific_entropy', f'{set_text_by_language('比熵', self.lang)} sf'),
            self.get_unit_conversion_row(result['vapor']['u_est'], 'kJ/kg', 'Specific_enthalpy', f'{set_text_by_language('比內能', self.lang)} uf'),
        ])

        self.output_rows.update()
