import flet as ft
from functions.language_dict_functions import set_text_by_language
from functions.thermodynamics.superheated_specific_volume_table_functions import get_superheated_properties
from functions.unit_functions import *
from views.abc_view.abc_view import AbcView
from functions.thermodynamics.specific_volume_table_functions import substance_list

substance_list = [s for s in substance_list if 'mp' in s]


class SuperheatedSteamPropertiesView(AbcView):
    def __init__(self, page):
        super().__init__(page)

        init_T = 773.15  # 500°C
        init_P = 2.0  # MPa
        init_T_unit = '°C'
        init_P_unit = 'MPa'
        init_result = get_superheated_properties('mp.H2O', init_T, init_P)

        self.substance_dropdown = ft.Dropdown(
            label=set_text_by_language('物質', self.lang),
            value='mp.H2O',
            options=[ft.dropdown.Option(text=s.split('.')[1], key=s) for s in substance_list],
            width=200,
            on_change=self.update_output,
            enable_search=True,
            enable_filter=True,
        )

        self.temp_input = self.get_textfield(label=set_text_by_language('溫度', self.lang), value=str(init_T - 273.15), width=100, on_change=self.update_output)
        temp_unit_options = self.get_zh_dropdown_list('Temperature') if self.lang == 'zh' else self.get_dropdown_list('Temperature')
        self.temp_unit_dropdown = ft.Dropdown(
            options=temp_unit_options,
            value=init_T_unit,
            width=120,
            on_change=self.update_output
        )

        self.pressure_input =   self.get_textfield(label=set_text_by_language('壓力', self.lang), value=str(init_P), width=100, on_change=self.update_output)
        pressure_unit_options = self.get_zh_dropdown_list('Pressure') if self.lang == 'zh' else self.get_dropdown_list('Pressure')
        self.pressure_unit_dropdown = ft.Dropdown(
            options=pressure_unit_options,
            value=init_P_unit,
            width=120,
            on_change=self.update_output
        )

        self.output_rows = ft.Column(self.render_output(init_result), spacing=5)

        self.main_column = ft.Column([
            ft.Row([self.substance_dropdown], alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([self.temp_input, self.temp_unit_dropdown], alignment=ft.MainAxisAlignment.CENTER),
            ft.Row([self.pressure_input, self.pressure_unit_dropdown], alignment=ft.MainAxisAlignment.CENTER),
            self.output_rows,
        ], scroll='adaptive', spacing=10)

    def update_output(self, e):
        self.output_rows.controls.clear()
        if not self.substance_dropdown.value or not self.temp_input.value or not self.pressure_input.value:
            self.output_rows.controls.append(ft.Row([ft.Text(set_text_by_language('請輸入正確的數值', self.lang))], alignment=ft.MainAxisAlignment.CENTER))
            self.output_rows.update()
            return

        try:
            T = get_temperature_ureg(self.temp_input.value, self.temp_unit_dropdown.value).to('K').magnitude
            P = ureg.parse_expression(self.pressure_input.value + self.pressure_unit_dropdown.value).to('MPa').magnitude
            result = get_superheated_properties(self.substance_dropdown.value, T, P)
        except Exception as err:
            result = {"error": str(err)}

        if "error" in result:
            self.output_rows.controls.append(ft.Row([ft.Text(result["error"], max_lines=None, weight=ft.FontWeight.BOLD, selectable=True)], alignment=ft.MainAxisAlignment.CENTER))
        else:
            self.output_rows.controls.extend(self.render_output(result))

        self.output_rows.update()

    def render_output(self, result: dict):
        return [
            self.get_unit_conversion_row(result['T'], 'K', 'Temperature', f"{set_text_by_language('溫度', self.lang)} T"),
            self.get_unit_conversion_row(result['P_MPa'], 'MPa', 'Pressure', f"{set_text_by_language('壓力', self.lang)} P"),
            self.get_unit_conversion_row(result['v'], 'm³/kg', 'Specific_volume', f"{set_text_by_language('比容', self.lang)} v"),
            self.get_unit_conversion_row(result['h'], 'kJ/kg', 'Specific_enthalpy', f"{set_text_by_language('比焓', self.lang)} h"),
            self.get_unit_conversion_row(result['s'], 'kJ/(kg*K)', 'Specific_entropy', f"{set_text_by_language('比熵', self.lang)} s"),
            self.get_unit_conversion_row(result['u'], 'kJ/kg', 'Specific_enthalpy', f"{set_text_by_language('內能', self.lang)} u"),
        ]
