import flet as ft

from functions.common_funtions import format_number
from functions.language_dict_functions import get_language, set_text_by_language
from functions.unit_functions import *
from views.abc_view.abc_view import AbcView


class UnitConversionView(AbcView):
    def __init__(self, page):
        super().__init__(page)
        font_color = 'white'
        title_color = 'pink600'
        dropdown_width = 133
        lang = get_language()
        dropdown_label = set_text_by_language('單位', self.lang)

        def on_unit_selected(e):
            selected_unit = self.unit_selector.value
            unit_symbol_name_dict = all_unit_dict_dict[selected_unit]
            # 修改其他欄位
            self.title = f'{all_unit_name_dict[selected_unit]} ({selected_unit})'
            unit_conversion_text.value = self.title
            input_textfield.label = self.title
            if self.lang == 'zh':
                dropdown_option_list1 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in unit_symbol_name_dict.items()]
                dropdown_option_list2 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in unit_symbol_name_dict.items()]
            else:
                dropdown_option_list1 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in unit_symbol_name_dict.items()]
                dropdown_option_list2 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in unit_symbol_name_dict.items()]
            first_unit_symbol_name = list(unit_symbol_name_dict.items())[0]
            input_dropdown.value = first_unit_symbol_name[0]
            output_dropdown.value = first_unit_symbol_name[0]
            input_dropdown.options = dropdown_option_list1
            output_dropdown.options = dropdown_option_list2
            page.update()
            calculate_ui(None)

        if lang == 'zh':
            unit_selector_options = [ft.dropdown.Option(key=unit, text=f"{name} ({unit})") for unit, name in all_unit_name_dict.items() if unit not in exclude_unit_list]
        else:
            unit_selector_options = [ft.dropdown.Option(key=unit, text=unit) for unit, name in all_unit_name_dict.items() if unit not in exclude_unit_list]
        self.unit_selector = ft.Dropdown(
            options=unit_selector_options,
            value='Mass',
            on_change=on_unit_selected,
            alignment=ft.MainAxisAlignment.CENTER
        )

        self.title = "質量 (Mass)"
        unit_symbol_list = mass_unit_symbol_list
        if self.lang == 'zh':
            dropdown_option_list1 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in mass_unit_symbol_name_dict.items()]
            dropdown_option_list2 = [ft.dropdown.Option(text=name + ' (' + unit_symbol + ')', key=unit_symbol) for unit_symbol, name in mass_unit_symbol_name_dict.items()]
        else:
            dropdown_option_list1 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in mass_unit_symbol_name_dict.items()]
            dropdown_option_list2 = [ft.dropdown.Option(text=unit_symbol, key=unit_symbol) for unit_symbol, name in mass_unit_symbol_name_dict.items()]

        def calculate_ui(e):
            if '溫度' in self.title or 'Temperature' in self.title:
                new_value = temperature_conversion(float(input_textfield.value), input_dropdown.value, output_dropdown.value)
            else:
                input_ureg = ureg.parse_expression(input_textfield.value + input_dropdown.value)
                new_unit = ureg.parse_expression(output_dropdown.value)
                new_value = input_ureg.to(new_unit)
            new_value = float(str(new_value).split()[0])
            output_text.value = format_number(new_value)
            output_text.update()

        unit_conversion_text = ft.Text(value=self.title, size=30, color=title_color)

        input_textfield = self.get_textfield(
            label=self.title,
            on_change=calculate_ui,
            keyboard_type=ft.KeyboardType.PHONE,
            value='1',
            # width=dropdown_width,
            color=font_color,
            border_color=ft.Colors.WHITE,
            expand=True,
            autofocus=True,
        )
        input_dropdown = ft.Dropdown(
            label=dropdown_label,
            options=dropdown_option_list1,
            value=unit_symbol_list[0],
            on_change=calculate_ui,
            width=dropdown_width,
            color=font_color,
            border_color=ft.Colors.WHITE
        )
        output_text = ft.Text(
            size=24,
            value=input_textfield.value,
            color=font_color,
            selectable=True,
            expand=True,
        )
        output_dropdown = ft.Dropdown(
            label=dropdown_label,
            options=dropdown_option_list2,
            value=unit_symbol_list[0],
            on_change=calculate_ui,
            width=dropdown_width,
            color=font_color,
            border_color=ft.Colors.WHITE
        )
        equal_sign_text = ft.Text("=", size=24)

        self.unit_conversion_view_column = ft.Column(
            controls=[
                ft.Row([self.unit_selector], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([input_textfield, input_dropdown]),
                ft.Row([equal_sign_text, output_text, output_dropdown], alignment=ft.MainAxisAlignment.CENTER)
            ],
            scroll=ft.core.types.ScrollMode.ADAPTIVE,
            # alignment=ft.MainAxisAlignment.START
        )

    def get_view(self):
        return ft.View(
            '/unit_conversion',
            controls=[
                # self.app_bar,
                ft.Container(content=self.unit_conversion_view_column, expand=True, alignment=ft.alignment.top_center, ),
            ],
            adaptive=True,
            padding=ft.padding.only(bottom=120 if self.page.platform == ft.PagePlatform.ANDROID else 70, left=10, right=10, top=70 if self.page.platform == ft.PagePlatform.ANDROID else 40),
        )
